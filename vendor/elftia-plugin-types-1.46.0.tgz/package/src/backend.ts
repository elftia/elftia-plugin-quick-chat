/**
 * backend.ts — `AgentBackendHostApi` v1: the frozen TYPE of the object the
 * MAIN-process loader injects into a Tier-1 plugin's main-side `activate`.
 *
 * This module references Node/Electron-shaped types (Decision D2). It MUST NOT
 * import `renderer.ts`, and no symbol it exports may pull a DOM type into the
 * main (Node) context. The only cross-module dependency allowed is the
 * lib-agnostic `./version`. Electron/Node shapes are declared STRUCTURALLY here
 * (no `import type { WebContents } from 'electron'`) so the frozen surface does
 * not lock an Electron type into the plugin package and stays decoupled.
 *
 * MINIMALITY (窄端口). Exactly TWO members — `registerMcpProviderFactory`,
 * `registerIpcMethods` — each backing onto an already-shipped mechanism. See
 * the freeze checklist in `./version`.
 *
 * DELIBERATELY EXCLUDED (enumerated for the freeze review):
 *   - A "static-channel privilege" field (OQ2 / D9) — `registerIpcMethods` is
 *     the first-class surface; transitional static `design.*` CHANNELS live
 *     OUTSIDE this contract as a time-boxed migration crutch.
 *   - Direct DB / filesystem / config handles — a plugin reaches main-side
 *     resources only through the methods it registers, not via raw host handles
 *     in v1 (additive later if a real consumer needs them).
 *   - Any loader / IPC-routing runtime (`plugins:invoke` dispatch) — that is
 *     Child I, out of scope.
 *
 * @module @elftia/plugin-types/backend
 */
import type {
  HostAgentBackendDefinition,
  HostAgentsBackend,
  HostAgentSessionSetupFn,
  HostAgentSetupInput,
  HostAgentSetupResult,
  HostAgentSetupSpecComponents,
  HostAgentsUi,
  HostAgentUiDefinition,
} from './host-api/agents';
import type { HostArtifactsMain } from './host-api/artifacts';
import type { AgentBackendHostServices } from './host-api/backend-services';
import type { HostCapabilities } from './host-api/capabilities';
import type { HostNotificationsBackend } from './host-api/notifications';
import type { HostToolkitsBackend, HostToolkitSpecLike } from './host-api/skill-toolkit';
import type { HostToolHostDescriptorLike, HostToolHostsBackend } from './host-api/tool-hosts';
import type {
  HostWorkflowCallContext,
  HostWorkflowCapabilities,
  HostWorkflowDescriptor,
  HostWorkflowDiagnostic,
  HostWorkflowError,
  HostWorkflowErrorCode,
  HostWorkflowProvider,
  HostWorkflowRegistration,
  HostWorkflowRequest,
  HostWorkflowResponse,
  HostWorkflowShutdownReason,
  HostWorkflowToolAccess,
  HostWorkflowToolDescriptor,
  HostWorkflowToolsetDescriptor,
} from './host-api/workflow';
import type {
  HostBrowserAction,
  HostBrowserInvokeContext,
  HostBrowserInvokeResult,
  HostBrowserToolkitLike,
  HostBrowserUnavailableReason,
} from './host-api/workflow-browser';
import type {
  HostStageBackend,
  HostStageOutcome,
  HostStageRole,
  HostStageStartInput,
  HostStageStartResult,
  HostWorkflowStageRuntimeLike,
} from './host-api/workflow-stage-runtime';
import type { HostApiCompat } from './version';

// Re-export the ADDITIVE v1.5 sibling type so it stays reachable from the
// `@elftia/plugin-types/backend` module surface (the barrel re-exports it).
export type { AgentBackendHostServices };
export type {
  HostLocalChannelAttachResult,
  HostLocalChannelEventEnvelope,
  HostLocalChannelOperationResult,
  HostLocalChannelsBackend,
} from './host-api/local-channels';
// Re-export the ADDITIVE v1.44 agents sibling types — both the renderer-half
// (`HostAgentsUi`) and backend-half (`HostAgentsBackend`) shapes live in
// `host-api/agents.ts` (a shared sibling module importing only `./_shared`).
export type {
  HostAgentBackendDefinition,
  HostAgentsBackend,
  HostAgentSessionSetupFn,
  HostAgentSetupInput,
  HostAgentSetupResult,
  HostAgentSetupSpecComponents,
  HostAgentsUi,
  HostAgentUiDefinition,
};
// Re-export the ADDITIVE v1.39 workflow sibling types the same way, so the
// whole `host.workflow` contract is reachable from the `backend` module surface.
export type {
  HostWorkflowCallContext,
  HostWorkflowCapabilities,
  HostWorkflowDescriptor,
  HostWorkflowDiagnostic,
  HostWorkflowError,
  HostWorkflowErrorCode,
  HostWorkflowProvider,
  HostWorkflowRegistration,
  HostWorkflowRequest,
  HostWorkflowResponse,
  HostWorkflowShutdownReason,
  HostWorkflowToolAccess,
  HostWorkflowToolDescriptor,
  HostWorkflowToolsetDescriptor,
};
// Re-export the ADDITIVE v1.40 workflow SIBLING SEAM types the same way, so the
// stage-runtime and browser-toolkit ports `host.workflow` now carries are
// reachable from the `backend` module surface too.
export type {
  HostBrowserAction,
  HostBrowserInvokeContext,
  HostBrowserInvokeResult,
  HostBrowserToolkitLike,
  HostBrowserUnavailableReason,
  HostStageBackend,
  HostStageOutcome,
  HostStageRole,
  HostStageStartInput,
  HostStageStartResult,
  HostWorkflowStageRuntimeLike,
};
// Re-export the ADDITIVE v1.48 artifact sibling types so the whole
// `host.artifacts` contract is reachable from the `backend` module surface.
// From-form re-exports: backend.ts itself names only `HostArtifactsMain` (the
// member type); the vocabulary re-exports need no local import.
export type {
  HostArtifactBadge,
  HostArtifactContext,
  HostArtifactEnvelope,
  HostArtifactErrorCode,
  HostArtifactKindDefinition,
  HostArtifactKindProvider,
  HostArtifactOpenOptions,
  HostArtifactOpenResult,
  HostArtifactRef,
  HostArtifactScope,
  HostArtifactsMain,
  HostArtifactsRenderer,
  HostArtifactState,
  HostArtifactSummary,
  HostArtifactSurfaceContext,
  HostArtifactSurfaceDefinition,
  HostArtifactSurfacePlacement,
  HostArtifactSurfaceProps,
  HostArtifactSurfaceRole,
  HostOpaqueArtifactLocator,
  HostSurfaceInteractionMode,
} from './host-api/artifacts';
// The C5 storage port lives in its own sibling module (it is a
// `host.services` member, not a `host.artifacts` member).
export type { HostArtifactStorageLike } from './host-api/artifact-storage';
// Re-export the ADDITIVE v1.51 tool-host sibling types the same way, so the
// whole `host.toolHosts` contract is reachable from the `backend` module
// surface. From-form re-export: backend.ts itself names only
// `HostToolHostsBackend` (the member type); the descriptor vocabulary needs no
// local import.
export type { HostToolHostDescriptorLike };
// Re-export the ADDITIVE v1.55 skill-toolkit sibling types the same way, so
// the whole `host.toolkits` contract is reachable from the `backend` module
// surface. From-form re-export: backend.ts itself names only
// `HostToolkitsBackend` (the member type) plus the spec it registers.
export type { HostToolkitFunctionLike } from './host-api/skill-toolkit';
export type { HostToolkitSpecLike };

// ───────────────────────────────────────────────────────────────────────────
// MCP provider factory (Decision D3)
// ───────────────────────────────────────────────────────────────────────────

/**
 * Structural mirror of an `McpProvider` value (the unit the registry holds).
 *
 * @remarks Canonical: `McpProvider`
 *   (`services/capabilities/tools/mcp-builtin/types.ts`), registered via
 *   `McpProviderRegistry.register(provider)`. Pinned to the identity members
 *   (`name`, `isEligible`, `buildEntry`); the rest are opaque so the frozen
 *   surface does not lock the full provider type into the plugin package.
 */
export interface HostMcpProviderLike {
  /** Unique MCP server name (becomes the `mcp__<name>__*` prefix). */
  readonly name: string;
  /**
   * Decide whether this MCP registers for a given session context.
   *
   * `ctx` is typed `unknown` (opaque-by-design — the real shape is main-owned
   * and not relocated into this package), but it is LOAD-BEARING: the real
   * argument is the per-session `AssemblyContext` (engineType / agentId /
   * providerId / model / trustTier / capabilities / designStudio / service
   * handles …). A plugin author MUST consult the canonical shape to read it.
   * @see `AssemblyContext` in
   *   `packages/desktop/app/main/services/capabilities/tools/mcp-builtin/types.ts`
   */
  isEligible(ctx: unknown): boolean | Promise<boolean>;
  /**
   * Build the engine-shape entry for the session. `ctx` is the same load-bearing
   * `AssemblyContext` described on {@link HostMcpProviderLike.isEligible}.
   * @see `AssemblyContext` in
   *   `packages/desktop/app/main/services/capabilities/tools/mcp-builtin/types.ts`
   */
  buildEntry(ctx: unknown): unknown;
  /** Remaining provider members (start/stop/fragments/…) are opaque — see source. */
  readonly [key: string]: unknown;
}

/**
 * A factory the plugin registers that yields an `McpProvider`-shaped value.
 * The host registers the produced provider into the shipped
 * `McpProviderRegistry` (Decision D3).
 *
 * @stability frozen
 */
export type HostMcpProviderFactory = () => HostMcpProviderLike;

// ───────────────────────────────────────────────────────────────────────────
// Scoped main-side IPC methods (Decision D6 / OQ2 D9)
// ───────────────────────────────────────────────────────────────────────────

/**
 * A single main-side handler the renderer reaches via the plugin's scoped
 * `host.ipc.invoke`. The host injects `pluginId`, so the renderer-supplied
 * `method` is plugin-local.
 *
 * @stability frozen
 */
export type HostIpcMethodHandler = (payload: unknown) => Promise<unknown> | unknown;

/**
 * A map of plugin-local method name → handler. Registered under the plugin's
 * `pluginId` (host-injected). These are reached via the FUTURE `plugins:invoke`
 * bridge (Child I) — they are NOT added to the static `CHANNELS` (Decision D6 /
 * OQ2 D9: no permanent first-party static-channel tier).
 */
export type HostIpcMethodMap = Record<string, HostIpcMethodHandler>;

/** Unregister previously-registered main-side resources (teardown). */
export type HostBackendUnregister = () => void;

// ───────────────────────────────────────────────────────────────────────────
// AgentBackendHostApi v1 — the frozen main surface (2 members)
// ───────────────────────────────────────────────────────────────────────────

/**
 * `AgentBackendHostApi` — the TYPE of the object the MAIN-process loader injects
 * into a Tier-1 plugin's main-side `activate`.
 *
 * v1 (frozen, byte-unchanged) — 2 members (窄端口):
 *   1. `registerMcpProviderFactory` — register an MCP provider into the shipped
 *      `McpProviderRegistry`.
 *   2. `registerIpcMethods` — register per-`pluginId` main-side methods reached
 *      via the future `plugins:invoke` bridge (NOT static `CHANNELS`).
 *
 * v1.5 (ADDITIVE, MINOR — the FIRST `AgentBackendHostApi` extension) — 1 member:
 *   4. `services` — the runtime service singletons the DS main `activate`
 *      composes its service layer from (see {@link AgentBackendHostServices}).
 *      Fulfills the v1 "additive later if a real consumer needs them" deferral
 *      (above) — DS's main flip is that consumer.
 *
 * v1.39 (ADDITIVE, MINOR) — 1 OPTIONAL member:
 *   5. `workflow?` — the DEEP workflow-provider registration namespace (see
 *      {@link HostWorkflowRegistration}). A plugin publishes a whole tool
 *      surface as a wire-safe descriptor and serves it through one `execute`
 *      entry point. OPTIONAL: a host build that does not wire a workflow
 *      registry omits it and the plugin `activate` guards.
 *
 * Plus `version` / `compat` mirroring the renderer surface.
 *
 * @stability frozen — see the freeze checklist in `./version`. The 2 v1 members
 *   are byte-unchanged; `services` (v1.5) and `workflow?` (v1.39) are additive
 *   (MINOR).
 */
export interface AgentBackendHostApi {
  /** The running host-API version string (the injected `HOST_API_VERSION`). */
  readonly version: string;
  /** Compatibility descriptor the host computed for this plugin (R1 gate). */
  readonly compat: HostApiCompat;

  /**
   * Member 1 — register an MCP provider factory.
   *
   * @remarks Backs onto `McpProviderRegistry.register(provider)`
   *   (`services/capabilities/tools/mcp-builtin/McpProviderRegistry.ts`). The
   *   `factory` returns an `McpProvider`-shaped value the host registers.
   */
  registerMcpProviderFactory(factory: HostMcpProviderFactory): HostBackendUnregister;

  /**
   * Member 2 — register per-`pluginId` main-side IPC methods.
   *
   * @remarks The methods are namespaced under the plugin's `pluginId`
   *   (host-injected) and reached via the FUTURE `plugins:invoke` bridge
   *   (Child I). They are NOT added to the static `CHANNELS` surface
   *   (Decision D6 / OQ2 D9).
   */
  registerIpcMethods(methods: HostIpcMethodMap): HostBackendUnregister;

  /**
   * ADDITIVE v1.5 (MINOR) — the runtime service singletons the DS main
   * `activate` composes its service layer from. A service-HANDLE port (whole
   * service objects, not per-operation reads) because the DS main half COMPOSES
   * a layer from these singletons. EXACTLY the 8 `bootstrapContentDesignStudio`
   * inputs + the `engineDispatcher` the design-session handler closes over (窄端口
   * — no speculative handles). Each handle is the LIVE boot singleton (threaded
   * through `loadMainExtensions`), or `undefined` when a build omits it (the
   * plugin `activate` guards). Opaque structural lower bounds (the
   * `HostMcpProviderLike` discipline — the contract imports no `@main` source);
   * the plugin casts each to the real service type at its construction boundary.
   * @see {@link AgentBackendHostServices}
   */
  readonly services: AgentBackendHostServices;

  /**
   * ADDITIVE v1.39 (MINOR) — member 5: the DEEP `host.workflow` registration
   * namespace (`rasen-single-plugin` Milestone 1). A plugin registers ONE
   * {@link HostWorkflowProvider} that publishes a whole tool surface as a
   * wire-safe descriptor and serves it through a single `execute` entry point,
   * so the host derives every classification (tool names, toolset membership,
   * the safe-tool allowlist, legacy aliases) from that descriptor instead of
   * hand-keeping its own lists.
   *
   * A NAMESPACE OBJECT rather than a fourth top-level `registerX` method: the
   * sibling workflow seams (a stage runtime, a browser toolkit) land beside
   * `register` without another top-level member.
   *
   * OPTIONAL (D3) — and optional is the HONEST shape, not a convenience. Every
   * conditionally-wired port in this contract (`storage`, `sessionRuntime`,
   * `pluginPaths`, `backupPolicy`, …) is optional and the plugin `activate`
   * guards; `services` is required only because it is always constructible. A
   * workflow registry is NOT wired on every host path — the extension-host path
   * deliberately does not wire it while the provider's verbs are not yet
   * wire-proxied — so a REQUIRED member whose `register` threw would be a worse
   * contract than an absent one. An older host lacks it entirely; a plugin
   * guards with `host.workflow?.register(...)` and activates normally without
   * workflow capability. Adding it as OPTIONAL is what keeps this bump MINOR.
   *
   * OWNER ID IS HOST-INJECTED: the host closes over the registering plugin's id
   * and records it as the owner (the `registerSessionHandler` discipline). No
   * plugin-supplied identity is accepted, so a plugin can neither name its own
   * owner id nor register on behalf of another plugin. The returned teardown is
   * also fed into the host's per-plugin teardown drain, so disabling the owner
   * revokes the registration even if the plugin never calls it.
   *
   * @see {@link HostWorkflowRegistration}
   */
  readonly workflow?: HostWorkflowRegistration;

  /**
   * ADDITIVE v1.44 (MINOR) — the UNIFIED `host.agents` backend-half registration
   * namespace. `define(def)` registers the setup function (if present) in the
   * `AgentSessionSetupRegistry` under key `def.agentId`; the returned
   * {@link HostBackendUnregister} revokes the registration.
   *
   * OPTIONAL (the same optional-member discipline as `workflow?`): a host built
   * at ≤v1.43 lacks it and the plugin guards `host.agents?.define(...)`.
   *
   * MINIMALITY: one `define` verb. The setup function is called by the
   * engineSession hook to inject per-session deltas (systemPromptAppend,
   * specComponents, engineConfigPatch, projectPath, mediaAssetOutput) WITHOUT
   * bypassing the standard path. See {@link HostAgentsBackend} /
   * {@link HostAgentBackendDefinition}.
   */
  readonly agents?: HostAgentsBackend;

  /**
   * ADDITIVE v1.47 (MINOR) — the cross-plugin Capability composition handle
   * (`elftia-composition-platform` Phase 1, design §8). A plugin declares
   * `capabilities.provides` / `requires` / `optional` in its manifest and
   * reaches the other side of that declaration here, instead of importing a
   * sibling plugin or calling its scoped IPC (design D2).
   *
   * SAME SHAPE ON BOTH HALVES (design D3): `HostCapabilities` references no
   * React / DOM / Node type, so `AgentUiHostApi` exposes this identical
   * interface. `HostCapabilityTarget` carries the process distinction as data.
   * Contrast `host.artifacts` (Phase 2), which MUST split per half.
   *
   * OPTIONAL (the same discipline as `workflow?` / `agents?`): a host built at
   * ≤v1.46 lacks it and the plugin guards `host.capabilities?.…`. Also honest —
   * the Broker is not wired on every host path.
   *
   * MINIMALITY: three verbs, one per role. `provide` is the Provider side,
   * `require` the Consumer side, `explain` the diagnosis side that design §39
   * makes an acceptance criterion. `observe()` is deliberately ABSENT (D21) —
   * deferred until a real optional consumer can validate its shape.
   * @see {@link HostCapabilities}
   */
  readonly capabilities?: HostCapabilities;

  /**
   * ADDITIVE v1.48 (MINOR) — the Artifact layer's MAIN-half handle
   * (`elftia-composition-platform` Phase 2, design §10). Unlike
   * `capabilities?` above, this namespace SPLITS per half (design §37 D3):
   * this is the data plane (`registerKind` / `create` / `getSummary` /
   * `subscribeSummary`); `AgentUiHostApi.artifacts?` carries the React-shaped
   * members (`surfaces` / `ArtifactView`). `open` appears on BOTH halves with
   * ONE pure-data signature (Gate-0 C2 — the member-level application of D3's
   * own "pure data ⇒ do not split" rule that keeps `HostCapabilities` whole).
   * Member assignment is pinned by cross-half absence probes in the smoke
   * fixtures + the half-purity gate test.
   *
   * OPTIONAL (the same discipline as `capabilities?`): a host built at ≤v1.47
   * lacks it and the plugin guards `host.artifacts?.…`. Honest — the artifact
   * runtime lands in later slices; this freeze is contract-only.
   *
   * MINIMALITY: four verbs + optional `open` — a kind exists only when a
   * provider registers it, `create` is the only way an artifact comes to
   * exist, and `getSummary`/`subscribeSummary` are the one projection (read +
   * live) every consumer eventually sees. No renderer data-plane verb, no
   * destroy, no `list`/`observe` (D21 — freeze no verb without a consumer).
   * @see {@link HostArtifactsMain}
   */
  readonly artifacts?: HostArtifactsMain;

  /**
   * ADDITIVE v1.51 (MINOR) — the `host.toolHosts` tool-host registration
   * namespace (Slice S08 `08-host-owned-tool-hosts`, change
   * `s08-pane-and-tool-host-surface`). A plugin registers ONE
   * {@link HostToolHostDescriptorLike} — pure data naming where its daemon
   * lives, how it launches, and where its rendezvous files are — and the host
   * takes over supervision (spawn, rendezvous wait, ownership, idle sweep)
   * plus the generic renderer entry surface. Nothing in the contract names a
   * specific tool (acceptance C4): which hosts exist is decided by which
   * plugins register.
   *
   * MINIMALITY: EXACTLY one verb, `register`. No status/stop verbs here —
   * supervision is host-owned, and the user reaches it through the host's own
   * IPC surface, not through the registering plugin. Registering delegates
   * process-spawning to the descriptor's `launch` fields, which is why the
   * manifest side carries the `host:tool-hosts` declaration token (same
   * declaration-worthy class as `host:workflow`).
   *
   * OPTIONAL (the same discipline as `workflow?` / `agents?`) — and optional
   * is the HONEST shape: the extension-host branch deliberately does not wire
   * this member while the descriptor is validated and consumed entirely on
   * the main process (the documented `workflow`-port posture — no wire-proxy
   * obligation is invented for it here). A host built at ≤v1.50 lacks it; a
   * plugin guards `host.toolHosts?.register(...)` and activates normally
   * without tool-host capability.
   *
   * OWNER TEARDOWN IS HOST-DRAINED: the returned {@link HostBackendUnregister}
   * is also fed into the host's per-plugin teardown drain, so disabling or
   * hot-toggling the owner unregisters the descriptor even if the plugin never
   * calls it. Teardown unregisters the DESCRIPTOR only — it never stops a
   * live daemon (daemons outlive plugins).
   * @see {@link HostToolHostsBackend} / {@link HostToolHostDescriptorLike}
   */
  readonly toolHosts?: HostToolHostsBackend;

  /**
   * ADDITIVE v1.53 (MINOR) — the `host.notifications` plugin notification
   * port (Slice S08 `08-host-owned-tool-hosts`, change
   * `s08-notifications-and-export`). A plugin's main half raises ONE
   * system notification through EXACTLY one verb, `notify(input) → void`,
   * with an optional DATA-ONLY click action
   * ({@link HostNotificationAction} — `openPath` on an absolute existing
   * directory): the HOST executes the action on click (focus the main
   * window, re-validate the path, `shell.openPath`), so a notification may
   * outlive its plugin — no callback ever crosses the seam and a click
   * after a disable runs zero plugin code.
   *
   * OS-SURFACE DISCIPLINE: title/body are rendered by the OS notification
   * surface (retained, indexed, screenshotable) — a plugin MUST NOT place
   * tokens or credential-bearing URLs in them. The host does not censor;
   * the `host:notifications` manifest declaration token is the review
   * signal. Attribution is HOST-INJECTED (the registering plugin's id) —
   * the input carries no source field a plugin could forge.
   *
   * OPTIONAL (the same discipline as `toolHosts?` / `workflow?`) — and
   * optional is the HONEST shape: the ext-host branch deliberately does
   * not wire this member (the documented `workflow`-port posture). A host
   * built at ≤v1.51 lacks it; a plugin guards
   * `host.notifications?.notify(...)` and activates normally without
   * notification capability.
   * @see {@link HostNotificationsBackend} / {@link HostNotificationInput}
   */
  readonly notifications?: HostNotificationsBackend;

  /**
   * ADDITIVE v1.55 (MINOR) — the `host.toolkits` skill-toolkit registration
   * namespace (change `third-party-tool-pack-channel`, module
   * `host-api/skill-toolkit.ts`). A plugin's main half registers ONE
   * {@link HostToolkitSpecLike} — name, description, SKILL.md body and a
   * function catalog — into the host's toolkit registry, so the model reaches
   * it through the host's existing `elftia_toolkit` MCP (`list_toolkits` /
   * `read_toolkit` / `skill_invoke`). This is the toolkit half of the
   * user-installable `kind:'tool-pack'` channel; the MCP half is the frozen v1
   * `registerMcpProviderFactory`.
   *
   * MINIMALITY: EXACTLY one verb, `register`. No list/read/invoke/
   * unregister-by-name — the host owns the registry and the user reaches it
   * through the host's own surfaces, not through the registering plugin.
   *
   * VALIDATED AT THE SEAM, REJECTED WHOLE: each function's `schema` is typed
   * `unknown` (no Zod in this dependency-light package), so the host
   * duck-types every declared function for a callable `safeParse` and refuses
   * the ENTIRE spec — naming plugin, toolkit and function — if any fails.
   * Registering anyway would route unvalidated model-supplied arguments into a
   * third-party handler in the main process.
   *
   * OPTIONAL (the same discipline as `toolHosts?` / `workflow?`) — and
   * optional is the HONEST shape, here for a CONCRETE reason rather than a
   * general one: the ext-host branch does NOT wire this member because the
   * host's per-invocation toolkit context carries live `logger` /
   * media-bridge object handles that are not wire-safe, so relaying a handler
   * would need callback proxying plus a per-handle boundary decision. A pack
   * that wants process isolation contributes MCP SERVERS (fully relayed
   * today); a pack contributing toolkits runs its handlers in the main
   * process — the same privilege its `activate` already has, so no new
   * privilege is granted, only no new isolation is gained. A host built at
   * ≤v1.54 lacks the member; a plugin guards `host.toolkits?.register(...)`
   * and activates normally without skill-toolkit capability.
   *
   * OWNER TEARDOWN IS HOST-DRAINED: the returned unregister handle is also fed
   * into the host's per-plugin teardown drain, so disabling or hot-toggling the
   * owner removes the toolkit even if the plugin never calls it. Teardown is a
   * REGISTRY REMOVAL, never a cancellation — an invocation already in flight
   * runs to completion; only the next one fails.
   *
   * The manifest side carries the `host:skill-toolkit` declaration token.
   * @see {@link HostToolkitsBackend} / {@link HostToolkitSpecLike}
   */
  readonly toolkits?: HostToolkitsBackend;
}

/**
 * The main-side `activate` signature a Tier-1 plugin exports. The loader
 * (Child I) calls it with the injected {@link AgentBackendHostApi}. Defined
 * here so the contract is anchored; the loader is out of scope.
 */
export type AgentBackendActivate = (host: AgentBackendHostApi) => void | Promise<void>;

/**
 * ADDITIVE v1.14 (MINOR) — the OPTIONAL main-side `deactivate` export a Tier-1
 * plugin MAY export (the Obsidian `onunload` analogue, the main twin of
 * {@link import('./renderer').AgentUiDeactivate}). The unload coordinator calls
 * it on disable, AFTER tearing down the host-side registrations (IPC methods,
 * session handlers / declared routes, MCP providers, owned streams), inside
 * try/catch (a throw is logged, never fatal).
 *
 * It takes NO arguments — the plugin already closed over its host in
 * `activate`. Use it to release the plugin's OWN side effects (a bare
 * `setInterval`, a `process.on` listener, a file watcher) that the host's
 * registration teardown cannot see. For an in-process (require-loaded) plugin
 * this is the honest backstop: the required module stays in the module cache,
 * so anything `deactivate` does not release survives until the next restart.
 * A plugin without it is disabled unchanged (the loader guards
 * `typeof mod.deactivate === 'function'`).
 *
 * Reentrancy: `activate(host)` MAY be called more than once in a single process
 * (re-enable after disable). Treat each `activate` call as a fresh start. See
 * the `── v1.14.0 ──` block in `./version` for the full reentrancy contract.
 *
 * MINIMALITY: zero-arg optional export; no new host surface, no required field.
 */
export type AgentBackendDeactivate = () => void | Promise<void>;
