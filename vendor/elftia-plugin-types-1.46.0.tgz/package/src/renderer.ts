/**
 * renderer.ts — `AgentUiHostApi` v1: the frozen TYPE of the object the
 * RENDERER host injects into a Tier-1 plugin's `activate(host)`.
 *
 * This module references DOM/React-shaped types (Decision D2). It MUST NOT
 * import `backend.ts`, and no symbol it exports may pull a Node/Electron type
 * into the renderer (DOM) context. The only cross-module dependency allowed is
 * the lib-agnostic `./version`.
 *
 * MINIMALITY (窄端口). This is an interface FREEZE, not an implementation. Each
 * member below carries a stability tier and the canonical SHIPPED mechanism it
 * exposes. The surface is exactly the 8 members the office-hours plan
 * (`agent-ui-extensions.md` §4) enumerates — no component registry, no
 * `window.native`, no bundled React. See the freeze checklist in `./version`.
 *
 * DELIBERATELY EXCLUDED (enumerated for the freeze review):
 *   - The full static `window.native` / `CHANNELS` surface — use scoped `ipc`.
 *   - A bundled React copy — `react` is a TYPE handle (Decision D4).
 *   - A dynamic `host.ui.get(name)` component registry — `ui` is a fixed typed
 *     handle (Decision D5).
 *   - Redefinition of the hello / page / workspace registries — the API only
 *     EXPOSES registration into the already-shipped ones (Decision D3).
 *   - Any loader / `plugin://` protocol / CSP / signature-verification member —
 *     that is Child H, out of scope.
 *
 * @module @elftia/plugin-types/renderer
 */
// Type-only import of React (Decision D4 / R2). `import type` is ERASED at
// build — it adds NO runtime dependency and bundles NO React copy. It resolves
// from the consuming app's `react` at type-check time. Used purely to type the
// `host.react.instance` handle as the whole React module shape (`typeof React`),
// so adding a new React hook later is not a breaking change to this contract.
import type * as React from 'react';

import type { HostComponentType, HostReactNode, HostUnregister } from './host-api/_shared';
import type { AgentUiHostAgent } from './host-api/agent';
import type { AgentUiAgentEvents, HostAgentStreamEvent } from './host-api/agent-events';
import type {
  HostAgentBackendDefinition,
  HostAgentsBackend,
  HostAgentSessionSetupFn,
  HostAgentSetupInput,
  HostAgentSetupResult,
  HostAgentSetupSpecComponents,
  HostAgentsUi,
  HostAgentUiDefinition,
} from './host-api/agents';
import type {
  HostArtifactBadge,
  HostArtifactEnvelope,
  HostArtifactErrorCode,
  HostArtifactKindDefinition,
  HostArtifactOpenOptions,
  HostArtifactOpenResult,
  HostArtifactRef,
  HostArtifactScope,
  HostArtifactsRenderer,
  HostArtifactState,
  HostArtifactSummary,
  HostArtifactSurfaceContext,
  HostArtifactSurfaceDefinition,
  HostArtifactSurfacePlacement,
  HostArtifactSurfaceProps,
  HostArtifactSurfaceRole,
  HostArtifactSurfaces,
  HostOpaqueArtifactLocator,
  HostSurfaceInteractionMode,
} from './host-api/artifacts';
import type { HostCapabilities, HostPetCapabilityConsumer } from './host-api/capabilities';
import type { AgentUiChatPanel, HostDesignCommentsTabContext } from './host-api/chatPanel';
import type { AgentUiHostComponents } from './host-api/components';
import type {
  HostLocalChannelClient,
  HostLocalChannelEvent,
  HostLocalChannelMessage,
  HostLocalChannels,
  HostLocalChannelSendResult,
  HostLocalChannelSnapshot,
  HostLocalChannelStatus,
  HostLocalChannelStreamEvent,
} from './host-api/local-channels';
import type {
  AgentUiMembership,
  ColorfulPurchaseCopy,
  ColorfulPurchaseRegistration,
} from './host-api/membership';
import type {
  AgentUiNewChat,
  HostNewChatDraft,
  HostNewChatDraftPatchContext,
  HostNewChatSubmitContext,
  HostPickedAgentLike,
  NewChatModalityDefinitionLike,
} from './host-api/new-chat';
import type {
  AgentUiPetRuntime,
  // ADDITIVE v1.53 — the settings-surface config patch re-export
  // (`desktop-pet-manager-page`); the barrel reaches pet types via this module.
  HostPetConfigPatch,
  HostPetFactEntryLike,
  HostPetFactsSnapshotLike,
  HostPetRuntimeConfig,
} from './host-api/pet-runtime';
import type { AgentUiCanvas, AgentUiDataPacks } from './host-api/platform-ipc';
import type {
  AgentUiProjectPlanning,
  HostPlanningDiagnosticLike,
  HostProjectPlanningStatusLike,
  ProjectPlanningPanelContext,
  ProjectPlanningSectionDefinitionLike,
} from './host-api/project-planning';
import type { HostQuickChatRegistry, HostQuickChatSurfaceDefinition } from './host-api/quick-chat';
import type {
  AgentUiSessionEffects,
  HostActiveArtifactPayload,
  HostSessionEffectContext,
  HostSessionEffectWorkspace,
  SessionEffectDefinitionLike,
} from './host-api/session-effects';
import type { AgentUiSessionKinds, SessionKindBehaviorLike } from './host-api/session-kinds';
import type { SessionGroupDefinitionLike } from './host-api/sessionGroup';
import type {
  AgentUiSettings,
  HostSettingsSectionContext,
  SettingsSectionDefinitionLike,
} from './host-api/settings';
import type { AgentUiHostStores } from './host-api/stores';
import type { HostApiCompat } from './version';

// Re-export the lib-agnostic structural primitives (extracted to
// `./host-api/_shared` to break the renderer.ts ↔ host-api/* import cycle —
// Decision D6). These three were ORIGINALLY defined inline in this module;
// re-exporting keeps the public exports byte-unchanged for existing consumers.
export type { HostComponentType, HostReactNode, HostUnregister };

// Re-export the ADDITIVE sibling types (v1.1 + v1.2 + v1.4 + v1.13 + v1.15 +
// v1.16) so they stay reachable from the `@elftia/plugin-types/renderer` module
// surface (barrel re-exports these).
export type {
  AgentUiAgentEvents,
  AgentUiCanvas,
  AgentUiChatPanel,
  AgentUiDataPacks,
  AgentUiHostAgent,
  AgentUiHostComponents,
  AgentUiHostStores,
  AgentUiMembership,
  AgentUiNewChat,
  // ADDITIVE v1.52 — the desktop-pet runtime port.
  AgentUiPetRuntime,
  AgentUiProjectPlanning,
  AgentUiSessionEffects,
  AgentUiSessionKinds,
  AgentUiSettings,
  ColorfulPurchaseCopy,
  ColorfulPurchaseRegistration,
  HostActiveArtifactPayload,
  HostAgentBackendDefinition,
  HostAgentsBackend,
  HostAgentSessionSetupFn,
  HostAgentSetupInput,
  HostAgentSetupResult,
  HostAgentSetupSpecComponents,
  HostAgentStreamEvent,
  HostAgentsUi,
  HostAgentUiDefinition,
  HostDesignCommentsTabContext,
  HostLocalChannelClient,
  HostLocalChannelEvent,
  HostLocalChannelMessage,
  HostLocalChannels,
  HostLocalChannelSendResult,
  HostLocalChannelSnapshot,
  HostLocalChannelStatus,
  HostLocalChannelStreamEvent,
  HostNewChatDraft,
  HostNewChatDraftPatchContext,
  HostNewChatSubmitContext,
  HostPetCapabilityConsumer,
  // ADDITIVE v1.52 — the pet facts snapshot / runtime-config structural bounds.
  // ADDITIVE v1.53 — the settings-surface config patch (`desktop-pet-manager-page`).
  HostPetConfigPatch,
  HostPetFactEntryLike,
  HostPetFactsSnapshotLike,
  HostPetRuntimeConfig,
  HostPickedAgentLike,
  HostPlanningDiagnosticLike,
  HostProjectPlanningStatusLike,
  HostQuickChatRegistry,
  HostQuickChatSurfaceDefinition,
  HostSessionEffectContext,
  HostSessionEffectWorkspace,
  HostSettingsSectionContext,
  NewChatModalityDefinitionLike,
  ProjectPlanningPanelContext,
  ProjectPlanningSectionDefinitionLike,
  SessionEffectDefinitionLike,
  SessionGroupDefinitionLike,
  SessionKindBehaviorLike,
  SettingsSectionDefinitionLike,
};

// Re-export the ADDITIVE v1.48 artifact sibling types the same way, so the
// renderer-relevant `host.artifacts` contract is reachable from the `renderer`
// module surface. The MAIN-half behavioral types (`HostArtifactsMain`,
// `HostArtifactKindProvider`, `HostArtifactContext`, the storage port) are
// deliberately NOT re-exported here — they belong to the backend module
// surface (design §37 D3).
export type {
  HostArtifactBadge,
  HostArtifactEnvelope,
  HostArtifactErrorCode,
  HostArtifactKindDefinition,
  HostArtifactOpenOptions,
  HostArtifactOpenResult,
  HostArtifactRef,
  HostArtifactScope,
  HostArtifactsRenderer,
  HostArtifactState,
  HostArtifactSummary,
  HostArtifactSurfaceContext,
  HostArtifactSurfaceDefinition,
  HostArtifactSurfacePlacement,
  HostArtifactSurfaceProps,
  HostArtifactSurfaceRole,
  HostArtifactSurfaces,
  HostOpaqueArtifactLocator,
  HostSurfaceInteractionMode,
};

// ───────────────────────────────────────────────────────────────────────────
// Structural shapes for the already-shipped registries (Decision D3)
//
// These mirror the renderer's canonical contracts STRUCTURALLY so this package
// does not depend on renderer source. Each shape is a faithful LOWER BOUND: it
// PINS the REQUIRED identity members the real store demands (so a plugin gets
// day-one compile-time safety — a def missing them would be rejected by the
// real registry), while leaving the rest `[key: string]: unknown` so the freeze
// does not lock a renderer-owned contract's full field set into this package.
// Child H wires the nominal identity. We deliberately do NOT relocate the
// canonical types into this package (that would be an out-of-scope relocation —
// see design.md "Trade-off: structural (not nominal) registry shapes").
// ───────────────────────────────────────────────────────────────────────────

// `HostReactNode` is defined in `./host-api/_shared` (Decision D6) and
// re-exported above — used structurally throughout this module.

/**
 * Structural LOWER BOUND of the shipped `AgentHelloDefinition`.
 *
 * Pins the three REQUIRED identity members the real def demands —
 * `agentIds`, `key`, and `HelloComponent` — so a plugin that omits any of them
 * fails to compile (matching what `registerAgentHello` would reject at runtime).
 * Everything else stays opaque (`[key: string]: unknown`).
 *
 * `HelloComponent` is typed as a `React.ComponentType` (faithful: the real type
 * is `ComponentType<AgentHelloComponentProps>`; the props contract is
 * renderer-owned and left opaque here, so the type is a lower bound not a full
 * validator).
 *
 * @remarks Canonical source: `renderer/src/shared/state/agentHelloStore.types.ts`
 *   (`AgentHelloDefinition`, re-exported from `agentHelloStore.ts`). Backed by
 *   `registerAgentHello(def)`. Child H supplies the nominal type at wiring time.
 * @stability frozen (identity members pinned; the BACKING fn is the contract)
 */
export interface AgentHelloDefinitionLike {
  /** Agent ids this hello def is registered under (one def may own several). */
  readonly agentIds: readonly string[];
  /** Stable React mount key — switching agents remounts the host. REQUIRED. */
  readonly key: string;
  /**
   * The component the host mounts for this agent's hello surface. REQUIRED.
   * Real type: `ComponentType<AgentHelloComponentProps>` (props opaque here).
   */
  readonly HelloComponent: React.ComponentType<Record<string, unknown>>;
  /**
   * Remaining members are intentionally opaque — see canonical source. The
   * plugin constructs a full def and the host registers it via
   * `registerAgentHello`.
   */
  readonly [key: string]: unknown;
}

/**
 * Structural LOWER BOUND of the shipped `WorkspaceDefinition`.
 *
 * Pins the REQUIRED identity members the real def demands — `view`,
 * `isAvailable`, and `render` — so a plugin that omits any of them fails to
 * compile (matching what `registerWorkspace` would reject). `onClose` is
 * optional in the real def and omitted here (left to the opaque index). The
 * `ctx`/`cb` params are renderer-owned and typed opaquely (lower bound).
 *
 * @remarks Canonical source: `renderer/src/shared/state/workspaceStore.ts`
 *   (`WorkspaceDefinition`). Backed by `registerWorkspace(def)`.
 * @stability frozen (identity members pinned; the BACKING fn is the contract)
 */
export interface WorkspaceDefinitionLike {
  /** Stable workspace view identifier (the `WorkspaceView` literal). REQUIRED. */
  readonly view: string;
  /** Gate whether this workspace is active for the host context. REQUIRED. */
  isAvailable(ctx: unknown): boolean;
  /** Render the workspace body for `(ctx, cb)`. REQUIRED. */
  render(ctx: unknown, cb: unknown): HostReactNode;
  /**
   * ADDITIVE v1.18 OPTIONAL (MINOR) — preview-toggle metadata
   * (`ds-extract-1c-kind-generalize` design D5). When the ACTIVE workspace
   * declares it, the host toolbar renders a generic flip control between this
   * workspace's `view` and `altView`, labeled by the host-resolved i18n keys.
   * Absent ⇒ no toggle (prior behavior). See {@link HostWorkspacePreviewToggle}.
   */
  readonly previewToggle?: HostWorkspacePreviewToggle;
  /** Remaining members (onClose, …) are opaque — see source. */
  readonly [key: string]: unknown;
}

/**
 * ADDITIVE v1.18 — declarative preview-toggle metadata a workspace definition
 * MAY carry (consumed by the host `WorkspaceToolbar`; replaces the former
 * hardcoded design↔html flip).
 */
export interface HostWorkspacePreviewToggle {
  /** The alternate view the toggle flips to (e.g. `'htmlPreview'`). */
  readonly altView: string;
  /** i18n key for the "switch to altView" tooltip (host-resolved). */
  readonly toLabelKey: string;
  /** i18n key for the "switch back to this view" tooltip (host-resolved). */
  readonly fromLabelKey: string;
  /** Optional testid for the toggle button (agent-testable-ui contract). */
  readonly testId?: string;
}

/**
 * Structural shape of an agent-page code registration (FORWARD-ANCHORED).
 *
 * Pins the REQUIRED identity members (`id`, `label`, `render`). Unlike
 * hello/workspace, the `ui.page` host is currently MANIFEST-DERIVED only
 * (`features/agents/hooks/useAgentPageRailItems.ts`,
 * `features/agents/components/agent-page/`) — a CODE-registration store
 * (mirroring `agentHelloStore`) does not exist yet; Child H builds it. This
 * type freezes the `page.register` shape now; the backing store lands with the
 * loader. Flagged for the freeze review as the only handle without a
 * fully-shipped backing store today (design.md OQ list).
 *
 * ADDITIVE-ONLY ARG CONTRACT (M3): `render()` takes NO required arguments in
 * v1. Because the backing store is forward-anchored (Tier-1-forward), future
 * host context MAY be supplied to `render` (and to any future method on this
 * handle) ONLY as OPTIONAL arguments — a new optional `render(ctx?)` is a MINOR
 * bump that does not break an existing zero-arg `render`. Never add a REQUIRED
 * argument (that is a MAJOR break — see the freeze checklist in `./version`).
 *
 * @stability frozen (identity members pinned; arg lists are additive-only)
 */
export interface AgentPageDefinitionLike {
  /** Stable page id (namespaced `agent-page:<agentId>` by the host). REQUIRED. */
  readonly id: string;
  /** Rail label (locale-resolved by the plugin, never an i18n key). REQUIRED. */
  readonly label: string;
  /**
   * Render the page body. Takes no host args in v1; future host context is
   * additive-only (optional args only — see the ADDITIVE-ONLY ARG CONTRACT
   * note above). REQUIRED.
   */
  render(): HostReactNode;
  // ── ADDITIVE v1.18 OPTIONAL legacy-alias fields (MINOR; absent ⇒ prior
  // behavior; `ds-extract-1c-kind-generalize` design D4). They let a plugin
  // page reproduce a pre-decoupling host shim as DATA: the host route/rail
  // build consumes them generically (no per-page literal in host code).
  /**
   * Legacy deep-link route that resolves to this agent page (e.g.
   * `'/design-studio'`). The host keeps the path valid (bookmark / external
   * link → this page's tab binding).
   */
  readonly legacyPath?: string;
  /**
   * Legacy `railItemVisibility` key honored IN ADDITION to the namespaced
   * `agent-page:<id>` key, so a pre-decoupling "hidden" preference carries
   * over (e.g. `'design-studio'`).
   */
  readonly legacyVisibilityKey?: string;
  /**
   * Rail testid override (agent-testable-ui contract), replacing the default
   * `sidebar-agent-page-<id>` (e.g. `'sidebar-design-studio'`).
   */
  readonly railTestId?: string;
  /**
   * Legacy `?new=<value>` new-chat query-param value that redirects to this
   * page's `legacyPath` (e.g. `'design'` for the historic `/chat?new=design`).
   * Only meaningful together with `legacyPath`.
   */
  readonly legacyNewChatParam?: string;
  /** Remaining members (icon, ordering, …) are opaque — see source. */
  readonly [key: string]: unknown;
}

// ───────────────────────────────────────────────────────────────────────────
// UI primitives (Decision D5) — TYPE references only, exactly 7, additive-only
//
// Structural prop shapes so this package depends on no renderer source; the
// CONCRETE components are injected by the loader (Child H) from `@/components/ui`.
// Each prop shape is anchored to its canonical component source.
// ───────────────────────────────────────────────────────────────────────────

// `HostComponentType<P>` is defined in `./host-api/_shared` (Decision D6) and
// re-exported above — used to type each UI primitive below.

/**
 * Props for `host.ui.Button`.
 * @remarks Canonical: `@/components/ui/button` (Button = button element attrs +
 *   `variant` / `size` cva variants).
 */
export interface HostButtonProps {
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'subtle' | 'link';
  size?: 'default' | 'xs' | 'sm' | 'lg' | 'icon';
  className?: string;
  disabled?: boolean;
  onClick?: (event: unknown) => void;
  children?: HostReactNode;
  [key: string]: unknown;
}

/**
 * Props for `host.ui.Dialog` (the open/controlled root).
 * @remarks Canonical: `@/components/ui/dialog` (Radix `Dialog.Root`).
 */
export interface HostDialogProps {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  children?: HostReactNode;
}

/**
 * Props for `host.ui.DialogContent`.
 * @remarks Canonical: `@/components/ui/dialog` (`DialogContent`).
 */
export interface HostDialogContentProps {
  className?: string;
  hideCloseButton?: boolean;
  children?: HostReactNode;
  [key: string]: unknown;
}

/** A single option in `host.ui.Select`. @remarks Canonical: `@/components/ui/select`. */
export interface HostSelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

/**
 * Props for `host.ui.Select` (the project's options-array API — native
 * `<select>` is forbidden per renderer CLAUDE.md).
 * @remarks Canonical: `@/components/ui/select` (`SelectPropsNew`).
 */
export interface HostSelectProps {
  value: string;
  onChange: (value: string) => void;
  options: HostSelectOption[];
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  id?: string;
  size?: 'sm' | 'default';
}

/**
 * Props for `host.ui.ConfirmDialog` (replaces `window.confirm`).
 * @remarks Canonical: `@/components/ui/confirm-dialog` (`ConfirmDialogProps`).
 */
export interface HostConfirmDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'destructive' | 'default';
  onConfirm: () => void;
}

/**
 * Props for `host.ui.Input` (native `<input>` is forbidden).
 * @remarks Canonical: `@/components/ui/input` (input attrs + `density`).
 */
export interface HostInputProps {
  value?: string;
  defaultValue?: string;
  onChange?: (event: unknown) => void;
  placeholder?: string;
  disabled?: boolean;
  type?: string;
  density?: 'default' | 'compact';
  className?: string;
  [key: string]: unknown;
}

/**
 * Props for `host.ui.Switch` (native checkbox is forbidden).
 * @remarks Canonical: `@/components/ui/switch` (`SwitchProps`).
 */
export interface HostSwitchProps {
  checked?: boolean;
  defaultChecked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
  disabled?: boolean;
  className?: string;
  id?: string;
  name?: string;
}

/**
 * Props for `host.ui.DropdownMenu` (the Radix root; sub-parts are accessed via
 * children the host wires from `@/components/ui/dropdown-menu`).
 * @remarks Canonical: `@/components/ui/dropdown-menu` (`DropdownMenu` root).
 */
export interface HostDropdownMenuProps {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  children?: HostReactNode;
}

// ── ADDITIVE v1.1 primitives (Decision D3 — MINOR; SET grows 8 → 11) ─────────

/**
 * Props for `host.ui.Badge`.
 * @remarks Canonical: `@/components/ui/badge` (div attrs + `variant`).
 */
export interface HostBadgeProps {
  variant?: 'default' | 'secondary' | 'destructive' | 'outline' | 'success';
  className?: string;
  children?: HostReactNode;
  [key: string]: unknown;
}

/**
 * Props for `host.ui.Slider` (range input, options-array API).
 * @remarks Canonical: `@/components/ui/slider` (`SliderProps`).
 */
export interface HostSliderProps {
  value?: number[];
  defaultValue?: number[];
  onValueChange?: (value: number[]) => void;
  min?: number;
  max?: number;
  step?: number;
  disabled?: boolean;
  className?: string;
  id?: string;
}

/**
 * Props for `host.ui.Tooltip`.
 * @remarks Canonical: `@/components/ui/Tooltip` (`TooltipProps`, default export).
 */
export interface HostTooltipProps {
  children: HostReactNode;
  content?: HostReactNode;
  position?: 'top' | 'bottom' | 'left' | 'right';
  className?: string;
  delay?: number;
}

/**
 * The fixed, SMALL typed handle of project UI primitives a plugin may use over
 * native controls (renderer CLAUDE.md mandate). Components are injected by the
 * loader from `@/components/ui`. Additive-only: a new primitive is a MINOR bump
 * (see freeze checklist).
 *
 * v1 froze the SET at 8 (`Button`…`DropdownMenu`). v1.1 ADDITIVELY grew it to
 * 11 (`Badge` / `Slider` / `Tooltip` — MINOR per the freeze checklist; the
 * original 8 are byte-unchanged).
 *
 * @stability frozen (the original 8 are byte-unchanged; additions are MINOR)
 */
export interface AgentUiPrimitives {
  /** @remarks `@/components/ui/button`. */
  Button: HostComponentType<HostButtonProps>;
  /** @remarks `@/components/ui/dialog` (`Dialog`). */
  Dialog: HostComponentType<HostDialogProps>;
  /** @remarks `@/components/ui/dialog` (`DialogContent`). */
  DialogContent: HostComponentType<HostDialogContentProps>;
  /** @remarks `@/components/ui/select`. */
  Select: HostComponentType<HostSelectProps>;
  /** @remarks `@/components/ui/confirm-dialog`. */
  ConfirmDialog: HostComponentType<HostConfirmDialogProps>;
  /** @remarks `@/components/ui/input`. */
  Input: HostComponentType<HostInputProps>;
  /** @remarks `@/components/ui/switch`. */
  Switch: HostComponentType<HostSwitchProps>;
  /** @remarks `@/components/ui/dropdown-menu` (`DropdownMenu` root). */
  DropdownMenu: HostComponentType<HostDropdownMenuProps>;
  /** ADDITIVE v1.1 (MINOR). @remarks `@/components/ui/badge`. */
  Badge: HostComponentType<HostBadgeProps>;
  /** ADDITIVE v1.1 (MINOR). @remarks `@/components/ui/slider`. */
  Slider: HostComponentType<HostSliderProps>;
  /** ADDITIVE v1.1 (MINOR). @remarks `@/components/ui/Tooltip`. */
  Tooltip: HostComponentType<HostTooltipProps>;
}

// ───────────────────────────────────────────────────────────────────────────
// Registration handles (Decision D3)
// ───────────────────────────────────────────────────────────────────────────

// `HostUnregister` is defined in `./host-api/_shared` (Decision D6) and
// re-exported above — the return type of every register/subscribe handle.

/**
 * Registration handles into the three already-shipped registries. The API
 * EXPOSES registration; it does NOT redefine the registries (Decision D3).
 *
 * @stability frozen
 */
export interface AgentUiRegistrationHandles {
  hello: {
    /**
     * Register a hello surface for the plugin's agent ids.
     * @remarks Routes to `registerAgentHello(def)` →
     *   `useAgentHelloRegistry.getState().register`
     *   (`renderer/src/shared/state/agentHelloStore.ts`).
     */
    register(def: AgentHelloDefinitionLike): HostUnregister;
  };
  workspace: {
    /**
     * Register a workspace type for the plugin.
     * @remarks Routes to `registerWorkspace(def)` →
     *   `useWorkspaceRegistry.getState().register`
     *   (`renderer/src/shared/state/workspaceStore.ts`).
     */
    register(def: WorkspaceDefinitionLike): HostUnregister;
  };
  page: {
    /**
     * Register a top-level agent page (rail tab) by CODE.
     * @remarks FORWARD-ANCHORED — backed by the agent-page host
     *   (`features/agents/components/agent-page/`, currently manifest-derived
     *   via `useAgentPageRailItems`). Child H adds the matching code-registration
     *   store mirroring `agentHelloStore`. See {@link AgentPageDefinitionLike}.
     */
    register(def: AgentPageDefinitionLike): HostUnregister;
  };
}

// ───────────────────────────────────────────────────────────────────────────
// Scoped IPC (Decision D6)
// ───────────────────────────────────────────────────────────────────────────

/**
 * Per-plugin scoped IPC handle. Mirrors the preload `invoke` call shape
 * (`packages/desktop/app/preload/namespaces/_invoke.ts`) but routes through the
 * FUTURE generic `plugins:invoke` / `plugins:event` channels (Child I), with
 * the plugin's `pluginId` injected by the HOST so a plugin cannot forge another
 * plugin's namespace. It deliberately does NOT expose the full static
 * `window.native` (`CHANNELS`-generated) surface (Decision D6 / 窄端口).
 *
 * @stability frozen
 */
export interface AgentUiScopedIpc {
  /**
   * Invoke a main-side method the plugin registered via
   * `AgentBackendHostApi.registerIpcMethods`. `method` is the bare name within
   * the plugin's own namespace; the host prefixes `pluginId` and routes via
   * `plugins:invoke`.
   */
  invoke<TResult = unknown>(method: string, payload?: unknown): Promise<TResult>;
  /**
   * Subscribe to a plugin-scoped event pushed from main (via `plugins:event`).
   * Returns an unsubscribe function.
   */
  on<TPayload = unknown>(event: string, cb: (payload: TPayload) => void): HostUnregister;
  /** Remove a previously-registered event listener. */
  off<TPayload = unknown>(event: string, cb: (payload: TPayload) => void): void;
}

// ───────────────────────────────────────────────────────────────────────────
// i18n + theme (Decision D7)
// ───────────────────────────────────────────────────────────────────────────

/**
 * i18n registration handle. A plugin contributes its OWN locale bundle under a
 * `pluginId`-prefixed namespace, so it renders its own strings and never the
 * renderer's i18n keys (consistent with "Package-loaded agents render manifest
 * name/description directly").
 *
 * @stability frozen
 */
export interface AgentUiI18n {
  /**
   * Register a locale resource bundle under the plugin's namespace. The host
   * prefixes the plugin's `pluginId`, so `namespace` is plugin-local.
   * @param namespace plugin-local namespace segment.
   * @param resources locale → flat/nested key map.
   */
  registerNamespace(
    namespace: string,
    resources: Record<string, Record<string, unknown>>
  ): HostUnregister;
}

/**
 * Resolved theme tokens snapshot (read-only). Mirrors the value shape exposed
 * by `themeStore`'s `getThemeSnapshot()`; kept opaque/extensible so the frozen
 * surface does not lock the full token list. Plugin UI consumes semantic tokens,
 * never hardcoded colors (renderer CLAUDE.md).
 */
export interface HostThemeSnapshot {
  /** Resolved light/dark mode. */
  readonly resolvedMode: 'light' | 'dark';
  /** Whether the resolved mode is dark (convenience mirror). */
  readonly isDarkMode: boolean;
  /** Remaining resolved token fields are extensible — read via CSS variables. */
  readonly [key: string]: unknown;
}

/**
 * Theme read handle: a resolved-tokens snapshot + subscribe. Mirrors
 * `themeStore`'s `getThemeSnapshot()` / `subscribeTheme()`
 * (`renderer/src/shared/state/themeStore.ts`). READ-only — a plugin reads tokens
 * and reacts to mode flips; it does not mutate global theme.
 *
 * @stability frozen
 */
export interface AgentUiTheme {
  /** Read the current resolved theme tokens. Mirrors `getThemeSnapshot()`. */
  getSnapshot(): HostThemeSnapshot;
  /**
   * Subscribe to theme changes (mode flip, token edits). Returns an
   * unsubscribe function. Mirrors `subscribeTheme(listener)`.
   */
  subscribe(listener: (snapshot: HostThemeSnapshot) => void): HostUnregister;
}

// ───────────────────────────────────────────────────────────────────────────
// React handle (Decision D4 / R2)
// ───────────────────────────────────────────────────────────────────────────

/**
 * The host's React instance handle.
 *
 * The plugin MUST mark `react` and `react-dom` as build EXTERNALS and consume
 * `host.react` — bundling its own React causes the dual-instance hazard (hooks
 * throw, context mismatches). This is a TYPE (`typeof import('react')`), never a
 * bundled copy: this package has no `react` runtime dependency, so it cannot
 * ship one. The companion `version` lets the loader (Child H) / plugin template
 * probe at `activate()` time.
 *
 * `typeof import('react')` (the whole module shape) is used instead of
 * re-exporting a hand-picked hook subset, so adding e.g. `useSyncExternalStore`
 * later is NOT a breaking change to this contract (Decision D4).
 *
 * @stability frozen
 */
export interface AgentUiReactHandle {
  /**
   * The shared React module instance — the SAME instance the host renders with.
   * Typed as `typeof React` via a TYPE-ONLY `import type * as React` (erased at
   * build, no runtime dep, no bundled copy) — equivalent to
   * `typeof import('react')` but lint-clean.
   */
  instance: typeof React;
  /** The host's React version, for probe/assert at `activate()` time (R2). */
  version: string;
}

// ───────────────────────────────────────────────────────────────────────────
// AgentUiHostApi — renderer surface (v1: 8 frozen; v1.1: +4; v1.2: +2 additive)
// ───────────────────────────────────────────────────────────────────────────

/**
 * `AgentUiHostApi` — the TYPE of the object the RENDERER host injects into a
 * Tier-1 plugin's `activate(host)`.
 *
 * v1 (frozen, byte-unchanged) — 8 members (窄端口):
 *   1. `react`      — shared React instance handle (D4 / R2)
 *   2. `ui`         — fixed UI component handle (D5; SET grew 8 → 11 in v1.1)
 *   3. `hello`      — register into the agent-hello registry (D3)
 *   4. `workspace`  — register into the workspace registry (D3)
 *   5. `page`       — register a top-level agent page, code path (D3, forward-anchored)
 *   6. `ipc`        — per-plugin scoped invoke/on/off (D6)
 *   7. `i18n`       — register a pluginId-prefixed locale namespace (D7)
 *   8. `theme`      — read resolved theme tokens + subscribe (D7)
 *
 * v1.1 (ADDITIVE, MINOR) — 4 members:
 *   9.  `sessionGroup` — register a sidebar session-group descriptor (Child-J)
 *   10. `stores`       — narrow per-store ports into 5 host data stores
 *   11. `canvas`       — typed forward to the host `canvas` IPC namespace (F1)
 *   12. `dataPacks`    — typed forward to the host `dataPacks` IPC namespace (F1)
 *
 * v1.2 (ADDITIVE, MINOR) — 2 members:
 *   13. `agent`      — narrow port into the host agent IPC client (`@/shared/agent`)
 *   14. `components` — host-provided React feature bodies (CodeEditor/DevPreview/
 *                      MediaHoverCard), distinct from `ui` primitives
 *
 * v1.4 (ADDITIVE, MINOR) — 1 member:
 *   15. `chatPanel`  — register the design-session Comments tab renderer
 *                      (`designCommentsTabStore`, single-slot IoC)
 *
 * v1.13 (ADDITIVE, MINOR) — 1 member:
 *   16. `newChat`    — register a new-chat MODALITY (draft lifecycle + submit
 *                      dispatch) keyed by agent ids (`newChatModalityStore`)
 *
 * v1.15 (ADDITIVE, MINOR) — 1 member:
 *   17. `agentEvents` — subscribe to the host's per-session `agent:event`
 *                       stream (`subscribe(listener): HostUnregister`; forwards
 *                       to the host `agent.onEvent` IPC subscription)
 *
 * v1.16 (ADDITIVE, MINOR) — 1 member:
 *   18. `sessionEffects` — register a PAGE-LEVEL effect the host mounts while a
 *                       session of a declared `kind` is active
 *                       (`registerSessionEffect(def): HostUnregister`; backed by
 *                       the host `sessionEffectStore`; the host owns the
 *                       page-level mount lifecycle, surviving slot remounts)
 *
 * v1.36 (ADDITIVE, MINOR) — 1 member:
 *   19. `membership`  — register the Colorful-purchase registration the core upsell
 *                       dialog invokes + renders (`registerColorfulPurchase(
 *                       { purchase, copy? }): HostUnregister`; backed by the host
 *                       `colorfulPurchaseStore`, single-slot IoC; the channel-gated
 *                       plugin supplies the purchase flow AND its copy, core renders
 *                       a channel-NEUTRAL fallback so it never names Steam)
 *
 * Plus `version` (the running {@link import('./version').HOST_API_VERSION}) and
 * `compat` so the plugin can assert the host it received.
 *
 * @stability frozen — see the freeze checklist in `./version`. The original 8
 *   members + the original 8 UI primitives are byte-unchanged; v1.1/v1.2/v1.4/
 *   v1.13/v1.15/v1.16 additive (v1.3 added the `errorMessage` field on the
 *   htmlPreview snapshot).
 */
export interface AgentUiHostApi {
  /** The running host-API version string (the injected `HOST_API_VERSION`). */
  readonly version: string;
  /** Compatibility descriptor the host computed for this plugin (R1 gate). */
  readonly compat: HostApiCompat;
  /** Member 1 — shared React instance handle. */
  readonly react: AgentUiReactHandle;
  /** Member 2 — fixed UI component handle (11 primitives after v1.1). */
  readonly ui: AgentUiPrimitives;
  /** Members 3–5 — registration into the three shipped registries. */
  readonly hello: AgentUiRegistrationHandles['hello'];
  readonly workspace: AgentUiRegistrationHandles['workspace'];
  readonly page: AgentUiRegistrationHandles['page'];
  /** Member 6 — per-plugin scoped IPC. */
  readonly ipc: AgentUiScopedIpc;
  /** Member 7 — i18n namespace registration. */
  readonly i18n: AgentUiI18n;
  /** Member 8 — theme read handle. */
  readonly theme: AgentUiTheme;

  // ── ADDITIVE v1.1 members (MINOR per the freeze checklist) ────────────────

  /**
   * ADDITIVE v1.1 (MINOR) — register a sidebar session-group descriptor.
   * Routes to `registerSessionGroup` (`sessionGroupStore`, the Child-J registry,
   * which shipped AFTER the original four-registry freeze). NOT part of the
   * frozen v1 four-registry set. See {@link SessionGroupDefinitionLike}.
   */
  readonly sessionGroup: {
    register(def: SessionGroupDefinitionLike): HostUnregister;
  };
  /**
   * ADDITIVE v1.1 (MINOR) — NARROW per-store ports into the host data stores a
   * first-party code plugin reads and/or writes. Each port exposes ONLY the
   * audited members (read = snapshot + subscribe, the `projectThemeSnapshot`
   * precedent; write = forwarded audited mutators), never the whole store
   * (窄端口). See {@link AgentUiHostStores}.
   */
  readonly stores: AgentUiHostStores;
  /**
   * ADDITIVE v1.1 (MINOR) — typed forward to the host `canvas` IPC namespace
   * (`@/shared/ipc/canvas` → `window.native.canvas`). Routers UNCHANGED; no
   * `plugins:invoke` reroute. See {@link AgentUiCanvas}.
   */
  readonly canvas: AgentUiCanvas;
  /**
   * ADDITIVE v1.1 (MINOR) — typed forward to the host `dataPacks` IPC namespace
   * (`@/shared/ipc/dataPacks` → `window.native.dataPacks`). Routers UNCHANGED;
   * no `plugins:invoke` reroute. See {@link AgentUiDataPacks}.
   */
  readonly dataPacks: AgentUiDataPacks;

  // ── ADDITIVE v1.2 members (MINOR per the freeze checklist) ────────────────

  /**
   * ADDITIVE v1.2 (MINOR) — NARROW port into the host agent IPC client
   * (`@/shared/agent`): the general session/file/model-resolution operations DS
   * reuses (`chatSessions.{list,create,update}`, `files.read`,
   * `resolveCodeCliBackend`). NOT the 39 `design:*` channels (those reach main
   * via `ipc.invoke`), NOT the whole agent API (窄端口). See {@link AgentUiHostAgent}.
   */
  readonly agent: AgentUiHostAgent;
  /**
   * ADDITIVE v1.2 (MINOR) — host-PROVIDED React feature bodies the plugin embeds
   * but cannot vendor without dragging heavy host deps into its chunk
   * (`CodeEditor` = codemirror; `DevPreviewPanel` = host dev-server machinery;
   * `MediaHoverCard`). DISTINCT from `ui` (the small mandated PRIMITIVES) — these
   * are heavier FEATURE bodies, rendered against `host.react` (one React
   * instance). Justified by the chunk-size hazard. See {@link AgentUiHostComponents}.
   */
  readonly components: AgentUiHostComponents;

  // ── ADDITIVE v1.4 member (MINOR per the freeze checklist) ─────────────────

  /**
   * ADDITIVE v1.4 (MINOR) — register the design-session Comments tab renderer.
   * Routes to `registerDesignCommentsTab` (`designCommentsTabStore`, the
   * single-slot IoC registry, last-registration-wins; `ChatSessionPage` resolves
   * the renderer for `kind='design'` sessions). A first-party TRANSITIONAL
   * register handle (the host genuinely has a single design-comments slot; may be
   * generalized later additively). See {@link AgentUiChatPanel}.
   */
  readonly chatPanel: AgentUiChatPanel;

  // ── ADDITIVE v1.13 member (MINOR per the freeze checklist) ────────────────

  /**
   * ADDITIVE v1.13 (MINOR) — register a new-chat MODALITY: a generic,
   * registry-driven contribution that owns the new-chat draft lifecycle
   * (`createInitialDraft` / `resetDraft` / `applyPrefill`) + the `submit(ctx)`
   * dispatch for the agent ids it declares. Routes to
   * `registerNewChatModality` (`newChatModalityStore`, last-registration-wins
   * per agent id). MINIMALITY: the port owns draft lifecycle + submit dispatch
   * only; rendering stays handled by the existing `host.hello` registry — the
   * resolved modality's draft bag flows into the active hello entry's
   * `ctx.draft` verbatim. This generalizes the host's previously-hardcoded
   * "design modality" new-chat path so EVERY plugin (not just Design Studio)
   * can contribute a new-chat entry. See {@link AgentUiNewChat}.
   */
  readonly newChat: AgentUiNewChat;

  // ── ADDITIVE v1.15 member (MINOR per the freeze checklist) ────────────────

  /**
   * ADDITIVE v1.15 (MINOR) — subscribe to the host's per-session `agent:event`
   * stream. `subscribe(listener): HostUnregister` forwards to the host
   * `agent.onEvent` IPC subscription (the channel the preload exposes as
   * `window.native.agent.onEvent` / `CHANNELS.agent.onEvent`); the IPC channel,
   * routers, and main-side emission are UNCHANGED. The listener receives a
   * {@link HostAgentStreamEvent} structural lower bound (pinning only the
   * `type`/`sessionId?`/`delta?` fields the design `<artifact>` stream consumer
   * reads). MINIMALITY: a single-purpose PUSH port (the `host.stores` /
   * `host.canvas` subscription precedent) — NO request/response, no per-session
   * filter argument (the consumer filters by `sessionId` client-side), no host
   * IPC object. See {@link AgentUiAgentEvents}.
   */
  readonly agentEvents: AgentUiAgentEvents;

  // ── ADDITIVE v1.16 member (MINOR per the freeze checklist) ────────────────

  /**
   * ADDITIVE v1.16 (MINOR) — register a PAGE-LEVEL session effect the host
   * mounts at its chat-page level while a session of the def's declared `kind`
   * is active (e.g. `'design'`). `registerSessionEffect(def): HostUnregister`
   * routes to the host `sessionEffectStore` (per-kind last-registration-wins).
   * The def pins `kind` + an `Effect` component the host mounts (keyed on
   * `(kind, sessionId)`) — so the effect SURVIVES workspace-slot remounts, the
   * load-bearing property no slot/panel-level register surface
   * (`hello`/`workspace`/`page`/`sessionGroup`/`chatPanel`/`newChat`) provides.
   * The host passes the effect a {@link HostSessionEffectContext} pinning the
   * per-session inputs (`sessionId`/`projectRoot`/`projectId`/`sourceSkillId?`/
   * `designSystemId?`/`mode?`) + a narrow `workspace` affordance
   * (`setView`/`setVisible`/`setActiveArtifact`). MINIMALITY: a single
   * registration verb (the `host.hello`/`workspace`/`sessionGroup` precedent) —
   * no host store object, no React handle, no per-frame callback. See
   * {@link AgentUiSessionEffects}.
   */
  readonly sessionEffects: AgentUiSessionEffects;

  // ── ADDITIVE v1.18 member (MINOR per the freeze checklist) ────────────────

  /**
   * ADDITIVE v1.18 (MINOR) — register a per-sessionType BEHAVIOR record
   * (`register(behavior): HostUnregister`). Routes to the host
   * `sessionKindStore` (per-kind last-registration-wins). The host's chat /
   * panel surfaces consult the registered flags (`agentLike` /
   * `inputProfile` / `organizerBucket` /
   * `stripInlineArtifacts`) instead of hardcoded `sessionType === '<kind>'`
   * literals; no registration ⇒ all flags falsy ⇒ plain-chat degradation.
   * (Workspace binding is NOT a sessionKind concern — it is agent-keyed via
   * the agent's `workspacePreview`, resolved through the workspace registry.)
   * MINIMALITY: one registration verb carrying a data record — no host store
   * object or callback crosses (the flags live in host stores a plugin cannot
   * reach through any existing surface). See {@link AgentUiSessionKinds}.
   */
  readonly sessionKinds: AgentUiSessionKinds;

  // ── ADDITIVE v1.20 member (MINOR per the freeze checklist) ────────────────

  /**
   * ADDITIVE v1.20 (MINOR) — register a SETTINGS SECTION (one nav entry + one
   * panel) the host renders in its settings page.
   * `registerSection(def): HostUnregister` routes to the host
   * `settingsSectionStore` (`registerSettingsSection`), with the plugin's
   * `pluginId` injected by the host factory and the entry keyed by the
   * namespaced id `plugin:<pluginId>:<sectionId>` — a plugin can never forge
   * another plugin's section namespace. The settings page appends a dynamic
   * nav group AFTER its built-in groups and renders the section's panel
   * lazily inside the host plugin error boundary. MINIMALITY: one
   * registration verb (the `hello`/`workspace`/`sessionGroup`/`newChat`/
   * `sessionKinds` precedent) — nav placement, lazy-mount, and error
   * isolation stay host-owned; no host store object crosses. See
   * {@link AgentUiSettings}.
   */
  readonly settings: AgentUiSettings;

  // ── ADDITIVE v1.36 member (MINOR per the freeze checklist) ────────────────

  /**
   * ADDITIVE v1.36 (MINOR) — register the Colorful-purchase registration the core
   * upsell dialog invokes + renders. `registerColorfulPurchase(registration):
   * HostUnregister` routes to the host `colorfulPurchaseStore` (single-slot
   * last-registration-wins; the `chatPanel`/`designCommentsTabStore` IoC
   * precedent). The channel-gated plugin SUPPLIES both the purchase behavior
   * (`registration.purchase` — open the DLC store + poll ownership) AND its COPY
   * (`registration.copy` — CTA / intro / pending thunks, plugin i18n); the core
   * dialog INVOKES the behavior and renders the copy, falling back to its OWN
   * channel-NEUTRAL strings when `copy` (or a given thunk) is absent — so the
   * open-source core stays Steam-free in BEHAVIOR and in WORDING. `purchase`
   * yields NO value (the purchase result reaches core via the EXISTING
   * entitlement-state path, never as a return). MINIMALITY: EXACTLY one register
   * verb — no read, no ownership query, no return value from `purchase`. The
   * returned `HostUnregister` is owner-scope-tracked so `unloadOne` revokes it.
   * See {@link AgentUiMembership} / {@link ColorfulPurchaseRegistration}.
   */
  readonly membership: AgentUiMembership;

  // ── ADDITIVE v1.41 member (MINOR per the freeze checklist) ───────────────

  /**
   * ADDITIVE v1.41 (MINOR) — own the planning-space area of a Project's
   * settings surface. THREE verbs, and the third is why this is not just
   * another single-verb register handle:
   * `registerSection(def): HostUnregister` routes to the host
   * `projectPlanningSectionStore` (`registerProjectPlanningSection`) with the
   * plugin's `pluginId` injected by the host factory and the entry keyed
   * `plugin:<pluginId>:<sectionId>` (no namespace forgery); `getStatus` /
   * `setEnabled` are a NARROW forward to the host's three Project planning
   * operations. MINIMALITY: the scoped `host.ipc` reaches only methods the
   * plugin registered main-side, so a contributed planning panel has NO legal
   * route to a Project's planning status — and granting the whole `projects:*`
   * namespace to serve one consumer would widen a host-owned surface to every
   * capability holder. The port exposes no Project create/update/delete,
   * member or session operation, and returns the host's status shape verbatim.
   * The returned `HostUnregister` is owner-scope-tracked so `unloadOne` revokes
   * the section live. See {@link AgentUiProjectPlanning}.
   *
   * OPTIONAL, per the freeze checklist's own definition of a MINOR bump ("a new
   * OPTIONAL handle member"). A host built at `1.0.0`-`1.40.0` does not have it,
   * and the loader's compat gate does NOT protect additive members: a higher
   * `requiredMinor` yields `warn-minor`, which logs and then proceeds to import
   * and `activate`. So the ONLY thing that can force a plugin author to guard an
   * additive member is declaring it optional here — typed REQUIRED, the compiler
   * actively signals the opposite of the runtime truth. Guard with
   * `host.projectPlanning?.registerSection(...)` and degrade, exactly as
   * `getProfileDir?.()` does on the main surface.
   */
  readonly projectPlanning?: AgentUiProjectPlanning;

  // ── ADDITIVE v1.44 member (MINOR per the freeze checklist) ───────────────

  /**
   * ADDITIVE v1.44 (MINOR) — the UNIFIED `host.agents` registration namespace.
   * `define(def)` dispatches each present field (`behavior`/`effect`/`workspace`/
   * `modality`/`group`) to the corresponding renderer store, keyed by
   * `def.agentId`. The returned {@link HostUnregister} revokes ALL dispatches.
   *
   * OPTIONAL (the same optional-member discipline as `projectPlanning?`): a host
   * built at ≤v1.43 lacks it and the plugin guards `host.agents?.define(...)`.
   *
   * MINIMALITY: one `define` verb carrying a definition whose fields are
   * structural pass-throughs (typed `unknown` in the contract; the host factory
   * casts each to its target store's `*Like` type). No new store shape, no host
   * object crosses. See {@link HostAgentsUi} / {@link HostAgentUiDefinition}.
   */
  readonly agents?: HostAgentsUi;

  /**
   * ADDITIVE v1.47 (MINOR) — the cross-plugin Capability composition handle
   * (`elftia-composition-platform` Phase 1, design §8).
   *
   * THE SAME `HostCapabilities` INTERFACE AS THE MAIN HALF (design D3). This is
   * the one namespace that does not split: it references no React / DOM / Node
   * type, so both halves share the declaration and `HostCapabilityTarget`
   * carries the process distinction as data. A renderer plugin therefore
   * `provide`s a renderer-target Capability and `require`s either target
   * through the same shape it would use in main.
   *
   * OPTIONAL (the same discipline as `agents?`): a host built at ≤v1.46 lacks
   * it and the plugin guards `host.capabilities?.…`.
   *
   * MINIMALITY: three verbs — `provide` / `require` / `explain`. `observe()` is
   * deliberately ABSENT (D21). See {@link HostCapabilities}.
   */
  readonly capabilities?: HostCapabilities;

  /**
   * ADDITIVE v1.48 (MINOR) — the Artifact layer's RENDERER-half handle
   * (`elftia-composition-platform` Phase 2, design §11). The D3 counterpart of
   * the backend's `artifacts?` data plane: this handle carries ONLY the
   * React-shaped members — `surfaces.register` (the one surface-registration
   * verb, Gate-0 C4) and `ArtifactView` (the host-rendered view every
   * placement reuses) — plus the same pure-data `open?` the Main half carries
   * (Gate-0 C2: both halves, one signature). Data-plane verbs are
   * deliberately ABSENT: renderer consumers read summaries through the
   * host-rendered `ArtifactView`, not by fetching them.
   *
   * OPTIONAL (the same discipline as `capabilities?`): a host built at ≤v1.47
   * lacks it and the plugin guards `host.artifacts?.…`.
   *
   * MINIMALITY: `surfaces` (one register verb), `ArtifactView`, `open?` —
   * every placement (canvas card, workspace, dialog) is the one view with
   * different props; `list`/`explain`/`observe` are NOT frozen (D21).
   * @see {@link HostArtifactsRenderer}
   */
  readonly artifacts?: HostArtifactsRenderer;

  // ── ADDITIVE v1.52 member (MINOR per the freeze checklist) ───────────────

  /**
   * ADDITIVE v1.52 (MINOR) — the desktop-pet window's runtime surface
   * (`desktop-pet-window-runtime` D7). FIVE members, each with a one-line
   * minimality note: `subscribeFacts(listener): HostUnregister` (read-only push
   * of freshly composed workbench facts snapshots — initial/ready replay, then
   * every change plus half-TTL re-assertions; snapshot stays sole truth),
   * `getConfig()` (read-only
   * runtime config — no write verb, the pet cannot re-enable itself),
   * `setPointerCapture(inside)` (boolean-only mouse-event capture toggle),
   * `startDrag()` (signal-only — the HOST owns the native drag loop and window
   * positioning), `requestAppExit()` (the single lifecycle verb, mirrors tray
   * quit). Meaningfully backed ONLY in the pet window's scoped harness; invoked
   * from a main-window plugin context it is a no-op / logged degradation, never
   * a crash. See {@link AgentUiPetRuntime}.
   *
   * OPTIONAL (F5 — the same discipline as `capabilities?`/`artifacts?` above):
   * a MINOR bump must never add a required member to an interface consumers
   * *construct* (a plugin repo's `const fakeHost: AgentUiHostApi = {...}` test
   * fixture would hard-break on every 1.50→1.52 upgrade otherwise). Always
   * present in practice (`buildDegradedPetRuntime` backs it even outside the
   * pet window); `?` exists for the construct-site contract, not to signal
   * absence.
   */
  readonly petRuntime?: AgentUiPetRuntime;

  /**
   * ADDITIVE v1.56 — owner-scoped Local Channel attach surface. Identity,
   * capability tokens and the lossless activation handshake remain Host-owned.
   */
  readonly localChannels?: HostLocalChannels;
  /** ADDITIVE v1.57 — selected Quick Chat shell's single remote-surface registry. */
  readonly quickChat?: HostQuickChatRegistry;
}

/** The exact public Host shape injected into an isolated desktop Pet plugin. */
export type AgentUiPetHostApi = Pick<
  AgentUiHostApi,
  'version' | 'compat' | 'react' | 'ui' | 'i18n' | 'theme' | 'ipc'
> & {
  readonly petRuntime: AgentUiPetRuntime;
  readonly capabilities: HostPetCapabilityConsumer;
};

/** The exact public Host shape injected into the trusted Quick Chat shell. */
export type AgentUiQuickChatHostApi = Pick<
  AgentUiHostApi,
  'version' | 'compat' | 'react' | 'ui' | 'i18n' | 'theme'
> & {
  readonly localChannels: HostLocalChannels;
  readonly quickChat: HostQuickChatRegistry;
};

/**
 * The renderer-side `activate` signature a Tier-1 plugin exports. The loader
 * (Child H) calls it with the injected {@link AgentUiHostApi}. Defined here so
 * the contract is anchored; the loader is out of scope.
 */
export type AgentUiActivate = (host: AgentUiHostApi) => void | Promise<void>;

/**
 * ADDITIVE v1.14 (MINOR) — the OPTIONAL renderer-side `deactivate` export a
 * Tier-1 plugin MAY export (the Obsidian `onunload` analogue). The loader calls
 * it on disable, AFTER draining the host-owned disposers and poisoning the
 * stale host, inside try/catch (a throw is logged, never fatal).
 *
 * It takes NO arguments — the plugin already closed over its host in
 * `activate`. Use it to release the plugin's OWN side effects (a bare
 * `setInterval`, a `window` listener, a `MutationObserver`) that the host's
 * owner-scoped disposer accounting cannot see. A plugin without it is disabled
 * unchanged (the loader guards `typeof mod.deactivate === 'function'`).
 *
 * Reentrancy: `activate(host)` MAY be called more than once in a single process
 * (re-enable after disable). Treat each `activate` call as a fresh start; a
 * `deactivate` is paired with the most recent `activate`. See the
 * `── v1.14.0 ──` block in `./version` for the full reentrancy contract.
 *
 * MINIMALITY: zero-arg optional export; no new host surface, no required field.
 */
export type AgentUiDeactivate = () => void | Promise<void>;
