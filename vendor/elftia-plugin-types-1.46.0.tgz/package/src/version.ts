/**
 * version.ts — Host-API version + compatibility policy (lib-agnostic).
 *
 * This module is the ONLY symbol shared between the renderer host-API module
 * (`renderer.ts`) and the main host-API module (`backend.ts`). Per Decision D2
 * it MUST contain ONLY lib-agnostic types — string literals and plain
 * interfaces — so that importing it from the main (Node) context does not pull
 * a DOM type in, and importing it from the renderer (DOM) context does not pull
 * a Node type in. Do NOT add any reference to `react`, `electron`, `WebContents`,
 * `HTMLElement`, etc. here.
 *
 * ---------------------------------------------------------------------------
 * Host-API versioning + compatibility policy (Decision D8 / spec
 * "Host-API versioning and compatibility policy")
 * ---------------------------------------------------------------------------
 *
 * The host API versions on **its own semver axis**, independent of the Elftia
 * app version (`package.json` `version`). App version churns for reasons
 * unrelated to the plugin contract; a plugin author should reason about exactly
 * one number — `HOST_API_VERSION`.
 *
 * Semver semantics for the host API:
 *   - **PATCH** (`1.0.0` → `1.0.1`): documentation / JSDoc-only changes. No
 *     type-surface change.
 *   - **MINOR** (`1.0.0` → `1.1.0`): purely **additive** — a new OPTIONAL method,
 *     a new OPTIONAL handle member, or a new OPTIONAL field. Existing plugins
 *     keep compiling unchanged.
 *   - **MAJOR** (`1.0.0` → `2.0.0`): a **breaking** change — removal of a member,
 *     a signature change, addition of a REQUIRED field, or a React-major bump
 *     that breaks the `host.react` shape. A migration note is REQUIRED.
 *
 * Interaction with manifest `minElftiaVersion`:
 *   - `minElftiaVersion` (a manifest field owned by the loader change, NOT this
 *     contract) remains the COARSE app-version gate.
 *   - `HOST_API_VERSION` is the FINE-GRAINED capability gate. A plugin declares
 *     the host-API range it needs; the future loader (Child H) refuses to
 *     `activate()` a plugin whose required host-API MAJOR exceeds the running
 *     app's `HOST_API_VERSION` major, **degrading** (an "update Elftia" message)
 *     rather than crashing.
 *
 * ---------------------------------------------------------------------------
 * FREEZE CHECKLIST (Decision D8 / spec "Freeze checklist")
 * ---------------------------------------------------------------------------
 *
 * Every FUTURE change that touches the host-API surface (`renderer.ts`,
 * `backend.ts`, or this file's exported types) MUST satisfy ALL of the
 * following before merge:
 *
 *   1. The change is ADDITIVE-ONLY, OR it bumps {@link HOST_API_VERSION} MAJOR
 *      and ships a migration note.
 *   2. Any surface WIDENING is justified against 窄端口 (narrow-port)
 *      minimality, or it is cut. New members carry a one-line minimality
 *      justification in JSDoc. Adding an argument to an EXISTING method (e.g.
 *      `render()` on the forward-anchored `AgentPageDefinitionLike`) is
 *      additive-only when the argument is OPTIONAL; a REQUIRED argument is a
 *      MAJOR break.
 *   3. No DOM type leaks into `backend.ts`, and no Node/Electron type leaks
 *      into `renderer.ts` (Decision D2). The two modules never import each
 *      other; only `version.ts` is shared, and it stays lib-agnostic.
 *   4. No React copy and no UI component is bundled into the package — the
 *      React handle stays `typeof import('react')` and UI primitives stay TYPE
 *      references (Decisions D4 / D5). The package declares NO runtime
 *      `dependencies`.
 *   5. The compile-smoke fixtures (`__smoke__/renderer.smoke.ts`,
 *      `__smoke__/backend.smoke.ts`) are updated to cover the new member, so
 *      both lib contexts still type-check.
 */

/**
 * The host-API version. v1 = `"1.0.0"`; v1.1 = `"1.1.0"`; v1.2 = `"1.2.0"`;
 * v1.3 = `"1.3.0"`; v1.4 = `"1.4.0"`; v1.5 = `"1.5.0"`; v1.6 = `"1.6.0"`;
 * v1.7 = `"1.7.0"`; v1.8 = `"1.8.0"`; v1.9 = `"1.9.0"`; v1.10 = `"1.10.0"`;
 * v1.11 = `"1.11.0"`; v1.12 = `"1.12.0"`; v1.13 = `"1.13.0"`;
 * v1.14 = `"1.14.0"`; v1.15 = `"1.15.0"`; v1.16 = `"1.16.0"`; v1.17 = `"1.17.0"`;
 * v1.18 = `"1.18.0"`; v1.19 = `"1.19.0"`; v1.20 = `"1.20.0"`;
 * v1.21 = `"1.21.0"`; v1.22 = `"1.22.0"`; v1.23 = `"1.23.0"`; v1.24 = `"1.24.0"`;
 * v1.25 = `"1.25.0"`; v1.26 = `"1.26.0"`; v1.27 = `"1.27.0"`; v1.28 = `"1.28.0"`;
 * v1.29 = `"1.29.0"`; v1.30 = `"1.30.0"`; v1.31 = `"1.31.0"`; v1.32 = `"1.32.0"`;
 * v1.33 = `"1.33.0"`; v1.34 = `"1.34.0"`; v1.35 = `"1.35.0"`;
 * v1.36 = `"1.36.0"`; v1.37 = `"1.37.0"`; v1.38 = `"1.38.0"`; v1.39 = `"1.39.0"`;
 * v1.40 = `"1.40.0"`; v1.41 = `"1.41.0"`; v1.42 = `"1.42.0"`; v1.43 = `"1.43.0"`;
 * v1.44 = `"1.44.0"`; v1.45 = `"1.45.0"`; v1.46 = `"1.46.0"`; v1.47 = `"1.47.0"`;
 * v1.48 = `"1.48.0"`; v1.49 = `"1.49.0"`; v1.50 = `"1.50.0"`; v1.51 = `"1.51.0"`;
 * v1.52 = `"1.52.0"`; v1.53 = `"1.53.0"`; v1.54 = `"1.54.0"`;
 * v1.55 = `"1.55.0"`; v1.56 = `"1.56.0"`; v1.57 = `"1.57.0"`;
 * v1.58 = `"1.58.0"`.
 * (The enumeration had stopped at v1.37 while the constant already read
 * `1.38.0` — corrected alongside the v1.39 bump.)
 *
 * The version axis is SHARED across both host APIs. v1.1–v1.4 were renderer-side
 * additions (`AgentUiHostApi`); v1.5 is the FIRST `AgentBackendHostApi` (main)
 * extension; v1.13 is again a RENDERER-side addition; v1.14 is a BOTH-HALVES
 * additive plugin-export type (the optional `deactivate`); v1.15 is again a
 * RENDERER-side addition (the `host.agentEvents` subscription port); v1.16 is
 * again a RENDERER-side addition (the `host.sessionEffects` page-level
 * session-effect registration port).
 *
 * ── v1.58.0 (ADDITIVE / MINOR) ──
 * Publishes the corrected dedicated Quick Chat window ABI: the Electron-free
 * `QuickChatWindowModule` / `QuickChatWindowHost`, one close intent, and one
 * no-argument endpoint-fixed Local Channel attach/client. The combined release
 * includes the v1.56 Local Channel transport, the main-only Quick Chat surface
 * request port, and the reduced Pet capability consumer. The provisional,
 * unarchived v1.57 renderer `host.quickChat` remote registry is superseded and
 * is not part of the producer-facing final ABI; generic compartment contracts
 * remain available to their other consumers. Unsupported/server lanes expose
 * no native Quick Chat surface.
 *
 * ── v1.57.0 (ADDITIVE / MINOR) ──
 * Adds the optional MAIN `host.services.quickChatSurface?` request port, the
 * optional RENDERER `host.quickChat?` remote-surface registry, and the distinct
 * reduced `AgentUiPetHostApi`. The Pet projection exposes only the
 * consumer-side `explain` / `require` flow and its generation-bound
 * `invoke` / acknowledged `release` lease; provider registration,
 * subscriptions, capability tokens and raw lease identities stay absent.
 * Unsupported main lanes and non-Quick-Chat renderer scopes leave the optional
 * general Host members absent.
 *
 * ── v1.56.0 (ADDITIVE / MINOR) ──
 * Adds two independent optional surfaces that originally advanced the shared
 * version axis in parallel. The renderer-side
 * `AgentUiPetRuntime.subscribeCharacterPresentation` read-only push port.
 * It is meaningfully backed only by the pet-window scoped Host and carries a
 * DOM-pure structural presentation snapshot; the main-window management
 * runtime omits it. Existing v1.55 plugins remain source-compatible.
 * Also adds the renderer `host.localChannels?` convenience client and the MAIN
 * `host.services.localChannels?` flat, extension-host-safe transport. The
 * backend surface exposes the seven Local request leaves plus one
 * attachment-addressed event subscription; every request deliberately omits
 * plugin identity because the host closes over the verified connection
 * principal. The service is permission-gated by `host:local-channel` at the
 * ext-host boundary, and connection teardown detaches its live attachments.
 *
 * ── v1.55.0 (ADDITIVE / MINOR) ──
 * Adds ONE OPTIONAL member: `AgentBackendHostApi.toolkits?` — the
 * skill-toolkit registration port (change `third-party-tool-pack-channel`,
 * module `host-api/skill-toolkit.ts`). A MAIN plugin registers ONE
 * `HostToolkitSpecLike` — `name` / `description` / `skillMarkdown` /
 * `functions[].name` pinned, everything else opaque — through EXACTLY one
 * verb `register(spec) → HostUnregister`, and the model reaches it through
 * the host's existing `elftia_toolkit` MCP (`list_toolkits` /
 * `read_toolkit` / `skill_invoke`). This is the TOOLKIT half of the
 * user-installable `kind:'tool-pack'` channel; the MCP half is the frozen
 * v1 `registerMcpProviderFactory`.
 * NO ZOD IN THE CONTRACT: each function's `schema` is typed `unknown`, not
 * `ZodTypeAny` — this package is dependency-light by charter and a plugin's
 * own validator instance is not the host's (a nominal Zod type would break
 * on `instanceof` across module boundaries). What the host needs is a
 * callable `safeParse`, a STRUCTURAL fact it duck-types at the seam.
 * VALIDATE AT THE SEAM, REJECT WHOLE: because `schema` is opaque, the host
 * checks every declared function before the registry sees the spec and
 * refuses the ENTIRE spec — naming plugin id, toolkit and offending
 * function — if any fails. Registering anyway would route unvalidated
 * MODEL-SUPPLIED arguments into a third-party handler running in the main
 * process; all-or-nothing is also what makes the returned teardown exact.
 * MAIN-ONLY, for a CONCRETE reason (not the general `workflow?` shrug): the
 * host's per-invocation toolkit context carries LIVE object handles
 * (`logger`, an optional media bridge) into every handler call, and neither
 * is wire-safe — relaying a handler would need callback proxying PLUS a
 * per-handle boundary decision. So a pack wanting process isolation
 * contributes MCP SERVERS (fully relayed today); a pack contributing
 * toolkits runs its handlers in main — the same privilege its `activate`
 * already has, so no new privilege is granted, only no new isolation.
 * TEARDOWN IS A REGISTRY REMOVAL, NOT A CANCELLATION: the dispatcher
 * resolves toolkit + function synchronously and then awaits the handler, so
 * an unregister landing mid-flight lets the running invocation complete
 * (side effects included) and only the NEXT invocation fails, with the
 * registry's unknown-toolkit error. The handle is also fed to the host's
 * per-plugin drain, so disabling the owner removes the toolkit even if the
 * plugin never calls it.
 * New declaration token `host:skill-toolkit` (a review signal with zero
 * runtime enforcement, like every other `host:*` token).
 * Backend smoke coverage pins the optional member (optional-chain
 * `register` + the one-verb `@ts-expect-error` probe); the renderer smoke
 * only advances the shared version literal.
 *
 * ── v1.53.0 (ADDITIVE / MINOR) ──
 * Adds ONE OPTIONAL member: `AgentBackendHostApi.notifications?` — the
 * plugin notification port (Slice S08 `08-host-owned-tool-hosts`, change
 * `s08-notifications-and-export`, module `host-api/notifications.ts`). A
 * MAIN plugin raises a system notification through EXACTLY one verb
 * `notify(input) → void` (title/body non-empty strings, optional
 * icon/silent, optional DATA-ONLY `action: { kind: 'openPath'; path }` on
 * an absolute existing directory). The action is executed by the HOST on
 * click — focus the main window, re-validate the path, `shell.openPath` —
 * so NO callback ever crosses the seam and a notification may outlive its
 * plugin (a click after a disable runs zero plugin code; the anticipated
 * per-notification callback registry is dissolved by construction).
 * Attribution is HOST-INJECTED (the registering plugin's id rides the
 * service's log/history; the input carries no forgeable source field).
 * Title/body are an OS surface (retained in notification-center history,
 * indexed, screenshotable): the contract FORBIDS tokens/credential-bearing
 * URLs in them; the host does not censor — the `host:notifications`
 * DECLARATION token (same class as `host:tool-hosts`, the C2 one-answer
 * test applied to a user-visible + attributable port) is the review
 * signal. The ext-host branch deliberately does not wire the member (the
 * documented `workflow`/`toolHosts` posture — validated and consumed
 * entirely on the main process). Backend smoke coverage pins the optional
 * member (optional-chain notify + the void return); the renderer smoke
 * only advances the shared version literal.
 *
 * ── v1.52.0 (ADDITIVE / MINOR) ──
 * Adds the RENDERER `host.petRuntime` desktop-pet runtime port
 * (`desktop-pet-window-runtime` D7). FIVE members: `subscribeFacts` (read-only
 * push of freshly composed workbench facts snapshots), `getConfig` (read-only
 * runtime config), `setPointerCapture` (boolean mouse-event capture toggle),
 * `startDrag` (signal-only; the host owns the drag loop), `requestAppExit`
 * (the single lifecycle verb). New sibling module
 * `host-api/pet-runtime.ts` imports ONLY `./_shared` (DOM-purity); the
 * snapshot/config payloads are structural lower bounds (`HostPetFactsSnapshotLike`
 * / `HostPetFactEntryLike` / `HostPetRuntimeConfig`), no `@elftia/shared` type.
 * The `1.50.0` surface is byte-unchanged. Meaningfully backed ONLY in the pet
 * window's scoped harness; a main-window plugin invoking it degrades to a
 * no-op / logged degradation, never a crash.
 *
 * ── v1.51.0 (ADDITIVE / MINOR) ──

 * Adds ONE OPTIONAL member: `AgentBackendHostApi.toolHosts?` — the tool-host
 * daemon registration port (Slice S08 `08-host-owned-tool-hosts`, module
 * `host-api/tool-hosts.ts`). A MAIN plugin publishes a wire-safe
 * `HostToolHostDescriptorLike` (pure data: launch command/args, the tool's own
 * rendezvous index/secret paths, an `{port}`/`{token}` editor URL template, a
 * root-relative health path) through EXACTLY one verb `register(descriptor) →
 * HostUnregister`, and the host takes over supervision (spawn, rendezvous
 * wait, ownership, idle sweep) plus the generic renderer entry surface. The
 * descriptor is validated and consumed entirely on the main process — no
 * wire-proxy obligation is invented for the ext-host branch, which
 * deliberately does not wire it (the documented `workflow`-port posture;
 * the member is ABSENT there, and a guarded call is a no-op). Registering
 * delegates process-spawning to a plugin's descriptor, so the manifest side
 * gains the `host:tool-hosts` DECLARATION token (same class as
 * `host:workflow`); the host-API surface itself carries no permission gate.
 * Nothing in the contract names a specific tool (acceptance C4). Backend
 * smoke coverage pins the optional member (optional-chain register + the
 * returned unregister); the renderer smoke only advances the shared version
 * literal.
 *
 * ── v1.50.0 (ADDITIVE / MINOR) ──
 * Adds THREE OPTIONAL explicit key-reveal verbs — the FIRST deliberate outward
 * secret exception on any port: `HostMediaConfigLike.revealProviderKey`,
 * `HostMediaConfigLike.revealProviderSecret` (video byteplus), and
 * `HostLlmConfigLike.revealProviderKey`. Each returns the stored key on a
 * DEDICATED `HostMediaKeyRevealResult`/`HostLlmKeyRevealResult` (never on a
 * provider row), for USER-INITIATED display only (the settings eye icon — the
 * relocated BYO panels read masked ports and previously could not show a
 * stored key at all). `$VAR`/relay-marker refs are returned verbatim (they are
 * not secrets). Both verbs reuse the EXISTING `host:media-config` /
 * `host:llm-config` tokens — same domain as `setProviderKey`/`testModel`, no
 * new token, no permission-scanner change. Every mask-on-return structural
 * invariant (`apiKey?: never` / `api_key` blanking) is untouched: the revealed
 * value type-checks ONLY onto the dedicated reveal results. Backend smoke
 * coverage pins all three optional methods (+ the video field-union
 * negatives); the renderer smoke only advances the shared version literal.
 *
 * ── v1.49.0 (ADDITIVE / MINOR) ──
 * Adds OPTIONAL `HostMediaConfigLike.setProviderSecret` for the independent
 * Seedance VOD provider's BytePlus AK/SK. The narrow method accepts only
 * `mediaType: 'video'` and `byteplusAk | byteplusSk`, returns status only, and
 * writes through the existing per-provider media secret-ref namespace. The
 * ordinary provider patch and every returned provider structurally forbid both
 * fields (`?: never`), so no plaintext credential is reopened on the config
 * surface. Backend smoke coverage pins the optional method and field union;
 * the renderer smoke only advances the shared version literal because the new
 * capability is main-only.
 *
 * ── v1.48.0 (ADDITIVE / MINOR) ──
 * The Artifact layer contract freeze (`elftia-composition-platform` Phase 2,
 * design §10/§11/§13 + §37 D22 adjudication). TWO new sibling modules + THREE
 * new OPTIONAL members + the canonical wire contract in `@elftia/shared`
 * (`contracts/artifact-composition.ts`, restated STRUCTURALLY here — this
 * package still imports no `@elftia/shared` type); the `1.47.0` surface is
 * BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.47.0` still compiles):
 *   - NEW sibling module `host-api/artifacts.ts` publishing the artifact data
 *     vocabulary (ref/scope/state/envelope/badge/summary/locator, surface
 *     role/props/definition/context, open options/result, kind definition, the
 *     closed 9-member `HostArtifactErrorCode`) + the behavioral types
 *     (`HostArtifactContext` with the HOST-DERIVED vs CALLER-ASSERTED trust
 *     split, `HostArtifactKindProvider`, `HostArtifactSurfaces` — EXACTLY one
 *     `register` verb) + the D3-split handles `HostArtifactsMain`
 *     (`registerKind`/`create`/`getSummary`/`subscribeSummary`/`open?` — the
 *     data plane) and `HostArtifactsRenderer` (`surfaces`/`ArtifactView`/`open?`
 *     — the React-shaped members). `open` sits on BOTH halves with ONE
 *     pure-data signature (Gate-0 C2); the state union is the ONE six-member
 *     union on both Envelope and Summary (C6); the locator is host-MINTED and
 *     envelope-validated verbatim, never a path (C3).
 *   - NEW sibling module `host-api/artifact-storage.ts` publishing
 *     `HostArtifactStorageLike` — EXACTLY three lifetime-scoped path verbs
 *     (`payloadDir`/`derivedDir`/`exportsDir`), each scoped by the host-minted
 *     locator, with NO artifact-root grant (`envelope.json` stays host-owned).
 *     A SIBLING of `storage?`, not an extension: artifact directories are
 *     RETAINED on disable/uninstall (OQ#2) — the opposite lifetime of
 *     `storage.dataDir()`'s delete-on-uninstall, hence forbidden under that
 *     tree (Gate-0 C5).
 *   - NEW OPTIONAL member `AgentBackendHostApi.artifacts?: HostArtifactsMain`
 *     — the Main-half data plane.
 *   - NEW OPTIONAL member `AgentUiHostApi.artifacts?: HostArtifactsRenderer`
 *     — the Renderer-half handle; its data-plane verbs are deliberately
 *     ABSENT (renderer consumers read summaries through the host-rendered
 *     `ArtifactView`).
 *   - NEW OPTIONAL member `AgentBackendHostServices.artifactStorage?` — the
 *     C5 storage port.
 *   - NEW gate `hostApiHalfPurity.test.ts` (beside the Phase-1 composition
 *     tests): leg 1 lib-stripped compile (`backend.ts` without DOM lib,
 *     `renderer.ts` without `@types/node`), leg 2 import-closure denylist,
 *     leg 3 cross-half absence probes in BOTH smoke fixtures — the D3 member
 *     table is now pinned MECHANICALLY (a structural `HostComponentType`
 *     member on the wrong half compiles everywhere; tsc alone cannot catch it).
 *
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: three new OPTIONAL members + two sibling modules (plus
 *      the canonical `@elftia/shared` module + its barrel line); no existing
 *      member or signature changes. All three members are OPTIONAL — the
 *      artifact runtime lands in later slices, so an unwired build yields
 *      `undefined` (the plugin `activate` guards, the `capabilities?`
 *      contract-only precedent).
 *   2. Narrow-port minimality: Main = 4 verbs + optional `open`; Renderer =
 *      `surfaces.register` + `ArtifactView` + optional `open`; storage =
 *      EXACTLY 3 verbs, no root grant. NO destroy verb, NO `list`/`explain`/
 *      `observe` (D21 — freeze no verb without a consumer; the C1
 *      duplicate-`surfaceId` policy is explicitly deferred to the registry
 *      slice). Every new member carries a per-member minimality JSDoc.
 *   3. No DOM/Node leakage: the context's cancellation signal is the
 *      STRUCTURAL `HostAbortSignalLike`, never bare `AbortSignal` (the
 *      Phase-1 `lib:[ES2022,DOM]` blind spot); `HostArtifactSurfaceContext`
 *      is identity-only — no DOM handle type anywhere (C3). FIRST release
 *      where this point is MECHANICALLY ENFORCED by the three-leg purity gate,
 *      not only reviewed.
 *   4. No React/runtime dependency: type-only change; `HostComponentType`
 *      appears ONLY on the renderer handle's `ArtifactView`; contract-only —
 *      no runtime service, no IPC channel, no React component ships.
 *   5. Smoke coverage: both smoke files bump `_version: '1.47.0'` →
 *      `'1.48.0'`; `backend.smoke.ts` exercises registerKind/create/
 *      getSummary/subscribeSummary/open + `services.artifactStorage`'s three
 *      verbs through the optional guards; `renderer.smoke.ts` exercises
 *      `surfaces.register` (full surface definition), an `ArtifactView`-
 *      conforming component fn, and `?.open`; cross-half absence probes in
 *      BOTH fixtures pin the D3 table (leg 3).
 *
 * ── v1.46.0 (ADDITIVE / MINOR) ──
 * Adds the optional `host.services.objectStorageConfig` port. The BYO plugin
 * can edit AWS S3, Cloudflare R2, Aliyun OSS, and S3-compatible non-secret
 * settings and submit write-only credentials; no credential is returned.
 *
 * ── v1.45.0 (BREAKING / bumped as MINOR — all consumers migrated) ──
 * Spec-session infrastructure retirement (`host-agents-define-infra` Phase 3).
 * The spec-session path is removed: `registerSessionHandler`,
 * `HostSessionHandler`, `HostSessionHandlerInput`, `HostSessionRuntimeLike`,
 * and the `host.services.sessionRuntime` port are DELETED. Both producers
 * (design-studio 1.6.5, html-video 1.5.0) migrated to `host.agents.define`
 * + `sessionType:'agent'` — zero runtime consumers remain. Technically a
 * MAJOR (API removal) but shipped as MINOR since all consumers are migrated.
 *
 * ── v1.44.0 (ADDITIVE / MINOR) ──
 * The UNIFIED `host.agents.define` port (`host-agents-define-infra`, design D1).
 * ONE new OPTIONAL member on BOTH `AgentUiHostApi` (renderer half) AND
 * `AgentBackendHostApi` (backend half) + ONE new sibling module; the `1.43.0`
 * surface is BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.43.0` still
 * compiles):
 *   - NEW sibling module `host-api/agents.ts` publishing `HostAgentsUi`
 *     (renderer half: `define(def): HostUnregister` dispatches `behavior`→
 *     sessionKindStore, `effect`→sessionEffectStore, `workspace`→workspaceStore,
 *     `modality`→newChatStore, `group`→sessionGroupStore — all keyed by `agentId`),
 *     `HostAgentsBackend` (backend half: `define(def): HostUnregister` registers
 *     the setup fn in `AgentSessionSetupRegistry`), and the setup-fn contract
 *     (`HostAgentSessionSetupFn` / `HostAgentSetupInput` / `HostAgentSetupResult`).
 *   - NEW OPTIONAL member `AgentUiHostApi.agents?: HostAgentsUi` — the renderer
 *     dispatch half. OPTIONAL: an older host yields `undefined` and the plugin
 *     guards `host.agents?.define(...)`.
 *   - NEW OPTIONAL member `AgentBackendHostApi.agents?: HostAgentsBackend` — the
 *     backend dispatch half. OPTIONAL, same discipline.
 *
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new OPTIONAL member on each of the two host halves +
 *      one sibling module; no existing member or signature changes. Both members
 *      are OPTIONAL — an unwired build yields `undefined` (the plugin `activate`
 *      guards, the `projectPlanning?` / `workflow?` optional-dep precedent).
 *   2. Narrow-port minimality: EXACTLY one `define` verb per half. The UI
 *      definition fields are structural pass-throughs (typed `unknown` in the
 *      contract; the host factory casts each to its target store's `*Like` type).
 *      No host store object crosses. The setup fn returns a plain data record —
 *      no callback, no host handle.
 *   3. No DOM/Node leakage: `host-api/agents.ts` imports ONLY `./_shared`
 *      (`HostUnregister`); plain `string`/`readonly`/structural-record shapes.
 *      `renderer.ts` and `backend.ts` import it as types. No React runtime dep,
 *      no `electron`/Node type enters the sibling module.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: both smoke files exercise `host.agents?.define(...)` and
 *      the `_version` literal `'1.43.0'` → `'1.44.0'` in BOTH files (the version
 *      axis is shared).
 *
 * ── v1.43.0 (ADDITIVE / MINOR) ──
 * The managed-runtime READ-ONLY path-resolution port
 * (`creative-library-managed-consumption`). ONE new OPTIONAL
 * `AgentBackendHostServices` member + ONE new sibling module; the `1.42.0`
 * surface is BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.42.0` still
 * compiles):
 *   - NEW sibling module `host-api/managed-runtime.ts` publishing
 *     `HostManagedRuntimeLike` (EXACTLY one read verb — `resolvePreparedDir(id)`
 *     returning `string | null`). NO write/create/delete/update verb — the host
 *     owns the runtime directory lifecycle; the plugin only reads the path.
 *   - NEW OPTIONAL member `AgentBackendHostServices.managedRuntime?` —
 *     READ-ONLY (no write verb). The host checks `node:fs.existsSync` for the
 *     dir + its `node_modules/` prep indicator; the plugin receives a path
 *     string or `null`, then performs its own `node:fs` I/O.
 *
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new OPTIONAL service member + one sibling module; no
 *      existing member or signature changes. The member is OPTIONAL — an
 *      unwired build yields `undefined` (the plugin `activate` guards, the
 *      creativeLibrary/backupPolicy optional-dep precedent).
 *   2. Narrow-port minimality: EXACTLY one read verb (`resolvePreparedDir`);
 *      no write/create/delete/update verb. No host service object crosses; no
 *      file handle crosses; no IPC channel name crosses. The plugin receives a
 *      path string or `null` — the narrowest possible shape.
 *   3. No DOM/Node leakage: `host-api/managed-runtime.ts` imports nothing
 *      (plain `string`/`null` shapes only); a MAIN-context module imported only
 *      by `backend.ts` via `backend-services.ts`. `renderer.ts` untouched.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` exercises
 *      `managedRuntime?.resolvePreparedDir('creative-library')` through the
 *      optional guard, with a `@ts-expect-error` probe asserting NO write verb
 *      is typeable on `HostManagedRuntimeLike`; the `_version` literal
 *      `'1.42.0'` → `'1.43.0'` in BOTH smoke files (the version axis is shared).
 *      `renderer.smoke.ts` compiles UNTOUCHED apart from that shared literal.
 *
 * ── v1.42.0 (ADDITIVE / MINOR) ──
 * The creative-library READ-ONLY enumerate + fetch port
 * (`unified-creative-library-phase2`). ONE new OPTIONAL
 * `AgentBackendHostServices` member + ONE new sibling module; the `1.41.0`
 * surface is BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.41.0` still
 * compiles):
 *   - NEW sibling module `host-api/creative-library.ts` publishing
 *     `HostCreativeLibraryLike` (EXACTLY two read verbs — `list(scope?)` +
 *     `get(id)`), `CreativeLibraryItem` (the unified readonly shape with
 *     optional `source`), and
 *     `CreativeLibraryScope` (`'image-prompt' | 'video-prompt'`).
 *   - NEW OPTIONAL member `AgentBackendHostServices.creativeLibrary?` —
 *     READ-ONLY (no write/create/delete verb). The host owns the bundled roots
 *     and the curation; the plugin only reads.
 *
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new OPTIONAL service member + one sibling module; no
 *      existing member or signature changes. The member is OPTIONAL — an
 *      unwired build yields `undefined` (the plugin `activate` guards, the
 *      backupPolicy/inAppContent optional-dep precedent).
 *   2. Narrow-port minimality: EXACTLY two read verbs (`list` + `get`); no
 *      write/create/delete/update verb. No host service object crosses; no file
 *      paths cross; no IPC channel names cross. The adapter closes over the
 *      host-side loaders.
 *   3. No DOM/Node leakage: `host-api/creative-library.ts` imports nothing
 *      (plain `string`/`readonly`/`Promise` shapes only); a MAIN-context module
 *      imported only by `backend.ts` via `backend-services.ts`. `renderer.ts`
 *      untouched.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` exercises `creativeLibrary?.list()` +
 *      `?.list({ scope: 'video-prompt' })` + `?.get('id')` through the optional guard,
 *      reads fields off a returned `CreativeLibraryItem`, with a `@ts-expect-error` probe
 *      asserting NO write/create/delete verb is typeable on the interface; the
 *      `_version` literal `'1.41.0'` → `'1.42.0'` in BOTH smoke files (the
 *      version axis is shared). `renderer.smoke.ts` compiles UNTOUCHED apart
 *      from that shared literal.
 *
 * ── v1.41.0 (ADDITIVE / MINOR) ──
 * The PROJECT-PLANNING contribution point (`rasen-single-plugin` Milestone 6).
 * ONE new RENDERER member + ONE new sibling module; the `1.40.0` surface is
 * BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.40.0` still compiles):
 *   - NEW sibling module `host-api/project-planning.ts` publishing
 *     `AgentUiProjectPlanning` (EXACTLY three verbs — `registerSection(def)`,
 *     `getStatus(projectId)`, `setEnabled(projectId, next)`),
 *     `ProjectPlanningSectionDefinitionLike`, the `{ projectId }`-only
 *     `ProjectPlanningPanelContext`, and the structural mirrors
 *     `HostProjectPlanningStatusLike` / `HostPlanningDiagnosticLike`.
 *   - NEW `AgentUiHostApi.projectPlanning` member routing `registerSection` to
 *     the host `projectPlanningSectionStore` (the `settingsSectionStore`
 *     namespacing + leak-safe-unregister shape) and the two read/write verbs to
 *     the host's existing Project planning operations.
 *
 * WHY THE MEMBER CARRIES A PORT AND NOT ONLY A REGISTER VERB (design D2 — the
 * one place this release widens beyond the single-verb precedent): a plugin's
 * scoped `host.ipc.invoke` routes ONLY to methods that plugin registered
 * main-side, so a contributed planning panel has NO legal route to a Project's
 * planning status, and a panel that cannot read its own status is not a panel.
 * The rejected alternative — granting the plugin the host's `projects:*`
 * channel — widens a host-owned namespace to every capability holder in order
 * to serve one consumer. The port therefore forwards to exactly the three
 * Project planning operations, returns the host's status shape verbatim, and
 * exposes no Project create/update/delete, member or session operation.
 *
 * FREEZE CHECKLIST:
 *   1. ADDITIVE-ONLY (a new member + a new module); MINOR bump, no migration.
 *   2. Minimality justified above and in the member's JSDoc; the port's surface
 *      is pinned by an enumerate-the-keys assertion rather than a spot check.
 *   3. No Node/Electron type enters `renderer.ts`; the new module imports only
 *      `./host-api/_shared`. `backend.ts` is untouched and cannot reach it.
 *   4. No React/runtime dependency: `render` returns the lib-agnostic
 *      `HostReactNode`, built by the plugin through `host.react`.
 *   5. Smoke coverage: `renderer.smoke.ts` registers a section with a thunk
 *      label and with a static label, reads the `{ projectId }` context, awaits
 *      both port verbs and reads a diagnostic's fields, with `@ts-expect-error`
 *      probes pinning the ABSENCE of any other Project operation on the port;
 *      the `_version` literal `'1.40.0'` → `'1.41.0'` in BOTH smoke files (the
 *      version axis is shared). `backend.smoke.ts` compiles UNTOUCHED apart
 *      from that shared literal.
 *
 * ── v1.40.0 (ADDITIVE / MINOR) ──
 * The two workflow SIBLING SEAMS (`rasen-single-plugin` Milestone 2). TWO new
 * OPTIONAL members on the EXISTING `HostWorkflowRegistration` namespace + TWO
 * new sibling modules + TWO vocabulary tokens; the `1.39.0` surface is
 * BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.39.0` still compiles):
 *   - NEW sibling module `host-api/workflow-stage-runtime.ts` publishing the
 *     stage-dispatch port — `HostWorkflowStageRuntimeLike` (EXACTLY three verbs
 *     `start(input)` / `wait(executionId)` / `cancel(executionId, reason?)`),
 *     `HostStageStartInput` (`backend` / `role` / `prompt` / `projectPath?` /
 *     `agentId?` / `timeoutMs`), the CLOSED `HostStageBackend` (`agent`|`codex`)
 *     and `HostStageRole` (`stage`|`planner`|`reviewer`|`fixer`|`implementer`)
 *     vocabularies, the `HostStageStartResult` RESULT UNION and
 *     `HostStageOutcome` in the RAW dispatch vocabulary (`completed`|`timeout`|
 *     `error`|`cancelled`).
 *     WHY A RESULT UNION AND NOT A BARE `{executionId}` (design D1): the two
 *     admission failures a caller must branch on — retryable max-concurrency vs
 *     a dispatch failure — can only be distinguished by a MACHINE-READABLE CODE,
 *     and a rejection carries no code across a process boundary. The union
 *     reuses the v1.39 `HostWorkflowErrorCode` members `stage_dispatch_busy` /
 *     `stage_dispatch_failed`, which were added in v1.39 FOR this release; NO
 *     new error code is introduced, so the closed 10-member vocabulary is
 *     unchanged.
 *     WHY THE RAW OUTCOME VOCABULARY (design D2): two backends produce different
 *     wording for the same status, so the RUNTIME composes its own `note` and
 *     the caller maps the four statuses onto its own vocabulary once.
 *     NO CALLBACK CROSSES IT: the one piece of mid-flight information a caller
 *     needs (the execution id) is the RETURN VALUE of `start`, not a callback
 *     the caller passes down — which is what makes the port wire-safe.
 *   - NEW sibling module `host-api/workflow-browser.ts` publishing the CURATED
 *     browser port — `HostBrowserToolkitLike` (ONE verb `invoke(action, params,
 *     ctx)`), the CLOSED 13-verb `HostBrowserAction` vocabulary, the plain
 *     identity-only `HostBrowserInvokeContext`, the three-reason
 *     `HostBrowserUnavailableReason` (`not_initialized` /
 *     `toolkit_not_registered` / `not_connected`) and the three-branch
 *     `HostBrowserInvokeResult`.
 *     CURATED, NOT PASSTHROUGH (design D9): the vocabulary is the browse
 *     driver's VERBS, never the underlying toolkit's function catalog — no
 *     toolkit function name appears in the module and none is addressable
 *     through it. Verb → function resolution lives in the host-side adapter.
 *     NO HOST OBJECT CROSSES IT (design D10): the invoke context is plain
 *     optional strings; the logger the host's implementation needs is supplied
 *     at ITS construction, not through a call.
 *   - NEW OPTIONAL members `HostWorkflowRegistration.stageRuntime?` and
 *     `.browserToolkit?` — the sibling seams the v1.39 namespace JSDoc reserved
 *     space for verbatim ("a stage runtime, a browser toolkit"), landing on the
 *     namespace rather than as new top-level host members. Its prose moves from
 *     "EXACTLY one verb" to "one verb and two optional capability handles".
 *     The member is named `browserToolkit`, NOT `browser`, because the static
 *     permission scanner matches a bare property name anywhere in a bundle and
 *     `.browser` would fire on nearly any bundle — a naming decision made FOR
 *     the scanner.
 *     NEITHER IS WIRE-PROXIED in this release (source plan D7): the shapes are
 *     wire-ready, but the extension-host path wires neither.
 *   - NEW vocabulary tokens `host:stage-runtime` and `host:browser-toolkit`
 *     (each names a NEW port, the `host:workflow` precedent — a path-shape
 *     extension of an existing port would not earn one). Declaration/review
 *     signal, ZERO runtime enforcement. Vocabulary count `22` → `24` host:*.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: two new OPTIONAL members on an existing interface + two
 *      new sibling modules + two vocabulary tokens; no existing member removed,
 *      no signature changed, no REQUIRED field added. BOTH members are OPTIONAL
 *      — a host build that wires neither yields `host.workflow.stageRuntime ===
 *      undefined` and the plugin guards, the v1.39 `workflow?` /
 *      `getDataRootDir?` precedent. Making either REQUIRED would have been
 *      MAJOR; both ship optional, which is what keeps this MINOR.
 *   2. Narrow-port minimality: EXACTLY three verbs on the stage runtime and
 *      EXACTLY one on the browser toolkit. The DEPTH is in the obligations
 *      encoded as JSDoc (admission is a result not a throw; busy is retryable
 *      and named; a timeout TERMINATES the real worker before reporting;
 *      cancel is valid the moment start resolves, routes only to the execution
 *      it names, and is inert for an unknown or resolved id; the browser port
 *      never fabricates a page result and contains a substrate rejection) — not
 *      in extra methods. No handle, promise or session object is ever handed
 *      back; no toolkit function catalog is exposed.
 *   3. No DOM/Node leakage: `host-api/workflow-stage-runtime.ts` imports ONLY
 *      `./workflow` (the closed error-code union) and `host-api/workflow-browser.ts`
 *      imports NOTHING; both use plain `string`/`number`/`boolean`/`unknown` —
 *      no DOM type, no `electron`/Node type, no `@main`/`@shared` import.
 *      `backend.ts` imports both (as types) and re-exports them; `renderer.ts`
 *      is untouched and cannot reach either.
 *   4. No React/runtime dependency: a type-only change (the adapters are
 *      host-side code; no new package dependency).
 *   5. Smoke coverage: `backend.smoke.ts` constructs a start input for EVERY
 *      backend × role, BOTH start-result branches, EVERY outcome status, all
 *      three browser-result branches and a conforming `HostBrowserToolkitLike`,
 *      and reads `host.workflow?.stageRuntime` / `?.browserToolkit` through the
 *      optional guard, with `@ts-expect-error` probes pinning the closed action
 *      vocabulary, the closed error vocabulary, the absence of a callback verb
 *      on the stage runtime and the absence of a logger in the invoke context;
 *      the `_version` literal `'1.39.0'` → `'1.40.0'` in BOTH smoke files (the
 *      version axis is shared). `renderer.smoke.ts` compiles UNTOUCHED apart
 *      from that shared literal — no Node type entered the renderer contract.
 *
 * ── v1.39.0 (ADDITIVE / MINOR) ──
 * The DEEP workflow-provider port (`rasen-single-plugin` Milestone 1). ONE new
 * OPTIONAL `AgentBackendHostApi` member + ONE new sibling module + ONE OPTIONAL
 * getter on an existing port + ONE vocabulary token; the `1.38.0` surface is
 * BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.38.0` still compiles):
 *   - NEW sibling module `host-api/workflow.ts` publishing the whole workflow
 *     contract — `HostWorkflowProvider` (EXACTLY three verbs `describe()` /
 *     `execute(request)` / `shutdown(reason)`), the wire-safe
 *     `HostWorkflowDescriptor` (+ `HostWorkflowToolDescriptor` /
 *     `HostWorkflowToolsetDescriptor` / `HostWorkflowCapabilities`), the
 *     versioned `HostWorkflowRequest` discriminated union (`tool` /
 *     `project-planning` / `cron` / `legacy`) with `HostWorkflowCallContext`,
 *     the `HostWorkflowResponse` envelope, `HostWorkflowError` over the CLOSED
 *     10-member `HostWorkflowErrorCode` vocabulary, `HostWorkflowDiagnostic`
 *     and `HostWorkflowShutdownReason`.
 *   - NEW OPTIONAL member `AgentBackendHostApi.workflow?: HostWorkflowRegistration`
 *     — EXACTLY one verb `register(provider): HostUnregister` (the same
 *     `() => void` teardown shape as `HostBackendUnregister`). The owner id is
 *     HOST-INJECTED (the `registerSessionHandler` discipline); the teardown is
 *     ALSO fed into the host's per-plugin drain, so disabling the owner revokes
 *     the registration. A NAMESPACE object rather than a fourth top-level
 *     `registerX` so the sibling workflow seams land beside it later.
 *   - NEW OPTIONAL getter `HostPluginPathsLike.getDataRootDir?(): string`
 *     returning `AppPaths.dataRoot` (`~/.elftia`, honoring `ELFTIA_HOME` +
 *     profile relocation) so a provider derives `<dataRoot>/<workflow-id>`
 *     without re-deriving host path policy. NO new vocabulary token — a
 *     path-shape extension of the existing `pluginPaths` read port (the v1.38
 *     `getProfileDir` precedent). NO-WRITE / read-only.
 *   - NEW vocabulary token `host:workflow` (registering a provider that serves
 *     a whole tool surface is declaration-worthy; the `host:backup-policy`
 *     precedent). Declaration/review signal, ZERO runtime enforcement.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new OPTIONAL host-API member + one new sibling module
 *      + one new OPTIONAL getter on an existing interface + one vocabulary
 *      token; no existing member removed, no signature changed, no REQUIRED
 *      field added. The member is OPTIONAL — a build that wires no workflow
 *      registry yields `host.workflow === undefined` and the plugin guards
 *      (`host.workflow?.register(...)`), the storage/sessionRuntime/pluginPaths/
 *      backupPolicy optional-dep precedent. Making either the member or
 *      `getDataRootDir` REQUIRED (as the source plan sketched) would have been
 *      MAJOR; both ship optional, which is what keeps this MINOR.
 *   2. Narrow-port minimality: EXACTLY one register verb on the namespace and
 *      EXACTLY three verbs on the provider. The DEPTH is in the obligations
 *      encoded as JSDoc (describe pure + repeatable; business failure is data,
 *      not a throw; a protocol violation may reject; writes honor a
 *      host-generated `idempotencyKey`; shutdown drains and deletes NOTHING;
 *      activate is re-entrant; no retained host mutable global) — not in extra
 *      methods. No per-operation host method; the host never learns the
 *      provider's internal method surface.
 *   3. No DOM/Node leakage: `host-api/workflow.ts` imports ONLY `./_shared`
 *      (`HostUnregister`) and uses plain `string`/`number`/`boolean`/`unknown`
 *      — no DOM type, no `electron`/Node type, no `@main`/`@shared` import.
 *      `backend.ts` imports it directly (as a type) and re-exports it;
 *      `renderer.ts` is untouched and cannot reach it.
 *   4. No React/runtime dependency: a type-only change (the host registry is
 *      host-side code; no new package dependency).
 *   5. Smoke coverage: `backend.smoke.ts` constructs a descriptor, a provider,
 *      ONE request of EACH of the four kinds and BOTH response branches, reads
 *      `pluginPaths?.getDataRootDir?.()`, and asserts the register teardown is
 *      assignable to `HostBackendUnregister`, with `@ts-expect-error` probes
 *      pinning the CLOSED error vocabulary and the absence of a fourth provider
 *      verb; the `_version` literal `'1.38.0'` → `'1.39.0'` in BOTH smoke files
 *      (the version axis is shared). `renderer.smoke.ts` compiles UNTOUCHED —
 *      no Node type entered the renderer contract.
 *
 * ── v1.38.0 (ADDITIVE / MINOR) ──
 * Profile-dir getter on the plugin-paths port (`elftia-home-relocation`). ONE new
 * OPTIONAL method `HostPluginPathsLike.getProfileDir?(): string` returning
 * `AppPaths.profileDir` (`<dataRoot>/profile`, i.e. `~/.elftia/profile` after the
 * home relocation); the `1.37.0` surface is BYTE-UNCHANGED. The Steam plugin
 * sources its backup target (`<profileDir>/backups`) from this getter instead of
 * deriving `join(getUserDataDir(),'profile')`, so the target follows the data root.
 * OPTIONAL: an older host lacks it → the plugin guards with
 * `getProfileDir?.() ?? join(getUserDataDir(),'profile')` (degrades to the old
 * userData-profile location, no crash). No new vocabulary token (path-shape
 * extension of the existing `pluginPaths` read port). NO-WRITE / read-only.
 *
 * ── v1.37.0 (ADDITIVE / MINOR) ──
 * Backup-policy host sink port (`db-relocate-steam-backup`). ONE new OPTIONAL
 * `AgentBackendHostServices` member + ONE sibling module + ONE vocabulary token;
 * the `1.36.0` surface is BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.36.0`
 * still compiles):
 *   - NEW sibling module `host-api/backup-policy.ts` publishing
 *     `HostBackupPolicyLike` (+ the wire-safe `BackupPolicyRegistration`), exposed
 *     as the OPTIONAL member `AgentBackendHostServices.backupPolicy` — EXACTLY one
 *     WRITE-ONLY verb `register(policy): HostUnregister`. The channel-gated Steam
 *     plugin PUSHES a backup policy (`{ targetFolderPath: <profileDir>/backups,
 *     dbOnly: true, retention: 2, autoBackupDefaults: enabled/6h }`) so the host's
 *     backup target / retention / db-only / auto-default resolution reads the
 *     registered policy INSTEAD of branching on `channel === 'steam'`. The host
 *     folds it into a single-slot `BackupPolicyRegistry` (last-registration-wins;
 *     the `authSession`/`colorfulPurchaseStore` single-slot IoC precedent); absent
 *     a policy the host uses the official default (user-picked folder / WebDAV,
 *     full-state, disabled). WRITE-ONLY / NO-READ (the crux): the port exposes NO
 *     read of the resolved target, the effective settings, the session, or any
 *     entitlement — a plugin can only PUSH the policy. NEW vocabulary token
 *     `host:backup-policy` (pushing the backup policy into the host is
 *     declaration-worthy; the `host:auth-session` precedent).
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new OPTIONAL service member + one sibling module + one
 *      vocabulary token; no existing member or signature changes. The member is
 *      OPTIONAL — an unwired build yields `undefined` (the plugin `activate`
 *      guards, the authSession/relayApi/pluginInstaller optional-dep precedent).
 *   2. Narrow-port minimality: EXACTLY one write verb (no read/state/target/
 *      settings/session/gate member — the `secretsWrite`/`authSession` shape). No
 *      host `BackupPolicyRegistry`/service object crosses; the adapter closes over
 *      the narrow registry sink + coerces the registration at the boundary.
 *   3. No DOM/Node leakage: `host-api/backup-policy.ts` imports ONLY `./_shared`
 *      (`HostUnregister`) and uses plain `string`/`boolean`/`number` only — no DOM
 *      type, no `electron`/Node type, no `@main`/`@shared` import. `backend.ts`
 *      imports it only as a type via `backend-services.ts`. `renderer.ts` untouched.
 *   4. No React/runtime dependency: type-only change (the host registry is a pure
 *      data setter; no new dependency).
 *   5. Smoke coverage: `backend.smoke.ts` exercises `host.services.backupPolicy
 *      ?.register({ targetFolderPath, dbOnly: true, retention: 2 })` reading the
 *      returned `HostUnregister`, with a `@ts-expect-error` asserting NO read verb
 *      (no `get`/resolved-target) is exposed; the `_version` literal `'1.36.0'` →
 *      `'1.37.0'` in BOTH smoke files (the version axis is shared).
 *
 * ── v1.36.0 (ADDITIVE / MINOR) ──
 * Membership Colorful-purchase host port (`steam-colorful-upsell-purchase`). ONE
 * new RENDERER `AgentUiHostApi` member + ONE sibling module; the `1.35.0` surface
 * is BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.35.0` still compiles):
 *   - NEW sibling module `host-api/membership.ts` publishing `AgentUiMembership`
 *     (+ the wire-safe `ColorfulPurchaseRegistration` / `ColorfulPurchaseCopy`
 *     shapes), exposed as `AgentUiHostApi.membership` — EXACTLY one verb
 *     `registerColorfulPurchase(registration: ColorfulPurchaseRegistration):
 *     HostUnregister`. The `registration` is `{ purchase, copy? }`: `purchase: ()
 *     => void | Promise<void>` is the channel-specific flow, and `copy` is the
 *     OPTIONAL plugin-supplied wording (`cta?`/`intro?`/`pending?` string thunks,
 *     re-evaluated per render — the section-label-thunk precedent). It routes to
 *     the host's canonical single-slot Colorful-purchase registry
 *     (`registerColorfulPurchase` → `colorfulPurchaseStore`, last-registration-
 *     wins; the `host.chatPanel` / `designCommentsTabStore` single-slot IoC
 *     precedent). The CHANNEL-GATED Steam plugin registers a `purchase` that opens
 *     the DLC store + polls ownership AND its own Steam copy; the CORE upsell
 *     dialog (`UpgradeDialog`) resolves the registration reactively, RENDERS the
 *     copy thunks (falling back to its OWN channel-NEUTRAL host strings —
 *     `settings.membershipUpgrade.colorfulBuy` / `colorfulPurchasing` — when a
 *     thunk is absent) and INVOKES `purchase` for its CTA. Neither the behavior
 *     NOR the wording names the channel from the core, so the open-source core
 *     stays Steam-free in BEHAVIOR and in COPY (`scripts/check-core-steam-purity.cjs`).
 *     `purchase` yields NO value: the purchase result reaches core through the
 *     EXISTING entitlement-state path (`authSession:state` → `useEntitlements`),
 *     never as a return. NO new vocabulary token — it is a renderer register
 *     port (the `hello`/`workspace`/`chatPanel` precedent), not a host service.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one NEW renderer member + one sibling module; no existing
 *      member or signature changes. An older host yields `membership === undefined`
 *      and the plugin guards `typeof host.membership?.registerColorfulPurchase
 *      === 'function'` (the optional-member degradation); the core dialog degrades
 *      to its prior behavior when no registration is present; `copy` is OPTIONAL
 *      (absent ⇒ the host channel-NEUTRAL fallback).
 *   2. Narrow-port minimality: EXACTLY one register verb — no read, no ownership
 *      query, no return value from `purchase`. Rendering, the dialog flow, and the
 *      entitlement flip stay host-owned; the host AUTHORS NO Steam copy (it renders
 *      plugin thunks over a neutral fallback); no host store object crosses (the
 *      seam is a single registration object of an opaque callback + copy thunks).
 *   3. No DOM/Node leakage: `host-api/membership.ts` imports ONLY `./_shared`
 *      (`HostUnregister`); no `react` runtime dep, no `electron`/Node type, no
 *      `@main`/`@shared` import. `backend.ts` untouched (renderer-only change).
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `renderer.smoke.ts` exercises
 *      `host.membership.registerColorfulPurchase({ purchase: () => {}, copy: {
 *      cta: () => 'Buy', pending: () => '...' } })` (+ an async-`purchase`
 *      variant) and reads the returned `HostUnregister`; the `_version` literal
 *      `'1.35.0'` → `'1.36.0'` in BOTH smoke files (the backend smoke `_version`
 *      bumps in lockstep — the version axis is shared).
 *
 * ── v1.35.0 (ADDITIVE / MINOR) ──
 * Native open-dialog method for file-source Workshop publishing
 * (`workshop-publish-from-file`). ONE new method on the EXISTING
 * `host.services.nativeDialog` port (`HostNativeDialogLike`, module
 * `host-api/backend-native-ops.ts`); NO new service member, NO new vocabulary
 * token. The `1.34.0` surface is BYTE-UNCHANGED (a plugin built against
 * `1.0.0`–`1.34.0` still compiles — the method is additive on an existing
 * interface):
 *   - `HostNativeDialogLike` gains `showOpenDialog(options): Promise<HostOpenDialogResult>`
 *     (the v1.12 `showSaveDialog` is byte-unchanged). It opens a native file OR
 *     directory picker (selected via `options.directory`) and returns ONLY the
 *     chosen absolute PATH(s) (`{ canceled, paths }`) — no `dialog` object,
 *     window handle, file handle, or file bytes crosses into the plugin. The
 *     channel-gated Steam plugin uses it so a user can BROWSE the filesystem and
 *     publish an arbitrary file/folder as a Workshop item; the renderer receives
 *     only a PATH (all packaging + the secret scan + ISteamUGC stay in MAIN).
 *   - NEW wire-safe option/result types `HostOpenDialogOptions` (mirrors the
 *     audited save-dialog subset + a `directory?` intent) + `HostOpenDialogResult`
 *     (`{ canceled, paths: readonly string[] }`).
 *   NO new vocabulary token — `host:native-dialog` already covers the port (an
 *   open is the SAME capability domain as a save; the `secretsPack`/`testModel`
 *   "verb-on-existing-port" precedent). `buildAgentBackendHostApi.ts` is
 *   UNTOUCHED — the `nativeDialog` handle is already exposed unconditionally; the
 *   new method rides the same handle.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new method on an existing port + two new wire-safe
 *      types; no existing member or signature changes. A plugin built against
 *      ≤v1.34 sees the method as absent and guards `typeof
 *      …showOpenDialog === 'function'` (the optional-method degradation — the
 *      file source hides on an old host).
 *   2. Narrow-port minimality: the open dialog is single-selection, path-only
 *      (no `multiSelections`, no message box, no dialog object); it widens the
 *      EXISTING `nativeDialog` port rather than adding a new `filePicker` service
 *      member + a new token. The host owns Electron `dialog.showOpenDialog`; only
 *      strings cross.
 *   3. No DOM/Node leakage: `host-api/backend-native-ops.ts` stays structural
 *      (`string`/`boolean`/`Promise`/readonly-array only); no `electron`/Node/DOM
 *      type, no `@main`/`@shared` import. `renderer.ts` untouched.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` exercises `nativeDialog?.showOpenDialog
 *      ({ directory: true })` reading `{ canceled, paths }`, with a
 *      `@ts-expect-error` asserting no `dialog`/handle/bytes field on the result;
 *      the `_version` literal `'1.34.0'` → `'1.35.0'` (the renderer smoke
 *      `_version` bumps in lockstep — the version axis is shared).
 *
 * ── v1.34.0 (ADDITIVE / MINOR) ──
 * In-app-content Workshop publishing (`workshop-publish-in-app-content`). ONE new
 * OPTIONAL `AgentBackendHostServices` member + ONE new vocabulary token; the
 * `1.33.0` surface is BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.33.0`
 * still compiles):
 *   - NEW `host.services.inAppContent` (`HostInAppContentLike`, module
 *     `host-api/in-app-content.ts`) — the NARROW in-app-content enumerate +
 *     package port the channel-gated Steam plugin uses to publish a user's
 *     self-created in-app THEME or AGENT to the Workshop (not only installed
 *     plugin packages). EXACTLY two verbs: `list()` (enumerate the user's
 *     publishable in-app items — user-created + allowlisted-kind only) +
 *     `package({ kind, id })` (materialize ONE item into a Workshop content dir
 *     under a host temp root, returning `{ contentDir, kind, pluginId }`). The
 *     host owns enumeration (built-in/bundled excluded), the SECRET-FREE export
 *     paths (`AgentManagementService.exportAgent` / `ThemeService.exportProfile`),
 *     and the content-dir materialization; the plugin only selects an id and
 *     uploads the returned dir via its EXISTING `publishPlugin` path. No item
 *     content crosses the renderer. HARD ALLOWLIST: the publishable kind is
 *     `'theme' | 'agent'` ONLY — `list()` never returns `prompt-template` and
 *     `package()` THROWS for any kind outside the allowlist (the Steam-review /
 *     portrait / IP guardrail, enforced at the host boundary). New vocabulary
 *     token `host:in-app-content`, mirroring `host:plugin-installer`.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one NEW OPTIONAL service member + a new module; no existing
 *      member or signature changes. OPTIONAL — an unwired host yields `undefined`
 *      and the plugin degrades to installed-plugin-only publishing (the plugin
 *      `activate` guards, the optional-dep pattern).
 *   2. Narrow-port minimality: EXACTLY `list` + `package` (no update/delete/
 *      read-body verb; no generic DB passthrough). The allowlist is a single host
 *      constant; widening it is a deliberate reviewed change.
 *   3. No DOM/Node leakage: `host-api/in-app-content.ts` imports nothing (plain
 *      `string`/record/`Promise` shapes only); a MAIN-context module imported only
 *      by `backend.ts` via `backend-services.ts`. `renderer.ts` untouched.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` exercises `inAppContent?.list()` +
 *      `?.package({ kind:'agent', id:'x' })`, with a `@ts-expect-error` asserting
 *      no secret-typed field on the result; the `_version` literal `'1.33.0'` →
 *      `'1.34.0'` (the renderer smoke `_version` bumps in lockstep — the version
 *      axis is shared).
 *
 * ── v1.33.0 (ADDITIVE / MINOR) ──
 * Settings-section profile mirroring (`steam-account-sections-in-profile`). The
 * RENDERER `host.settings` section-contribution contract
 * `SettingsSectionDefinitionLike` (v1.20) gains ONE new OPTIONAL field; the
 * `1.32.0` surface is BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.32.0`
 * still compiles):
 *   - NEW OPTIONAL `SettingsSectionDefinitionLike.showInProfile?: boolean`. When
 *     truthy, the host ALSO renders the section's panel inside its "personal info"
 *     / account hub (`PersonalInfoTab`), in addition to the section's normal
 *     settings-page placement. The host mounts the SAME `render(ctx)` closure
 *     there inside the plugin error boundary, so the panel keeps the plugin's own
 *     scoped `host` — a CORE component never reaches the plugin's IPC directly
 *     (the per-plugin capability token is unchanged). Absent/false ⇒ the section
 *     appears ONLY in the settings page (the v1.20 behavior — no regression for
 *     un-flagged contributors). The channel-gated Steam plugin sets it on its
 *     account-shaped sections (sign-in / Colorful / points) so the account hub
 *     presents them together; the core hub stays channel-agnostic (it renders
 *     whatever flagged sections exist, with zero Steam knowledge — on a build
 *     where no plugin registers a flagged section, nothing extra appears).
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one NEW OPTIONAL field on an existing interface; no existing
 *      member or signature changes. The field is OPTIONAL — a plugin omitting it,
 *      or an old host ignoring it, behaves exactly as v1.20 (settings-page only).
 *   2. Narrow-port minimality: a single placement boolean (nav presentation only);
 *      no capability, no host service, no DB/dialog/WebContents crosses. The host
 *      reuses its EXISTING `settingsSectionStore` entry + `PluginErrorBoundary`
 *      panel renderer (`PluginSettingsSectionPanel`) — no new render path.
 *   3. No DOM/Node leakage: `host-api/settings.ts` still imports ONLY `./_shared`
 *      (`HostReactNode` + `HostUnregister`); no `react` runtime dep, no
 *      `electron`/Node type, no `@main`/`@shared` import. `backend.ts` untouched.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `renderer.smoke.ts` exercises a `registerSection` carrying
 *      `showInProfile: true`; the `_version` literal `'1.32.0'` → `'1.33.0'` (the
 *      backend smoke `_version` bumps in lockstep — the version axis is shared).
 *
 * ── v1.32.0 (ADDITIVE / MINOR) ──
 * Steam ticket-exchange login verb (`oss-channel-isolation` Phase 3 slice
 * P3-3b-2b-ii) — ONE new verb on the EXISTING `host.services.authSession` port
 * (`HostAuthSessionLike`); NO new service member, NO new vocabulary token. The
 * `1.31.0` surface is BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.31.0`
 * still compiles — the verb is additive on an existing interface):
 *   - `HostAuthSessionLike` gains a SECOND write verb `applySteamSession(ticketHex,
 *     identity): Promise<SteamSessionApplyResult>` (the v1.31 `setSteamColorfulDlcOwned`
 *     is byte-unchanged). The channel-gated Steam plugin reads the steamworks
 *     web-API auth ticket locally and hands the HOST ONLY the `ticketHex` +
 *     `identity`; the HOST runs the elftia-web exchange (`AuthApiClient.exchangeSteamTicket`)
 *     + session apply/persist and owns the NO-CLOBBER guard (a present valid
 *     session short-circuits the exchange). A NEW host method
 *     `AuthSessionService.applySteamSession(ticketHex, identity)` (no-clobber +
 *     bad-ticket guards + exchange + persist) is the adapter's real source.
 *   TOKENS-NEVER-CROSS + NO-READ (the crux): the verb returns ONLY a narrow
 *   `SteamSessionApplyResult` (`{ applied; skipped?; reason? }`) — NO token / user /
 *   session / access field crosses back; the plugin still cannot read who is signed
 *   in. The host alone holds the exchange + the persisted tokens.
 *   ADDITIVE/DORMANT this phase: nothing consumes it yet (the steam plugin's LOGIN
 *   FLIP is P3-3b-2b-ii-2; the existing core `trySteamAutoLogin` still drives boot
 *   login until the flip). NO new vocabulary token — the verb rides the EXISTING
 *   `host:auth-session` token (same port, same capability domain).
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new verb on an existing optional port + one new result
 *      type; no existing member or signature changes. The port member stays
 *      OPTIONAL — an unwired build yields `undefined` (the plugin `activate` guards,
 *      the relayApi/pluginInstaller/authSession optional-dep precedent). The new
 *      host method is additive (unused until the flip).
 *   2. Narrow-port minimality: a SECOND write verb (no read/state/token/user/gate
 *      member; the `secretsWrite` shape preserved). The host owns the exchange +
 *      no-clobber guard; no host `AuthSessionService`/`AuthApiClient` object crosses
 *      — the adapter closes over a structural sink source.
 *   3. No DOM/Node leakage: `host-api/auth-session.ts` uses `string`/`boolean`/
 *      `Promise`/plain-object only — no DOM type, no `electron`/Node type, no
 *      `@main`/`@shared` import. `backend.ts` imports it only as a type via
 *      `backend-services.ts`.
 *   4. No React/runtime dependency: type-only change (the host method is plain TS).
 *   5. Smoke coverage: `backend.smoke.ts` exercises `host.services.authSession
 *      ?.applySteamSession('deadbeef', 'desktop')` reading `.applied`/`.skipped`/
 *      `.reason`, with a `@ts-expect-error` asserting NO token/user/session field on
 *      `SteamSessionApplyResult`; the `_version` literal `'1.31.0'` → `'1.32.0'`.
 *
 * ── v1.31.0 (ADDITIVE / MINOR) ──
 * Narrow write-only session-sink port (`oss-channel-isolation` Phase 3 slice
 * P3-3b-2b-i) — ONE new OPTIONAL `AgentBackendHostServices` member on the MAIN
 * host API; the `1.30.0` surface is BYTE-UNCHANGED (a plugin built against
 * `1.0.0`–`1.30.0` still compiles):
 *   - NEW sibling module `host-api/auth-session.ts` publishing
 *     `HostAuthSessionLike`, exposed as the OPTIONAL member
 *     `AgentBackendHostServices.authSession` — EXACTLY one WRITE-ONLY verb,
 *     `setSteamColorfulDlcOwned(owned): Promise<void>`. The channel-gated Steam
 *     plugin's in-process main reads the user's Steam Colorful DLC ownership
 *     locally (steamworks `apps.isDlcInstalled`) and PUSHES it to the host so the
 *     main-side `hasColorfulAccess()` gate reflects it. The host folds `owned`
 *     into `AuthSessionState.steamColorfulDlcOwned` idempotently + emits a state
 *     update (the existing reactive entitlement path). Backed by the SAME
 *     `AuthSessionService` singleton the v1.29 `relayApi` port draws the bearer
 *     from — NO new boot dependency. A NEW host sink method
 *     `AuthSessionService.setSteamColorfulDlcOwned(owned)` (idempotent, pure data,
 *     no channel guard) is the adapter's real source.
 *   WRITE-ONLY / NO-READ (the crux): the port exposes NO session READ — no
 *   `getState`/`hasColorfulAccess`/token/user/channel. A plugin can report the one
 *   boolean it observed but can neither read who is signed in, nor the access
 *   token, nor the gate result. The `secretsWrite` single-write-verb shape.
 *   ADDITIVE/DORMANT this phase: nothing consumes it yet (the steam plugin's DLC
 *   FLIP is P3-3b-2b-i-2); this slice adds the seam + the host sink method only.
 *   ONE new vocabulary token `host:auth-session` gates `host.services.authSession`
 *   (pushing entitlement into the session is declaration-worthy; vocabulary
 *   18→19 host tokens).
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new OPTIONAL service member + one sibling module + one
 *      vocabulary token; no existing member or signature changes. The member is
 *      OPTIONAL — an unwired build yields `undefined` (the plugin `activate`
 *      guards, the relayApi/pluginInstaller optional-dep precedent). The new host
 *      sink method is additive (idempotent, unused until the FLIP).
 *   2. Narrow-port minimality: EXACTLY one write verb (no read/state/token/user/
 *      gate member — the `secretsWrite` shape). No host `AuthSessionService` object
 *      crosses; the adapter closes over a structural sink source.
 *   3. No DOM/Node leakage: `host-api/auth-session.ts` uses a plain `boolean` /
 *      `Promise<void>` only — no DOM type, no `electron`/Node type, no `@main`/
 *      `@shared` import. `backend.ts` imports it only as a type via
 *      `backend-services.ts`.
 *   4. No React/runtime dependency: type-only change (the host sink method is a
 *      pure data setter; no new dependency).
 *   5. Smoke coverage: `backend.smoke.ts` exercises `host.services.authSession
 *      ?.setSteamColorfulDlcOwned(true)` with a `@ts-expect-error` asserting NO
 *      read method / state field is exposed; the `_version` literal `'1.30.0'` →
 *      `'1.31.0'`.
 *
 * ── v1.30.0 (ADDITIVE / MINOR) ──
 * Plugin-install path + installer ports (`oss-channel-isolation` Phase 3 slice
 * P3-3b-2a) — TWO new OPTIONAL `AgentBackendHostServices` members on the MAIN
 * host API; the `1.29.0` surface is BYTE-UNCHANGED (a plugin built against
 * `1.0.0`–`1.29.0` still compiles):
 *   - NEW sibling module `host-api/plugin-paths.ts` publishing
 *     `HostPluginPathsLike`, exposed as the OPTIONAL member
 *     `AgentBackendHostServices.pluginPaths` — three SYNC read-only getters
 *     (`getPluginsRootDir` / `getPluginDataRootDir` / `getUserDataDir`) returning
 *     host-resolved ABSOLUTE path STRINGS. The channel-gated Steam plugin's
 *     in-process main resolves the SHARED plugins-install + plugin-data + userData
 *     roots through it WITHOUT importing `@main`/`ElftiaPaths`/`electron`. It is
 *     DELIBERATELY DISTINCT from the v1.12 `host.services.platformPaths` port
 *     ({@link import('./backend-native-ops').HostPlatformPathsLike}, the DS
 *     userData/agent-workspaces/bundled-resources getters, async `Promise<string>`):
 *     a DIFFERENT path domain (plugin-install roots, resolved SYNC because the host
 *     already holds them as plain strings at construction). Two narrow ports, two
 *     audited consumption sets — conflating them would widen the v1.12 port with a
 *     different shape.
 *   - NEW sibling module `host-api/plugin-installer.ts` publishing
 *     `HostPluginInstallerLike`, exposed as the OPTIONAL member
 *     `AgentBackendHostServices.pluginInstaller` — EXACTLY `installLocal({ path })`
 *     + `uninstall(id)`, backed by the host's SINGLE guardrail-bearing
 *     `PluginInstaller` (manifest validation / symlink+zip-slip+size rejection /
 *     containment-safe uninstall / trust classification). The plugin installs
 *     UNTRUSTED Workshop UGC through the host's guardrails instead of vendoring +
 *     DRIFTING a copy. The shape is PINNED to the host's `WorkshopSyncInstaller`
 *     interface so the relocated `WorkshopService` reconciliation consumes
 *     `host.services.pluginInstaller` DIRECTLY (no plugin-side wrapper);
 *     `installLocal` returns ONLY `{ id, trust, dir }` (`trust` a plain `string` —
 *     the host `PluginTrust` union is assignable, so no host enum type crosses).
 *   ADDITIVE/DORMANT this phase: nothing consumes either port yet (the steam
 *   plugin's Workshop slice is P3-3b-2a-2); this slice adds the seam only. TWO new
 *   vocabulary tokens — `host:plugin-paths` gates `host.services.pluginPaths` (it
 *   pins the shared install/userData roots where the plugin writes UGC) and
 *   `host:plugin-installer` gates `host.services.pluginInstaller` (installing
 *   untrusted Workshop UGC runs the host install pipeline). Both are
 *   declaration-worthy and NEW this release (vocabulary 16→18 host tokens); unlike
 *   the v1.12 DS `platformPaths` port, which stays unconditional low-sensitivity
 *   plumbing deliberately ABSENT from the vocabulary (see `plugin-permissions.ts`).
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: two new OPTIONAL service members + two sibling modules; no
 *      existing member or signature changes. Both members are OPTIONAL — an
 *      unwired build yields `undefined` (the plugin `activate` guards, the storage/
 *      sessionRuntime/relayApi optional-dep precedent).
 *   2. Narrow-port minimality: `pluginPaths` is THREE audited path getters (no
 *      generic `getPath(name)` passthrough, no write/mkdir/fs verb); `pluginInstaller`
 *      is the TWO Workshop-reconciliation verbs only (no inspect/git/trust/scan
 *      verb — the full `PluginInstaller` surface is NOT republished). No host
 *      `PluginInstaller`/`ElftiaPaths`/`app` object crosses — the host adapter
 *      closes over the resolved root strings + the single installer instance.
 *   3. No DOM/Node leakage: both new modules use `string`/`Promise`/opaque
 *      structural records only — no DOM type, no `electron`/Node type, no `@main`/
 *      `@shared` import. `backend.ts` imports them only as types via
 *      `backend-services.ts`.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` exercises `host.services.pluginPaths`
 *      (the three sync string getters) and `host.services.pluginInstaller`
 *      (`installLocal({ path })` reading `{ id, trust, dir }` + `uninstall(id)`),
 *      with a `@ts-expect-error` asserting no async/Promise getter on `pluginPaths`
 *      and no extra installer verb; the `_version` literal `'1.29.0'` → `'1.30.0'`.
 *
 * ── v1.29.0 (ADDITIVE / MINOR) ──
 * Generic host-guarded authed-fetch port (`oss-channel-isolation` Phase 3 slice
 * P3-3a) — ONE new OPTIONAL `AgentBackendHostServices` member on the MAIN host
 * API; the `1.28.0` surface is BYTE-UNCHANGED (a plugin built against
 * `1.0.0`–`1.28.0` still compiles):
 *   - NEW sibling module `host-api/relay-api.ts` publishing `HostRelayApiLike`,
 *     exposed as the OPTIONAL member `AgentBackendHostServices.relayApi` — a
 *     SINGLE authed-fetch verb `fetch(path, init): Promise<{ status, ok, body }>`
 *     to the elftia-web API. The channel-gated Steam plugin's in-process main
 *     half (P3-3b) calls `/api/v1/points/*` through it WITHOUT importing core
 *     internals or reading the session token.
 *   TOKEN-NEVER-CROSSES + PATH-ALLOWLIST (the crux): the HOST injects the bearer
 *   access token (from its AuthSessionService, `refreshIfNeeded`) + the
 *   elftia-web base URL, and REJECTS any path outside the allowlist BEFORE any
 *   network call (P3-3a allowlist = paths under `/api/v1/points/`; P3-3b extends
 *   it for workshop/dlc). The plugin supplies ONLY a host-relative `path` +
 *   non-auth method/headers/body (an absolute URL, a protocol-relative `//host`,
 *   or a `..` traversal is rejected) and receives ONLY `{ status, ok, body }`
 *   (raw response text — it parses JSON itself). The host sets `Authorization`
 *   LAST and STRIPS any plugin-supplied `authorization`/`Authorization` header,
 *   so the plugin can neither read nor override the bearer; no response
 *   auth/set-cookie header is echoed. New vocabulary token `host:relay-api`.
 *   ADDITIVE/DORMANT this phase: nothing consumes it yet (the steam plugin main
 *   stays a no-op scaffold that only gains the permission declaration); P3-3b
 *   flips the consumer.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new OPTIONAL service member + one sibling module + one
 *      vocabulary token; no existing member or signature changes. The member is
 *      OPTIONAL — an unwired build yields `undefined` (the plugin `activate`
 *      guards, the storage/sessionRuntime optional-dep precedent).
 *   2. Narrow-port minimality: EXACTLY one authed-fetch verb (no list/stream/
 *      abort/redirect knob; the plugin pre-serializes its body + parses the raw
 *      text). The host owns the bearer + base + path allowlist; no host service
 *      object, AuthSessionService, DB handle, or `WebContents` crosses — the
 *      adapter closes over the narrow token source + base.
 *   3. No DOM/Node leakage: `host-api/relay-api.ts` uses `string`/`number`/
 *      `boolean`/`Promise`/opaque structural records only — NO DOM
 *      `Response`/`Headers`/`Request`, no `electron`/Node type, no `@main`/
 *      `@shared` import. `backend.ts` imports it only as a type via
 *      `backend-services.ts`.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` exercises `host.services.relayApi
 *      ?.fetch('/api/v1/points/balance', { method: 'GET' })` reading
 *      `{ status, ok, body }`, with a `@ts-expect-error` asserting no
 *      token/Response-typed field is exposed; the `_version` literal `'1.28.0'`
 *      → `'1.29.0'`.
 *
 * ── v1.28.0 (ADDITIVE / MINOR) ──
 * Settings-section grouping + top-pinning (`settings-section-groups`). The
 * RENDERER `host.settings` section-contribution contract `SettingsSectionDefinitionLike`
 * (v1.20) gains TWO new OPTIONAL fields; the `1.27.0` surface is BYTE-UNCHANGED
 * (a plugin built against `1.0.0`–`1.27.0` still compiles):
 *   - NEW OPTIONAL `SettingsSectionDefinitionLike.group?: SettingsSectionGroupLike`
 *     ({@link import('./host-api/settings').SettingsSectionGroupLike} =
 *     `{ id; label: string | (() => string); icon?; order?; defaultExpanded? }`).
 *     Sections sharing the SAME `group.id` render under ONE collapsible parent
 *     nav item (reusing the host's existing `renderNavItem` children +
 *     `expandedSections` collapse machinery; the parent persists its expand
 *     state keyed by `group.id`). `group.label` is a plugin-resolved string or a
 *     per-render thunk (plugin i18n; NEVER a renderer i18n key). Absent ⇒ the
 *     section stays FLAT (unchanged appended-last behavior).
 *   - NEW OPTIONAL `SettingsSectionDefinitionLike.pinToTop?: boolean`. When
 *     truthy, the section — or, if grouped, its collapsible parent — renders in
 *     the TOP block ABOVE the built-in nav groups (ordered by the unified key:
 *     `group.order` for groups, `order` for flats). Absent/false ⇒ LEGACY
 *     appended-last placement (no regression for un-pinned contributors —
 *     hello-sample stays flat-and-last). A group is top-pinned iff ANY member sets it.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: two NEW OPTIONAL fields on an existing interface + one NEW
 *      sibling interface (`SettingsSectionGroupLike`); no existing member or
 *      signature changes. Both fields are OPTIONAL — a plugin omitting them, or
 *      an old host ignoring them, behaves exactly as v1.20 (flat, appended-last).
 *   2. Narrow-port minimality: `SettingsSectionGroupLike` is `{ id, label }`
 *      REQUIRED + 3 OPTIONAL nav-presentation fields (icon/order/defaultExpanded)
 *      only — no capability, no host service, no DB/dialog/WebContents crosses;
 *      `pinToTop` is a single placement boolean. The group id is plugin-local
 *      (nav bucketing only), not host-namespaced.
 *   3. No DOM/Node leakage: `host-api/settings.ts` imports ONLY `./_shared`
 *      (`HostReactNode` + `HostUnregister`); `group.icon` is the lib-agnostic
 *      `HostReactNode` (the section `icon` precedent); no `react` runtime dep,
 *      no `electron`/Node type, no `@main`/`@shared` import.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `renderer.smoke.ts` exercises a `registerSection`
 *      carrying a `group` (label thunk + order + defaultExpanded) AND
 *      `pinToTop: true`; the `_version` literal `'1.27.0'` → `'1.28.0'`.
 *
 * ── v1.27.0 (ADDITIVE / MINOR) ──
 * BYO model-test + secrets-pack host surfaces (`byo-p2-llm-2` — the 3 LLM features
 * sliced from byo-p2-llm: ModelTest + MigrationPack + TransformerConfig). ONE new
 * OPTIONAL `AgentBackendHostServices` member + ONE new method on the existing
 * `llmConfig` port; the `1.26.0` surface is BYTE-UNCHANGED (a plugin built against
 * `1.0.0`–`1.26.0` still compiles):
 *   - The EXISTING `HostLlmConfigLike` port (v1.21) gains `testModel(providerId,
 *     modelId): Promise<HostModelTestResult>` — a provider/model CONNECTIVITY
 *     DIAGNOSTIC ({@link import('./host-api/llm-config').HostModelTestResult} =
 *     `{ success, message, response?, model, durationMs? }`). NO-SECRET-IN-OR-OUT:
 *     the host sends a trivial "Hello" with the host-resolved key; the key never
 *     appears in the request or the return. Reuses the EXISTING `host:llm-config`
 *     token (same domain — a provider/model op; NO new token). Delegates to the
 *     same body the host `completion.testModel` IPC uses.
 *   - NEW sibling module `host-api/secrets-pack.ts` publishing `HostSecretsPackLike`,
 *     exposed as the OPTIONAL member `AgentBackendHostServices.secretsPack` — the
 *     ENCRYPTED credential MIGRATION PACK (`export({passphrase})` /
 *     `import({passphrase})`, the `.epack` round-trip). PASSPHRASE-IN, COUNTS/PATH/
 *     STATUS-OUT (the security crux): the host runs the native save/open dialog +
 *     ALL encryption/decryption + the file I/O + the ingest entirely main-side; the
 *     plugin passes ONLY a passphrase and receives ONLY `{ success, path? | imported:
 *     counts, canceled?, message? }`. NO return type can carry a plaintext key, a
 *     token, the encrypted blob, or the passphrase ({@link
 *     import('./host-api/secrets-pack').HostSecretsPackImportCounts} has counts +
 *     a `skipped` name list only). The plugin inherits the SAME boundary the host
 *     renderer already has — no new exposure. New vocabulary token `host:secrets-pack`,
 *     DISTINCT from `host:secrets-write` (per-ref plaintext writes — a different
 *     capability). Delegates to the host's `SecretsPackService` (the same body
 *     `secretsPack:*` uses; the dialog + codec + service are shared via the
 *     `runSecretsPackExport`/`runSecretsPackImport` flow helper).
 *   - TransformerConfig (the 3rd sliced feature) needs NO host surface — it is a
 *     pure controlled component (bundled `BUILTIN_TRANSFORMERS` + provider-body
 *     persistence via the existing `updateProvider`). It rides this same release
 *     only for the un-stub; it adds NO port, method, or token.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one NEW optional method on an existing optional port + one
 *      NEW OPTIONAL service member + one sibling module + one vocabulary token; no
 *      existing member or signature changes. The new member is OPTIONAL — an
 *      unwired build yields `undefined` (the plugin `activate` guards, the storage/
 *      sessionRuntime optional-dep precedent).
 *   2. Narrow-port minimality: `testModel` is the ONLY completion verb the BYO UI
 *      needs (folded into `llmConfig`, NOT a one-method `completion` port); the
 *      `secretsPack` port mirrors the audited `secretsPack:*` two-verb set only (no
 *      collect/seal/codec verb — those stay host-side); the adapters delegate to the
 *      host's `CompletionService.testModel` + `SecretsPackService`. No host service
 *      object, DB handle, native dialog, codec, or `WebContents` crosses.
 *   3. No DOM/Node leakage: the new method + the new module use `string`/`number`/
 *      `boolean`/`Promise`/opaque structural records only; no `electron`/Node type,
 *      no `@main`/`@shared` import. `backend.ts` imports the module only as types
 *      via `backend-services.ts`.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` exercises `host.services.llmConfig
 *      .testModel(...)` (asserts the diagnostic shape carries no secret-bearing
 *      field) and `host.services.secretsPack.export/import(...)` (asserts the return
 *      is counts/path/status only — a `@ts-expect-error` confirms no key/token/blob
 *      field is typeable); the `_version` literal `'1.26.0'` → `'1.27.0'`.
 *
 * ── v1.26.0 (ADDITIVE / MINOR) ──
 * BYO CLI/subscription host ports (`byo-p2-subscription`, the LAST + largest P2 UI
 * block — the only P2 UI child that touches the host). TWO new OPTIONAL
 * `AgentBackendHostServices` members + manual-token verbs on the existing
 * subscription-auth port; the `1.25.0` surface is BYTE-UNCHANGED (a plugin built
 * against `1.0.0`–`1.25.0` still compiles):
 *   - NEW sibling module `host-api/agent-config.ts` publishing `HostAgentConfigLike`,
 *     exposed as the OPTIONAL member `AgentBackendHostServices.agentConfig` — the
 *     cli-related `MagiConfig` sub-settings (`getCliBackendConfig`/`setCliBackendConfig`
 *     over `cliBackendId`/`cliTimeout`/`cliPtyMode`/`cliPtyCols`/`cliPtyRows`) the
 *     relocated "Code CLI" sub-settings panel writes, so the host owns no cli
 *     sub-settings UI. THE GENERAL ENGINE FIELD STAYS HOST: the port DELIBERATELY
 *     does NOT expose `agentBackend` (`HostCliBackendConfig.agentBackend` is `?: never`
 *     — a payload carrying it fails to type-check; the adapter strips it again at
 *     runtime). Engine selection is an execution concern present in all builds; a
 *     plugin cannot flip the engine. Delegates to `magi.getConfig`/`magi.updateConfig`.
 *     New vocabulary token `host:agent-config`.
 *   - NEW sibling module `host-api/cli-runtime.ts` publishing `HostCliRuntimeLike`,
 *     exposed as the OPTIONAL member `AgentBackendHostServices.cliRuntime` — the
 *     Code CLI availability/install/launch surface (`getAuthStatus`/`setEnabled`/
 *     `install`/`launchTerminal`/`listBackends`, mirroring `window.native.codeCli.*`)
 *     the relocated runtime UI drives. NO-CREDENTIAL-ON-RETURN: `getAuthStatus`
 *     returns availability DESCRIPTORS only (installed/authenticated/backendId +
 *     display fields, never a token); install/launch are host-run actions returning
 *     `{ ok, error? }`. Delegates to the host's existing `codeCli:*` runtime. New
 *     vocabulary token `host:cli-runtime`.
 *   - The EXISTING `HostSubscriptionAuthLike` port (v1.22) gains the manual-token
 *     write verbs `setClaudeManualToken`/`setCodexManualToken`/`setGeminiManualToken`/
 *     `updateClaudeSubscriptionLevel` (deferred from v1 as "write-in only, additive
 *     later"). INWARD-only: the pasted token/level is consumed host-side into the
 *     encrypted `account-tokens` store; the status-only return echoes NO token —
 *     fitting the no-token-OUT invariant exactly. No new token (uses `host:subscription-auth`).
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: two new OPTIONAL service members + two sibling modules + four
 *      verbs on an existing optional port; no existing member or signature changes.
 *      Both new members are OPTIONAL — an unwired build yields `undefined` (the
 *      plugin `activate` guards, the storage/sessionRuntime optional-dep precedent).
 *   2. Narrow-port minimality: `agentConfig` exposes ONLY the 5 audited cli keys
 *      (NOT the general `agentBackend` — it is `?: never`); `cliRuntime` mirrors the
 *      audited `codeCli:*` verb set (no PTY-data/resize/session-list verbs — those
 *      stay host/execution-side); the manual-token verbs are write-in only. No host
 *      service object, DB handle, or `WebContents` crosses — the adapters delegate
 *      to the host's `magi` options service + the `codeCli:*` runtime + `TokensService`.
 *   3. No DOM/Node leakage: the new modules use `string`/`number`/`boolean`/`Promise`/
 *      opaque structural records only; no `electron`/Node type, no `@main`/`@shared`
 *      import. `backend.ts` imports them only as types via `backend-services.ts`.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` exercises `host.services.agentConfig`
 *      (a `getCliBackendConfig` read + a `setCliBackendConfig` write; a
 *      `@ts-expect-error` asserts `agentBackend` is NOT a settable patch field),
 *      `host.services.cliRuntime` (getAuthStatus descriptors + setEnabled/install/
 *      launchTerminal/listBackends), and the manual-token verbs (status-only); the
 *      `_version` literal `'1.25.0'` → `'1.26.0'`.
 *
 * ── v1.25.0 (ADDITIVE / MINOR) ──
 * Media-config port key-write hardening (`byo-media-secret-hardening`). The
 * `host.services.mediaConfig` port (v1.23) gains ONE new method and narrows one
 * patch field — additive-compatible (no shipped plugin depended on the dropped
 * inbound field; the port already MASKED `apiKey` out of every RETURN at v1.23):
 *   - NEW `HostMediaConfigLike.setProviderKey(mediaType, id, apiKey)` — the ONLY
 *     way to write a media provider key. It routes through the EXISTING guarded
 *     `host.services.secretsWrite` under the per-type `media-<type>:<id>:apiKey`
 *     ref (the 5 prefixes are now in `BYO_SECRET_NAMESPACE_PREFIXES`), via the
 *     SHARED `setMediaProviderKey` body the renderer one-way channel also calls
 *     (no fork; NOT a second write port). An empty `apiKey` clears the secret.
 *     Returns `{ success, error? }` only — never the key.
 *   - `HostMediaProviderUpdate.apiKey` is now `?: never` (the key is no longer a
 *     patch field — it must go through `setProviderKey`). This narrows an INBOUND
 *     field no shipped plugin relied on (the v1.23 port already returned masked
 *     providers; the only correct write avenue is now `setProviderKey`).
 *   GUARDED-WRITE REUSE: like the search knife (UNLIKE the v1.23 media port's
 *   then-plaintext-DB-column posture), the key write routes through the EXISTING
 *   `secretsWrite` path — media is now a SecretsService secret-ref domain, so the
 *   port touches `secretsWrite` (the rule: a port touches `secretsWrite` iff its
 *   domain's secret lives behind a SecretsService ref). No new vocabulary token
 *   (`host:media-config` + `host:secrets-write` already exist).
 * Freeze checklist (the 5 points):
 *   1. Additive-compatible: one NEW optional method on an existing optional port
 *      + one inbound-patch narrowing no shipped plugin depended on. The port
 *      member stays OPTIONAL on `AgentBackendHostServices` (unwired ⇒ undefined).
 *   2. Narrow-port minimality: `setProviderKey` mirrors the audited one-way media
 *      key write; no host service or secret store object crosses (the adapter
 *      delegates to the shared `setMediaProviderKey` + the host secret store).
 *   3. No DOM/Node leakage: the new method + result use `string`/`boolean`/
 *      `Promise` only; no `electron`/Node type, no `@main`/`@shared` import.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` exercises `host.services.mediaConfig
 *      .setProviderKey(...)` and asserts (via `@ts-expect-error`) that the
 *      `updateProvider` patch's `apiKey` is NOT settable; the `_version` literal
 *      `'1.24.0'` → `'1.25.0'`.
 *
 * ── v1.24.0 (ADDITIVE / MINOR) ──
 * BYO web-search-provider config port (`byo-port-search-config` D1/D2, the FINAL
 * P1 knife) — ONE new OPTIONAL `AgentBackendHostServices` member on the MAIN host
 * API; the `1.23.0` surface is BYTE-UNCHANGED (a plugin built against
 * `1.0.0`–`1.23.0` still compiles):
 *   - NEW sibling module `host-api/search-config.ts` publishing
 *     `HostSearchConfigLike`, exposed as the OPTIONAL member
 *     `AgentBackendHostServices.searchConfig` — the API-KEY web-search providers
 *     (tavily/jina/zhipu(+z.ai)/grok/searxng/exa/bocha): non-secret config
 *     (`configureProvider`/`configureProviders`, NO inbound `apiKey`), status
 *     reads (`getProviders`/`getProviderConfig`/`isProviderEnabled`/`validate`),
 *     and a thin `setProviderKey(providerId, apiKey)`. The surface a future
 *     `byo-providers` plugin drives so the host owns no BYO web-search-config UI.
 *     The KEYLESS `local-*` providers, `search` query execution, and login-window
 *     verbs are deliberately ABSENT (host/execution-side, out of scope).
 *   NO-SEARCH-KEY-ON-RETURN (the crux): no method returns a search key.
 *   `getProviderConfig` inherits `WebSearchService`'s strip, and its config return
 *   type masks `apiKey` out structurally (`HostMaskedSearchProviderConfig.apiKey`
 *   is `?: never`, so a forgotten strip fails to type-check); `setProviderKey`
 *   returns `{ success, error? }` only and the inbound key is consumed host-side.
 *   GUARDED-WRITE REUSE: UNLIKE the media knife (DB columns), the key write routes
 *   through the EXISTING guarded secrets path — `setProviderKey` performs the SAME
 *   bundled op as `webSearch:setProviderKey` (`SecretsService.setSecret`/
 *   `deleteSecret` under the `search-provider:<id>:apiKey` ref, ALREADY in
 *   `BYO_SECRET_NAMESPACE_PREFIXES`, then reconfigure for the Jina sync). The
 *   bundled body is a SINGLE shared fn (`setSearchProviderKey`) called by BOTH the
 *   IPC handler and the port adapter (no fork; the IPC stays byte-identical). It
 *   does NOT re-add `search-provider:` to the SSOT and does NOT create a second
 *   write port. The existing `webSearch:*` IPC channels + the web-search settings
 *   UI stay fully functional (dual-track; deletion is a future P3 run).
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new OPTIONAL service member + one sibling module; no
 *      existing member or signature changes. The member is OPTIONAL — an unwired
 *      build yields `undefined` (the plugin `activate` guards, the storage/
 *      sessionRuntime optional-dep precedent).
 *   2. Narrow-port minimality: the port mirrors the audited `webSearch:*` CONFIG
 *      verb set only (no `search`/`localSearch`/`jinaReader`/login-window verbs);
 *      no host `WebSearchService` object or secret store crosses (the adapter
 *      delegates to the host service + the shared `setSearchProviderKey`).
 *   3. No DOM/Node leakage: the new module uses `string` / `boolean` / `Promise` /
 *      opaque structural records only; no `electron`/Node type, no `@main`/
 *      `@shared` import. `backend.ts` imports it only as a type via
 *      `backend-services.ts`.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` exercises `host.services.searchConfig`
 *      (a masked `getProviderConfig` read asserts `config.apiKey` is NOT typeable
 *      via `@ts-expect-error`; `setProviderKey` returns status); the `_version`
 *      literal `'1.23.0'` → `'1.24.0'`.
 *
 * ── v1.23.0 (ADDITIVE / MINOR) ──
 * BYO media-provider config port (`byo-port-media-config` D1/D2) — ONE new
 * OPTIONAL `AgentBackendHostServices` member on the MAIN host API; the `1.22.0`
 * surface is BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.22.0` still
 * compiles):
 *   - NEW sibling module `host-api/media-config.ts` publishing
 *     `HostMediaConfigLike`, exposed as the OPTIONAL member
 *     `AgentBackendHostServices.mediaConfig` — a FLAT `mediaType`-discriminated
 *     surface (`'image'|'video'|'music'|'tts'|'asr'`) covering all five
 *     media-provider types: `listProviders`/`getProvider`/`updateProvider`/
 *     `toggleProvider`/`createCustomProvider`/`deleteProvider`/`getGlobalSettings`/
 *     `setGlobalSettings`/`refreshUpstreamModels(mediaType, …)` + image-only
 *     `resetProviderToDefaults(id)`. Model management rides `updateProvider`'s
 *     patch (`models`/`modelGroups`); default selection rides `updateProvider`/
 *     `setGlobalSettings`. The surface a future `byo-providers` plugin drives so
 *     the host owns no BYO media-config UI.
 *   MASK-ON-RETURN (the crux): EVERY provider the port returns has `config.apiKey`
 *   stripped — enforced both at the adapter boundary AND structurally
 *   (`HostMaskedMediaProviderConfig.apiKey` is `?: never`, so a forgotten strip
 *   fails to type-check). An inbound user key (`updateProvider`/`createCustomProvider`
 *   `apiKey`) is consumed host-side and NEVER echoed. UNLIKE the LLM knife this
 *   port does NOT touch `secretsWrite` / `byo-secret-namespaces.ts` — media keys
 *   are PLAINTEXT DB COLUMNS, not BYO secret-refs (the plugin writes a key via the
 *   port's `updateProvider`, the host writes the DB column exactly as the existing
 *   IPC). The legacy `mediaProviders.*` IPC return posture (which DOES leak the
 *   key — a known pre-existing at-rest gap deferred to a future hardening knife) is
 *   left BYTE-IDENTICAL (dual-track).
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new OPTIONAL service member + one sibling module; no
 *      existing member or signature changes. The member is OPTIONAL — an unwired
 *      build yields `undefined` (the plugin `activate` guards, the storage/
 *      sessionRuntime optional-dep precedent).
 *   2. Narrow-port minimality: the flat discriminated surface mirrors the audited
 *      `mediaProviders.<type>.*` IPC verb set; no host ConfigService object or DB
 *      handle crosses (the adapter delegates to the host's 5 ConfigServices +
 *      generation services). The 5 surfaces are near-identical → flat over
 *      5×-duplicated sub-handles.
 *   3. No DOM/Node leakage: the new module uses `string` / `boolean` / `Promise` /
 *      opaque structural records only; no `electron`/Node type, no `@main`/
 *      `@shared` import. `backend.ts` imports it only as a type via
 *      `backend-services.ts`.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` exercises `host.services.mediaConfig`
 *      across all five `mediaType`s (a masked read asserts `config.apiKey` is NOT
 *      typeable via `@ts-expect-error`); the `_version` literal `'1.22.0'` →
 *      `'1.23.0'`.
 *
 * ── v1.22.0 (ADDITIVE / MINOR) ──
 * BYO subscription/OAuth/CLI-account port (`byo-port-subscription-auth` D1/D2) —
 * ONE new OPTIONAL `AgentBackendHostServices` member on the MAIN host API; the
 * `1.21.0` surface is BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.21.0`
 * still compiles):
 *   - NEW sibling module `host-api/subscription-auth.ts` publishing
 *     `HostSubscriptionAuthLike`, exposed as the OPTIONAL member
 *     `AgentBackendHostServices.subscriptionAuth` — OAuth flow initiation
 *     (`getClaudeAuthParams`/`getClaudeSetupAuthParams`/`getCodexAuthParams`/
 *     `getGeminiAuthParams` + the matching `exchange*Token`), CLI import
 *     (`importFromExternalCli`/`get`/`setCliAutoImport`), account management
 *     (`getSanitized`/`listAccounts`/`setActiveAccount`/`removeAccount`/
 *     `updateAccountLabel`/`applyAccountToCli`/`refreshAccount`/`clearConfig`),
 *     and subscription/OpenCodeGo (`listSubscriptions`/`subscriptionStatus`/
 *     `setOpenCodeGoConfig`/`addOpenCodeGoAccount`/`clearOpenCodeGo`/
 *     `refreshCredential`) — the surface the future `byo-providers` plugin drives
 *     so the host owns no subscription-sign-in UI.
 *   TOKEN-NEVER-CROSSES (the crux): no method returns an access/refresh/id/setup
 *   token or api key. OAuth init returns `{ authUrl, state }` ONLY — the PKCE
 *   `code_verifier` STAYS HOST-SIDE (retained keyed by `state`, never in
 *   `HostOAuthInitParams`); at exchange the plugin relays back ONLY the
 *   short-lived authorization `code` (+ `state`) and the host looks the verifier
 *   up by `state` and runs `exchangeCodeForTokens` itself. Reads return sanitized
 *   `has*Token` descriptors; exchange/refresh/mutate return status only. An
 *   inbound user key (`setOpenCodeGoConfig.apiKey`) is consumed host-side and
 *   NEVER echoed. UNLIKE the LLM knife, this port does NOT touch `secretsWrite` /
 *   `byo-secret-namespaces.ts` — subscription tokens live in the host's OWN
 *   encrypted `account-tokens` electron-store, not a BYO secret-ref.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new OPTIONAL service member + one sibling module; no
 *      existing member or signature changes. The member is OPTIONAL — an unwired
 *      build yields `undefined` (the plugin `activate` guards, the storage/
 *      sessionRuntime optional-dep precedent).
 *   2. Narrow-port minimality: the port mirrors the audited `auth:providerTokens.*`
 *      / `auth:subscription.*` IPC verb set (no manual raw-token paste setters —
 *      host-UI-only, additive later). No host service object or DB handle crosses;
 *      the adapter delegates to the host `TokensService`.
 *   3. No DOM/Node leakage: the new module uses `string` / `boolean` / `Promise` /
 *      opaque structural records only; no `electron`/Node type, no `@main`/
 *      `@shared` import. `backend.ts` imports it only as a type via
 *      `backend-services.ts`.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` exercises `host.services.subscriptionAuth`
 *      (OAuth init reads `{ authUrl, state }` — NO `codeVerifier` field is
 *      typeable; exchange/refresh/mutate return status; reads return sanitized
 *      descriptors); the `_version` literal `'1.21.0'` → `'1.22.0'`.
 *
 * ── v1.21.0 (ADDITIVE / MINOR) ──
 * BYO LLM-config + write-only secrets ports (`byo-port-llm-config` D1/D2/D4) —
 * TWO new OPTIONAL `AgentBackendHostServices` members on the MAIN host API; the
 * `1.20.0` surface is BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.20.0`
 * still compiles):
 *   - NEW sibling module `host-api/llm-config.ts` publishing `HostLlmConfigLike`,
 *     exposed as the OPTIONAL member `AgentBackendHostServices.llmConfig` — the
 *     LLM provider config CRUD (`getProviders`/`getProvider`/`addProvider`/
 *     `updateProvider`/`deleteProvider`/`toggleProvider`/`reorderProviders`/
 *     `resetProvider`/`discoverModels`), presets (`getProviderPresets`/
 *     `addFromPreset`), multi-key pool (`getApiKeys`/`addApiKey`/`updateApiKey`/
 *     `deleteApiKey`/`toggleApiKey`/`getKeyHealth`), and default-model router
 *     config (`getRouterConfig`/`setRouterConfig`) surface the future
 *     `byo-providers` plugin drives. MASK-ON-RETURN: every provider/key return
 *     is the SAME renderer-masked projection the existing IPC handlers return
 *     (`toRendererProvider`/`toRendererEntry`) — a literal key blanked, a `$VAR`
 *     ref preserved, `hasKey`/`keyHint` only; no method returns a plaintext key.
 *     Bulk `import`/`export` config is DELIBERATELY omitted from v1 (a host-app
 *     concern; additive later).
 *   - NEW sibling module `host-api/secrets-write.ts` publishing
 *     `HostSecretsWriteLike`, exposed as the OPTIONAL member
 *     `AgentBackendHostServices.secretsWrite` — a WRITE-ONLY surface with
 *     EXACTLY `setSecret(ref, value): Promise<void>` (no `getSecret`/list/
 *     return-bearing member). The host adapter guards `ref` against the shared
 *     `@elftia/shared` BYO namespace-prefix allowlist (`isAllowedByoSecretRef`)
 *     and rejects a foreign ref before any store interaction. The media/search/
 *     subscription knives REUSE this port (they extend the shared allowlist, not
 *     the surface).
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: two new OPTIONAL service members + two sibling modules; no
 *      existing member or signature changes. Both members are OPTIONAL — an
 *      unwired build yields `undefined` (the plugin `activate` guards, the
 *      storage/sessionRuntime optional-dep precedent).
 *   2. Narrow-port minimality: `llmConfig` mirrors the audited IPC verb set (no
 *      bulk import/export); `secretsWrite` is a single write verb (no read/list).
 *      No host service object, DB handle, or `ApiKeyPoolService` interface
 *      crosses — the adapter delegates to the host's services and the shared
 *      `poolKeyOps` module.
 *   3. No DOM/Node leakage: both new modules use `string` / `Promise` / opaque
 *      structural records only; no `electron`/Node type, no `@main`/`@shared`
 *      import. `backend.ts` imports them only as types via `backend-services.ts`.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` reads `host.services.llmConfig` (a
 *      provider CRUD + key-pool + router-config probe) and
 *      `host.services.secretsWrite.setSecret`; the `_version` literal
 *      `'1.20.0'` → `'1.21.0'`.
 *
 * ── v1.20.0 (ADDITIVE / MINOR) ──
 * Settings contribution point (`byo-settings-ext-point` D4) — ONE new
 * RENDERER member; the `1.19.0` surface is BYTE-UNCHANGED (a plugin built
 * against `1.0.0`–`1.19.0` still compiles):
 *   - NEW sibling module `host-api/settings.ts` publishing the settings-
 *     section registration port, exposed as ONE new member
 *     `AgentUiHostApi.settings` (`AgentUiSettings`):
 *     `registerSection(def: SettingsSectionDefinitionLike): HostUnregister`.
 *     The def pins `id` + `label: string | (() => string)` + optional
 *     `icon`/`order` + `render(ctx): HostReactNode` (`ctx` =
 *     `HostSettingsSectionContext`, an opaque extensible record). Routes to
 *     the host `settingsSectionStore` (`registerSettingsSection`); the host
 *     factory injects `pluginId` and keys the entry
 *     `plugin:<pluginId>:<sectionId>` (no namespace forgery). The settings
 *     page appends a dynamic nav group after the built-in groups and renders
 *     the panel lazily inside the host plugin error boundary.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new renderer member + one sibling module; no
 *      existing member or signature changes. The new `settings` member is
 *      NON-OPTIONAL — the host always provides it and an old plugin simply
 *      does not consume it.
 *   2. Narrow-port minimality: exactly one registration verb; rendering, nav
 *      placement, lazy-mount, and error isolation stay host-owned; the v1
 *      render ctx is an empty reserved record (no capability leaks).
 *   3. No DOM/Node leakage: `host-api/settings.ts` imports only `./_shared`
 *      (`HostReactNode` + `HostUnregister`); `backend.ts` untouched.
 *   4. No React/runtime dependency: `render`/`icon` use the structural
 *      `HostReactNode`; type-only change.
 *   5. Smoke coverage: `renderer.smoke.ts` registers a section (label thunk +
 *      icon + order + render) and the `_version` literal `'1.19.0'` →
 *      `'1.20.0'`; backend smoke untouched.
 *
 * ── v1.19.0 (ADDITIVE / MINOR) ──
 * Chat-session lower-bound enrichment (`ds-extract-3-sdk-structural-types` D1)
 * — OPTIONAL fields on two existing structural session shapes, one on each
 * half; the `1.18.0` surface is BYTE-UNCHANGED (a plugin built against
 * `1.0.0`–`1.18.0` still compiles):
 *   - `HostChatSessionLike` (`backend.ts`, main) and `HostChatSessionRef`
 *     (`host-api/stores.ts`, renderer) each gain OPTIONAL
 *     `projectPath?: string | null` and `settings?: HostChatSessionSettingsLike`.
 *     Both fields were previously reachable only via the shapes' opaque index
 *     signatures — naming them is a type REFINEMENT (the session-kinds v1.18
 *     precedent), not a widening of what crosses the boundary.
 *   - NEW `HostChatSessionSettingsLike` in `host-api/_shared.ts` (lib-agnostic,
 *     so the main and renderer modules can share it without importing each
 *     other) pinning ONLY `designConfig?: unknown`. Deliberately NO index
 *     signature: the host canonical `ChatSessionSettings` is an `interface`
 *     (no implicit index signature), so an indexed bound would break host
 *     satisfaction.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: two optional fields on each of two existing shapes plus
 *      one new shared interface; no member removed or re-narrowed, no
 *      signature changes.
 *   2. Narrow-port minimality: exactly the two session members a session-
 *      handling plugin (DS) reads beyond `id` (`projectPath` root resolution +
 *      the `settings.designConfig` blob); writes still go through the existing
 *      `unknown`-typed channels, nothing else crosses.
 *   3. No DOM/Node leakage: the new types use `string`/`null`/`unknown` only;
 *      `_shared.ts` stays lib-agnostic; `backend.ts` and `stores.ts` still
 *      never import each other.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` reads `session.projectPath` +
 *      `session.settings?.designConfig` off a `HostChatSessionLike`;
 *      `renderer.smoke.ts` reads the same pair off a `HostChatSessionRef`; the
 *      `_version` literal `'1.18.0'` → `'1.19.0'`. Host satisfaction is proven
 *      TYPE-ONLY at the two wiring boundaries (renderer `hostStores.ts`, main
 *      `ChatStreamHandler.ts`).
 *
 * ── v1.18.0 (ADDITIVE / MINOR) ──
 * Session-kind generalization ports (`ds-extract-1c-kind-generalize`): ONE new
 * RENDERER member + OPTIONAL fields on two existing renderer registration
 * input types; the `1.17.0` surface is BYTE-UNCHANGED (a plugin built against
 * `1.0.0`–`1.17.0` still compiles):
 *   - NEW sibling module `host-api/session-kinds.ts` publishing the
 *     per-sessionType BEHAVIOR registration port, exposed as ONE new member
 *     `AgentUiHostApi.sessionKinds` (`AgentUiSessionKinds`):
 *     `register(behavior: SessionKindBehaviorLike): HostUnregister`. The
 *     behavior record pins `kind` + `agentLike` and the optional flags
 *     `inputProfile: 'chat'` / `workspaceView` / `organizerBucket` /
 *     `stripInlineArtifacts`. Routes to the host `sessionKindStore` (per-kind
 *     last-registration-wins, leak-safe unregister). The host's chat / panel /
 *     workspace surfaces consult the flags instead of `sessionType==='design'`
 *     literals; no registration ⇒ flags falsy ⇒ plain-chat degradation (R5).
 *   - `AgentPageDefinitionLike` gains FOUR optional legacy-alias fields
 *     (`legacyPath` / `legacyVisibilityKey` / `railTestId` /
 *     `legacyNewChatParam`) so a plugin page reproduces the pre-decoupling
 *     host route/rail/testid/`?new=` shims as descriptor DATA. Absent ⇒ prior
 *     behavior.
 *   - `WorkspaceDefinitionLike` gains the optional `previewToggle`
 *     (`HostWorkspacePreviewToggle`: `altView` + `toLabelKey` / `fromLabelKey`
 *     + optional `testId`) — declarative metadata for the host toolbar's
 *     generic view-flip control (replaces the hardcoded design↔html toggle).
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new renderer member + one sibling module + optional
 *      fields on two input types; no existing member or signature changes.
 *      The new `sessionKinds` member is NON-OPTIONAL — the host always
 *      provides the full object and an old plugin simply does not consume it
 *      (the `newChat`/`agentEvents`/`sessionEffects` precedent). The new
 *      fields were previously reachable only via the opaque index signature;
 *      naming them is a type REFINEMENT, not a widening of what crosses.
 *   2. Narrow-port minimality: `sessionKinds` carries a flags DATA record
 *      only (the audited set of host branch points the `'design'` literals
 *      gated); the alias/preview fields are static strings known at
 *      registration. No host store object, callback, or React handle crosses.
 *   3. No DOM/Node leakage: every published type uses `string` / `boolean` /
 *      `HostUnregister` only; the new module imports ONLY `./_shared`.
 *   4. No React/runtime dependency: type-only; no runtime dependency added.
 *   5. Smoke coverage: `renderer.smoke.ts` exercises
 *      `host.sessionKinds.register({ kind:'design', agentLike:true, … })` +
 *      a `page.register` def carrying the four alias fields + a
 *      `workspace.register` def carrying `previewToggle`; the `_version`
 *      literal `'1.17.0'` → `'1.18.0'`.
 *
 * ── v1.17.0 (ADDITIVE / MINOR) ──
 * Host-resolved engine for spec-session dispatch (`design-engine-residue`):
 * ONE param WIDENING on the BACKEND host API; every other surface is
 * BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.16.0` still compiles):
 *   - `HostSessionRuntimeLike.dispatchSpecSession` `engineType` param widens
 *     `string` → `string | undefined`. `undefined` ⇒ the HOST resolves the
 *     engine from its live bound session row (explicit row `engineType` →
 *     cli-backend routing → default executor). A plugin passes a string ONLY
 *     to forward an explicit user-chosen engine — it never computes, defaults,
 *     or hardcodes one (agent definitions do not pin backends; engine
 *     selection is host dispatch policy).
 * WHY A WIDENING (not a new member): the method's ownership already said
 * "host-owned dispatch"; requiring the plugin to SUPPLY the engine leaked
 * dispatch policy into plugin code (Design Studio grew a local engine
 * resolver — the exact coupling the contract exists to prevent). Param
 * widening is compile-compatible for every existing caller (a `string`
 * argument still satisfies `string | undefined`).
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one param type widening; no member added/removed; every
 *      existing plugin call site (passing a string) compiles unchanged.
 *   2. Narrow-port minimality: no new capability — the host already held the
 *      live session row this resolution reads; nothing else crosses.
 *   3. No DOM/Node leakage: the widened param is `string | undefined`.
 *   4. No React/runtime dependency: type-only change.
 *   5. Smoke coverage: `backend.smoke.ts` exercises a `dispatchSpecSession`
 *      call with `undefined` engineType; the `_version` literal
 *      `'1.16.0'` → `'1.17.0'`.
 *
 * ── v1.16.0 (ADDITIVE / MINOR) ──
 * Page-level session-effect registration port (`ds-design-session-mount-move`)
 * — ONE addition to the RENDERER host API; the `1.15.0` surface is
 * BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.15.0` still compiles):
 *   - NEW sibling module `host-api/session-effects.ts` publishing the
 *     page-level session-effect registry port, exposed as ONE new member
 *     `AgentUiHostApi.sessionEffects` (`AgentUiSessionEffects`):
 *     `registerSessionEffect(def): HostUnregister` — register a
 *     `SessionEffectDefinitionLike` (pins a REQUIRED `kind` + `Effect`
 *     component). Routes to `registerSessionEffect` (the host
 *     `sessionEffectStore`, per-kind last-registration-wins). The host mounts
 *     the `Effect` (keyed on `(kind, sessionId)`) at the chat-PAGE level while a
 *     session of `kind` is active, passing a `HostSessionEffectContext`
 *     (structural lower bound: `sessionId` required; `projectRoot`/`projectId`
 *     `string | null`; `sourceSkillId?`/`designSystemId?`/`mode?` optional; a
 *     narrow `workspace` affordance `HostSessionEffectWorkspace` exposing ONLY
 *     `setView`/`setVisible`/`setActiveArtifact`, the latter accepting a
 *     `HostActiveArtifactPayload`). The host OWNS the mount lifecycle, keeping
 *     the effect alive across workspace-slot remounts.
 * WHY A NEW PORT: every existing renderer register surface
 * (`hello`/`workspace`/`page`/`sessionGroup`/`chatPanel`/`newChat`) is
 * SLOT/PANEL-level — none survives a workspace-slot remount. The design-session
 * streaming bridge must mount PAGE-level so a late slot mount never drops
 * mid-stream chunks (the load-bearing property). PORT-ONLY: nothing consumes it
 * yet — the host's own design-session page-level mount stays live and
 * byte-unchanged; a later slice (3b) flips the consumer.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new renderer member + one sibling module; no existing
 *      member or signature changes (the v1 8 + v1.1/v1.2/v1.4/v1.13/v1.15
 *      members and the entire `AgentBackendHostApi` + the v1.14 `deactivate`
 *      export are byte-unchanged). The new `sessionEffects` member is
 *      NON-OPTIONAL — the host always provides the full object, and an old
 *      plugin simply does not consume it (the `agentEvents`/`newChat`/
 *      `chatPanel` precedent), so existing plugins keep compiling.
 *   2. Narrow-port minimality: the port exposes ONLY `registerSessionEffect(def):
 *      HostUnregister`; the def pins `kind` + `Effect`; the context pins the 7
 *      design inputs (`sessionId`/`projectRoot`/`projectId`/`sourceSkillId`/
 *      `designSystemId`/`mode` + `workspace`) + the 3 workspace affordances
 *      `useDesignSessionEffects` threads today and leaves the rest opaque. No
 *      host store object, no `htmlPreviewStore`/`WebContents`/`ipcRenderer`/
 *      `CHANNELS` value, no React handle, no per-frame callback.
 *   3. No DOM/Node leakage: published types use `string` / optional record /
 *      `HostReactNode` / `HostUnregister` only; no Electron or Node type, no
 *      `@elftia/shared` import, no renderer-source import. The module imports
 *      ONLY `./_shared`.
 *   4. No React/runtime dependency: type-only; the module imports only
 *      `./_shared`. `Effect` is typed with the structural `HostReactNode` return
 *      (no `react` runtime dep — the plugin produces the component via
 *      `host.react`).
 *   5. Smoke coverage: `renderer.smoke.ts` exercises
 *      `host.sessionEffects.registerSessionEffect({ kind:'design', Effect:
 *      ({ctx}) => { void ctx.sessionId; void ctx.workspace.setView; void
 *      ctx.workspace.setActiveArtifact; return null; } })` and invokes the
 *      returned unregister; the `_version` literal `'1.15.0'` → `'1.16.0'`.
 *
 * ── v1.15.0 (ADDITIVE / MINOR) ──
 * Per-session `agent:event` subscription port (`ds-design-session-decouple`) —
 * ONE addition to the RENDERER host API; the `1.14.0` surface is BYTE-UNCHANGED
 * (a plugin built against `1.0.0`–`1.14.0` still compiles):
 *   - NEW sibling module `host-api/agent-events.ts` publishing the per-session
 *     event-subscription port, exposed as ONE new member
 *     `AgentUiHostApi.agentEvents` (`AgentUiAgentEvents`):
 *     `subscribe(listener): HostUnregister` — subscribe to the host's
 *     per-session `agent:event` stream (the channel the preload exposes as
 *     `window.native.agent.onEvent` / `CHANNELS.agent.onEvent`). The host wires
 *     it to the existing `agent.onEvent` IPC subscription (`@/shared/agent`);
 *     the IPC channel, its preload bridge, the routers, and main-side agent-
 *     event emission are UNCHANGED. The `listener` receives a
 *     `HostAgentStreamEvent` structural lower bound pinning ONLY the fields the
 *     design `<artifact>` stream consumer reads (`type` required; `sessionId?`;
 *     `delta?` with optional `type`/`content`/`text` + opaque rest).
 * Closes the SINGLE host-internal edge the Design Studio plugin's DORMANT
 * streaming machinery (`ArtifactStreamConsumer`) could not reach from a
 * `plugin://` bundle (the htmlPreview WRITE side has been covered by
 * `host.stores.htmlPreview` since v1.1; persistence by the scoped
 * `host.ipc.invoke` bridge). PORT-ONLY: nothing consumes it yet — the host's
 * own design-session streaming path stays live and byte-unchanged; a later
 * slice flips the consumer.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new renderer member + one sibling module; no existing
 *      member or signature changes (the v1 8 + v1.1/v1.2/v1.4/v1.13 members and
 *      the entire `AgentBackendHostApi` + the v1.14 `deactivate` export are
 *      byte-unchanged). The new `agentEvents` member is NON-OPTIONAL — the host
 *      always provides the full object, and an old plugin simply does not
 *      consume it (the `agent`/`chatPanel`/`newChat` precedent), so existing
 *      plugins keep compiling.
 *   2. Narrow-port minimality: the port exposes ONLY `subscribe(listener):
 *      HostUnregister`; no `invoke`, no per-session filter argument (the
 *      consumer filters by `sessionId` client-side), no `WebContents` /
 *      `ipcRenderer` / `CHANNELS` value crosses. The event payload pins the 3
 *      parser-read fields (`type` / `delta.text` / `delta.content`) and leaves
 *      the rest opaque.
 *   3. No DOM/Node leakage: published types use `string` / an optional nested
 *      record / `HostUnregister` only; no Electron or Node type, no
 *      `@elftia/shared` agent-event type, no renderer-source import. The module
 *      imports ONLY `./_shared`.
 *   4. No React/runtime dependency: type-only; plugin-types adds no runtime
 *      dependency (the new module imports only `./_shared`).
 *   5. Smoke coverage: `renderer.smoke.ts` exercises
 *      `host.agentEvents.subscribe((e) => { void e.type; void e.sessionId;
 *      void e.delta?.text; })` and invokes the returned unregister.
 *
 * ── v1.14.0 (ADDITIVE / MINOR) ──
 * Hot-toggle `deactivate` plugin-export hook + activate-reentrancy contract
 * (`plugin-hot-toggle`) — ONE additive plugin-export type on EACH half; the
 * `1.13.0` host-API surface (`AgentUiHostApi` + `AgentBackendHostApi` and every
 * member) is BYTE-UNCHANGED (a plugin built against `1.0.0`–`1.13.0` still
 * compiles):
 *   - NEW optional renderer export type `AgentUiDeactivate = () => void |
 *     Promise<void>` (next to `AgentUiActivate` in `renderer.ts`) and its main
 *     twin `AgentBackendDeactivate = () => void | Promise<void>` (next to
 *     `AgentBackendActivate` in `backend.ts`); both re-exported from the barrel.
 *     The hook is the Obsidian `onunload` analogue: the loader calls a plugin
 *     module's `deactivate()` on disable — AFTER draining the host-owned
 *     disposers (renderer) / tearing down the host-side registrations (main) —
 *     inside try/catch. It takes NO arguments (the plugin already closed over
 *     its host in `activate`); a plugin without it is disabled unchanged (the
 *     loader guards `typeof mod.deactivate === 'function'`).
 * ACTIVATE-REENTRANCY CONTRACT (the doc the bump exists to publish):
 *   - Because the ESM/CJS module cache is permanent, RE-enabling a previously
 *     disabled plugin re-runs `activate(host)` on the SAME cached module rather
 *     than re-importing code. Therefore `activate(host)` MAY be called more than
 *     once in a single process.
 *   - A plugin MUST treat EACH `activate` call as a fresh start: it receives a
 *     FRESH host object each time (the prior host is poisoned on disable — its
 *     methods throw and its captured host-internal refs are nulled), so a plugin
 *     MUST re-read its host per use and never capture a host from a prior
 *     `activate` in a long-lived closure.
 *   - A plugin SHALL release its OWN side effects (timers, global listeners,
 *     observers) in `deactivate()` — the host's disposer accounting only revokes
 *     the registrations the host minted, never the plugin's bare side effects.
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: two new OPTIONAL plugin-export TYPES (one per half); no
 *      existing member or signature changes; the entire host-API surface is
 *      byte-unchanged.
 *   2. Narrow-port minimality: each export type is a zero-argument function
 *      type — the plugin already holds its host from `activate`; no host surface
 *      added, no required field.
 *   3. No DOM/Node leakage: both are lib-agnostic `() => void | Promise<void>`
 *      function types — `AgentUiDeactivate` stays in the renderer (DOM) module,
 *      `AgentBackendDeactivate` in the main (Node) module; neither imports the
 *      other module and neither pulls a cross-context type.
 *   4. No React/runtime dependency: type-only; plugin-types adds no runtime
 *      dependency.
 *   5. Smoke coverage: `renderer.smoke.ts` / `backend.smoke.ts` each export a
 *      `deactivate` typed as `AgentUiDeactivate` / `AgentBackendDeactivate`.
 *
 * ── v1.13.0 (ADDITIVE / MINOR) ──
 * New-chat modality contribution port (`new-chat-modality-port`) — ONE addition
 * to the RENDERER host API; the `1.12.0` surface is BYTE-UNCHANGED (a plugin
 * built against `1.0.0`–`1.12.0` still compiles):
 *   - NEW sibling module `host-api/new-chat.ts` publishing the new-chat modality
 *     registry port, exposed as ONE new member `AgentUiHostApi.newChat`
 *     (`AgentUiNewChat`): `registerModality(def): HostUnregister` — register a
 *     `NewChatModalityDefinitionLike` (pins `id` + `agentIds` + `submit`; the
 *     draft lifecycle hooks `createInitialDraft`/`resetDraft`/`applyPrefill` are
 *     OPTIONAL). Routes to `registerNewChatModality` (`newChatModalityStore`,
 *     last-registration-wins per agent id). The port owns the new-chat draft
 *     lifecycle + submit dispatch; rendering stays on the existing `host.hello`
 *     registry (the resolved modality's opaque `HostNewChatDraft` flows into the
 *     active hello entry's `ctx.draft`). Sibling context types
 *     `HostPickedAgentLike` / `HostNewChatDraftPatchContext` /
 *     `HostNewChatSubmitContext` are structural lower bounds.
 * Generalizes the host's previously-hardcoded "design modality" new-chat path
 * so EVERY plugin can contribute a new-chat entry; the Design Studio modality
 * migrates through the same port via a host-side bridge (behavior-preserving).
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: one new renderer member + one sibling module; no existing
 *      member or signature changes (the v1 8 + v1.1/v1.2/v1.4 members and the
 *      entire `AgentBackendHostApi` are byte-unchanged). The new `newChat`
 *      member is NON-OPTIONAL — the host always provides the full object, and
 *      an old plugin simply does not consume it (the `agent`/`components`/
 *      `chatPanel` precedent), so existing plugins keep compiling.
 *   2. Narrow-port minimality: the port exposes ONLY modality registration
 *      (draft lifecycle + submit dispatch); rendering is NOT duplicated (it
 *      stays on `host.hello`). `HostNewChatSubmitContext` exposes only the
 *      audited new-chat inputs the design modality consumed (message, provider/
 *      model, project path, playground flag, opaque draft, the two host
 *      `bindSessionToActiveTab` / `focusInput` actions); no host store object,
 *      session client, or React handle crosses.
 *   3. No DOM/Node leakage: published types use strings, booleans, promises,
 *      `HostUnregister`, and opaque `Record<string, unknown>` / `unknown`
 *      payloads only; no Electron/Node type and no renderer-source / `@elftia/
 *      shared` import appears.
 *   4. No React/runtime dependency: plugin-types remains type-only and adds no
 *      runtime dependency (the new module imports only `./_shared`).
 *   5. Smoke coverage: `renderer.smoke.ts` exercises
 *      `host.newChat.registerModality(...)` with a full def (id + agentIds +
 *      submit + the three optional draft hooks).
 *
 * ── v1.12.0 (ADDITIVE / MINOR) ──
 * DS ext-host native-operation ports (`plugin-proc-isolation-p1-ds-flip`) —
 * three new OPTIONAL `AgentBackendHostServices` members on the MAIN host API;
 * the `1.11.0` surface is BYTE-UNCHANGED (a plugin built against
 * `1.5.0`–`1.11.0` still compiles):
 *   - NEW sibling module `host-api/backend-native-ops.ts` publishing the
 *     process-safe native-operation contracts a main-half plugin uses instead
 *     of importing `electron` (required before utilityProcess ext-host
 *     execution, where Electron main APIs do not exist):
 *     `AgentBackendHostServices.platformPaths` (`HostPlatformPathsLike`:
 *     `userDataDir()` / `agentWorkspacesRootDir()` / `bundledResourcesDir()` —
 *     host-resolved absolute path strings; no generic `getPath(name)`
 *     passthrough), `AgentBackendHostServices.nativeDialog`
 *     (`HostNativeDialogLike`: wire-safe `showSaveDialog(options)` →
 *     `{ canceled, filePath? }`; no `dialog` object crosses), and
 *     `AgentBackendHostServices.pdfRenderer` (`HostPdfRendererLike`:
 *     `renderHtmlFileToPdf({ sourceFilePath, destPath, pageSize?,
 *     printBackground?, margins?, injectCss? })` — the HOST owns any
 *     `BrowserWindow`/`printToPDF` usage and writes the PDF file; no PDF
 *     bytes and no window handle cross the boundary).
 * Freeze checklist for this release (the 5 points):
 *   1. Additive-only: three optional service members and one sibling module
 *      are added; no existing member or signature changes.
 *   2. Narrow-port minimality: each port exposes only the audited DS
 *      consumption set (3 path getters / save-only dialog / one
 *      file-in-file-out PDF method); no Electron object, callback, or
 *      host-private `@main` class crosses.
 *   3. No DOM/Node leakage: published types use strings, numbers, booleans,
 *      and promises only; no Electron or Node type appears.
 *   4. No React/runtime dependency: plugin-types remains type-only and adds
 *      no runtime dependency.
 *   5. Smoke coverage: backend smoke fixtures exercise `platformPaths`,
 *      `nativeDialog.showSaveDialog`, and `pdfRenderer.renderHtmlFileToPdf`.
 *
 * ── v1.11.0 (ADDITIVE / MINOR) ──
 * Phase 1 session wire seams (`plugin-proc-isolation-p1-session-wire`) — one
 * addition to the MAIN host API; the `1.10.0` surface is BYTE-UNCHANGED (a
 * plugin built against `1.5.0`–`1.10.0` still compiles):
 *   - NEW sibling module `host-api/backend-session-runtime.ts` publishing the
 *     session runtime port, exposed as ONE new OPTIONAL service member
 *     `AgentBackendHostServices.sessionRuntime` (`HostSessionRuntimeLike`):
 *     `dispatchSpecSession(engineType, wireSpec, wireCtx)` — host-owned spec
 *     folding + engine dispatch over `WireResolvedAgentSpec` + `WireSessionCtx`
 *     (both from `@elftia/agent-spec`, the existing dependency direction, never
 *     the reverse); `emitStreamEvent(streamId, event)` — plugin stream emission
 *     through the host's `completion:stream:<streamId>` envelope + delivery
 *     buffer WITHOUT holding `WebContents`; `onStreamEnded(cb)` — host→plugin
 *     stream lifecycle notification (wire-safe `{ streamId, dbSessionId?,
 *     reason }`). `registerSessionHandler` / `HostSessionHandler` /
 *     `HostEngineDispatcherLike` are signature-UNCHANGED.
 * Freeze checklist for this release (the 5 points, verbatim from the change's
 * design D7):
 *   1. Additive-only: one optional service member and sibling session-runtime
 *      types are added; no existing member or signature changes.
 *   2. Narrow-port minimality: the new port exposes only session dispatch,
 *      stream emit, and stream-ended notification; no `WebContents`, engine
 *      object, full `ChatSession`, or process primitive crosses.
 *   3. No DOM/Node leakage: published types use strings, promises, agent-spec
 *      wire types, `WireValue`-safe payloads, and `HostUnregister`; no
 *      Electron or Node type appears.
 *   4. No React/runtime dependency: plugin-types remains type-only and adds no
 *      runtime dependency.
 *   5. Smoke coverage: backend smoke fixtures exercise `sessionRuntime`,
 *      `dispatchSpecSession`, `emitStreamEvent`, and `onStreamEnded`.
 *
 * ── v1.10.0 (ADDITIVE / MINOR) ──
 * Process-isolation Phase 0 seams (`plugin-proc-isolation-p0`) — two additions
 * to the MAIN host API; the `1.9.0` surface is BYTE-UNCHANGED (a plugin built
 * against `1.5.0`–`1.9.0` still compiles):
 *   - NEW sibling module `host-api/backend-transport.ts` publishing
 *     `BackendHostTransport` — the request/response + event-subscription
 *     transport contract whose payloads are structured-clone-safe `WireValue`s
 *     (defined in `@elftia/agent-spec`, imported/re-exported here — never the
 *     reverse: package cycle). The host implements it in-process with
 *     `LocalTransport` (zero behavior change); a Phase 1 process boundary is a
 *     transport substitution. MINIMALITY: 2 members (`request` / `subscribe`)
 *     — no live host object, no process primitive, no register verb.
 *   - One OPTIONAL member on the existing `HostEngineDispatcherLike` narrow
 *     port: `supportsSpecSessions?(type): Promise<boolean>` — the async engine
 *     capability query. MINIMALITY: a boolean answer only (no engine object
 *     crosses); the sync `getEngine` + `applyResolvedSpec` guard stays for
 *     in-process fallback (absent on an older host ⇒ the consumer guards).
 * No DOM type in backend contracts and no Node/Electron type in renderer
 * contracts (the new module uses only `string`/`Promise`/`WireValue`); no
 * React copy, no UI component, no runtime dependency. The 3 frozen
 * `AgentBackendHostApi` members + the entire renderer surface are
 * BYTE-UNCHANGED. Smoke: `backend.smoke.ts` exercises the transport types and
 * the optional capability query.
 *
 * ── v1.5.0 (ADDITIVE / MINOR) ──
 * Added the `services` member (`AgentBackendHostServices`) to
 * `AgentBackendHostApi` (`host-api/backend-services.ts`): the 8 runtime service
 * singletons the DS main `activate` composes its service layer from (`logger`,
 * `db`, `imageGeneration`, `videoGeneration`, `musicGeneration`,
 * `claudeSdkEngine`, `designSystemPluginSource`, `engineDispatcher` — EXACTLY the
 * `bootstrapContentDesignStudio` inputs + the design-session handler's
 * `engineDispatcher`, 窄端口). A service-HANDLE port (heavier than the renderer
 * per-operation ports — justified because the DS main half COMPOSES a layer);
 * each handle is an opaque structural lower bound (the `HostMcpProviderLike`
 * discipline — no `@main` import) and is the LIVE boot singleton (threaded
 * through `loadMainExtensions`), or `undefined` when omitted (the plugin guards).
 * Fulfills the v1 "additive later if a real consumer needs them" deferral. The 3
 * frozen `AgentBackendHostApi` members + the entire renderer surface are
 * BYTE-UNCHANGED; a plugin built against any earlier version still compiles.
 *
 * ── v1.4.0 (ADDITIVE / MINOR) ──
 * Added the `chatPanel` member (`AgentUiChatPanel`) to `AgentUiHostApi`
 * (`host-api/chatPanel.ts`): `registerDesignCommentsTab(render): HostUnregister`,
 * a first-party transitional register handle routing to the shipped host
 * `designCommentsTabStore` (single-slot IoC). The `render` callback receives a
 * `HostDesignCommentsTabContext` (`{ engineType, conversationId }`, verified
 * against the real store). ALL prior members byte-unchanged; a plugin built
 * against `1.3.0` (or any earlier 1.x) still compiles against `1.4.0`.
 *
 * ── v1.3.0 (ADDITIVE / MINOR) ──
 * Added the optional `errorMessage?: string` field to `HostHtmlPreviewSnapshot`
 * (`host-api/stores.ts`), mirroring the real `HtmlPreviewState.errorMessage`, and
 * `buildHtmlPreviewPort`'s `getSnapshot` projection now emits it (a
 * runtime-observable value, not merely index-signature-reachable). ALL prior
 * members byte-unchanged; a plugin built against `1.2.0` still compiles against
 * `1.3.0`.
 *
 * ── v1.2.0 (ADDITIVE / MINOR) ──
 * Added (all new OPTIONAL members; ALL prior members — the v1 8, the v1.1
 * `sessionGroup`/`stores`/`canvas`/`dataPacks` + 3 UI primitives, and the entire
 * `AgentBackendHostApi` — are BYTE-UNCHANGED, so a plugin built against `1.1.0`
 * (or `1.0.0`) still compiles against `1.2.0`). Closes the renderer-flip
 * host-module gap L0 undercounted:
 *   - `AgentUiHostApi.agent` (`AgentUiHostAgent`) — a NARROW port into the host
 *     agent IPC client (`@/shared/agent`): `chatSessions.{list,create,update}`,
 *     `files.read`, `resolveCodeCliBackend` (the audited DS call-set; NOT the 39
 *     `design:*` channels, NOT the whole agent API).
 *   - `AgentUiHostApi.components` (`AgentUiHostComponents`) — host-PROVIDED React
 *     feature bodies (`DevPreviewPanel` / `CodeEditor` / `MediaHoverCard`) the
 *     plugin embeds but cannot vendor without dragging heavy host deps into its
 *     chunk. Minimality justified by the chunk-size hazard (codemirror must stay
 *     OFF the plugin chunk — the Phase-3 leak lesson); distinct from `ui`
 *     (the small mandated primitives). TYPE references injected by the loader —
 *     no component bundled into this package.
 * New sibling modules `src/host-api/{agent,components}.ts` hold the new types;
 * `renderer.smoke.ts` exercises every new member. No DOM↔Node leak, no bundled
 * React/component, no runtime dependency.
 *
 * ── v1.1.0 (ADDITIVE / MINOR) ──
 * Added (all new OPTIONAL members; the original 8 `AgentUiHostApi` members + the
 * original 8 `AgentUiPrimitives` + the entire `AgentBackendHostApi` are
 * BYTE-UNCHANGED, so a plugin built against `1.0.0` still compiles against
 * `1.1.0`):
 *   - `AgentUiHostApi.sessionGroup` — register a sidebar session-group descriptor
 *     (`registerSessionGroup`, the Child-J registry shipped after the v1 freeze).
 *   - 3 UI primitives on `AgentUiPrimitives` — `Badge` / `Slider` / `Tooltip`
 *     (the SET grew 8 → 11; a SET addition is MINOR).
 *   - `AgentUiHostApi.stores` — narrow per-store ports (`htmlPreview` read+write,
 *     `devPreview` read-only, `workspaceToolbar` write, `newChatHandoff` write,
 *     `chat` read-only).
 *   - `AgentUiHostApi.canvas` + `.dataPacks` — typed forwards to the existing
 *     host static `canvas`/`dataPacks` IPC channels (F1; routers unchanged).
 * New sibling modules under `src/host-api/` (`_shared`, `sessionGroup`, `stores`,
 * `platform-ipc`) hold the new types; `renderer.smoke.ts` exercises every new
 * member. No DOM↔Node leak, no bundled React/component, no runtime dependency.
 *
 * ── v1.6.0 (ADDITIVE / MINOR) ──
 * Added one OPTIONAL audited member to an existing narrow port (the `1.5.0`
 * surface is BYTE-UNCHANGED, so a plugin built against `1.5.0` still compiles):
 *   - `HostNewChatHandoffPort.openNewChat` — open a fresh chat surface + queue the
 *     persona-select handoff in one host call. A plugin page (DS Examples "Use")
 *     cannot reach the host `useChatTabs` hooks to flip the active tab OFF its own
 *     agent-page, so a bare `requestPersonaSelect` never mounts `NewChatContent`;
 *     this performs the canonical `useOpenChatWithAgentAndPrompt` tab-flip for it.
 * No DOM↔Node leak, no bundled React/component, no runtime dependency (a `chatTabs`
 * + `newChatHandoff` store write, wired at the single `hostStores` cast boundary).
 *
 * ── v1.9.0 (ADDITIVE / MINOR) ──
 * Added two OPTIONAL members to the `AgentBackendHostServices` narrow port
 * (spec `plugin-storage` — fs-boundary storage path grants; the `1.8.0`
 * surface is BYTE-UNCHANGED, so a plugin built against `1.5.0`–`1.8.0` still
 * compiles):
 *   - `AgentBackendHostServices.storage` (`HostStorageLike`) — per-plugin
 *     storage PATH GRANTS, the VSCode `storageUri` pattern: `dataDir()` resolves
 *     + lazily creates `<userData>/plugin-data/<pluginId>/` (removed on plugin
 *     uninstall) and `projectDir(projectRoot)` resolves + lazily creates
 *     `<projectRoot>/.elftia/<pluginId>/` (project-colocated data that lives
 *     and dies with the user-owned folder). The plugin id is HOST-INJECTED at
 *     handle construction (never a caller parameter); the host validates the
 *     flat-id charset before any path build and rejects an empty/non-absolute
 *     projectRoot. Paths only — the in-process plugin does its own `node:fs`
 *     I/O. MINIMALITY: no file API (no boundary gain in-process), no KV
 *     (deferred — zero consumers), no SQL substrate (a plugin wanting sqlite
 *     opens it inside its own dataDir). TRUST HONESTY: the grants are data
 *     hygiene under install-time trust, NOT a security boundary.
 *   - `AgentBackendHostServices.projectEvents` (`HostProjectEventsLike`) —
 *     `onProjectDeleted(cb): HostUnregister`; payload `{ id, kind }`. The host
 *     emits when a host-owned project ROW is deleted. MINIMALITY: project-
 *     colocated data needs no event (it lives with the folder); the port exists
 *     for plugins keying `dataDir()`-side caches/indexes by project id — there
 *     is no other way to observe the deletion.
 * Both are OPTIONAL — absent on a host without the wiring (the optional-dep
 * pattern; the plugin `activate` guards). No `@main` import; no DOM↔Node leak;
 * no bundled React/component; no runtime dependency. The 3 frozen
 * `AgentBackendHostApi` members + the entire renderer surface are BYTE-UNCHANGED.
 *
 * ── v1.8.0 (ADDITIVE / MINOR) ──
 * Narrowed the A+B-audited `AgentBackendHostServices` handles from opaque
 * `{ [k: string]: unknown }` lower bounds into NARROW PUBLISHED INTERFACES
 * (`ds-standalone-contracts`, Decision 5) — a TYPE-only refinement, no member
 * added/removed and no runtime shape change:
 *   - `AgentBackendHostServices.logger` → `HostLoggerLike` (`error` + optional
 *     `warn`/`info`/`debug`).
 *   - `AgentBackendHostServices.db` → `HostDbRpcLike` (generic `send<T>(channel,
 *     ...params)` only — NO typed design data method leaks into the contract).
 *   - `AgentBackendHostServices.engineDispatcher` → `HostEngineDispatcherLike`
 *     (`getEngine(type): SpecCapableEngineHandle` from `@elftia/agent-spec` — the
 *     HONEST handle whose `applyResolvedSpec?` is OPTIONAL, mirroring
 *     `IEngine.applyResolvedSpec?`; the consumer guards then narrows it to
 *     `SpecApplicableEngine`. Plus `dispatch(type, ctx)`).
 *   - `AgentBackendHostServices.designSystemPluginSource` →
 *     `HostDesignSystemSourceLike` (`listSystems(): unknown` + the cache-miss body
 *     fallback `getDetail(id): Promise<unknown>` / `getBody(id): Promise<string |
 *     null>` — design-domain result shapes are re-narrowed by the consumer, never
 *     leaked into this generic plugin contract).
 * The narrow interfaces are SUPERTYPES of what Design Studio read off the old
 * opaque handle (via cast), so a plugin built against `1.5.0`–`1.7.0` still
 * compiles. Lets DS code against published `@elftia/plugin-types` contracts
 * instead of casting `host.services.*` to host-private `@main` service classes
 * (the B-bucket `@main`-decoupling). The remaining composed handles
 * (image/video/music generation, `claudeSdkEngine`, `dataPackResolver`) stay
 * opaque. The 3 frozen `AgentBackendHostApi` members + the entire renderer
 * surface are BYTE-UNCHANGED.
 *
 * ── v1.7.0 (ADDITIVE / MINOR) ──
 * Added one OPTIONAL audited member to the `AgentBackendHostServices` narrow port
 * (the `1.6.0` surface is BYTE-UNCHANGED):
 *   - `AgentBackendHostServices.dataPackResolver` — the host's data-pack
 *     content-root precedence resolver. A plugin PROVIDES its bundled root + pack
 *     id; the host (the owner of the data-pack install/precedence mechanism)
 *     resolves which root is in effect. Lets a plugin (Design Studio) stop
 *     importing the host's `pluginDirs` platform internals directly — the
 *     provider/consumer boundary fix. Absent on an older host ⇒ the plugin
 *     degrades to its bundled root (the optional-dep pattern).
 *
 * Distinct from the Elftia app version — see the policy block above. The future
 * loader compares a plugin's required host-API MAJOR against the MAJOR of this
 * literal to decide whether to `activate()`.
 *
 * @stability frozen — bumping this is governed by the freeze checklist.
 */
/**
 * ---------------------------------------------------------------------------
 * v1.47 IS LIVE ON THE IN-PROCESS MAIN HALF ONLY — read before relying on it
 * ---------------------------------------------------------------------------
 * `host.capabilities` (composition Phase 1) is constructed at boot: the app
 * builds ONE `ExtensionCapabilityBroker`, registers every in-process plugin's
 * manifest `capabilities` declaration before any plugin activates, and orders
 * activation Providers-before-Consumers. So for an IN-PROCESS main-half plugin
 * the member is defined and `provide`/`require`/`explain` really work.
 *
 * It is `undefined` — and a guarded call is a no-op — on the two paths that
 * still have no transport, both by omission rather than by policy:
 *   - the RENDERER half. `AgentUiHostApi.capabilities` is declared (D3: ONE
 *     interface on both halves) but the renderer host API builds no handle;
 *     there is no IPC bridge for it yet.
 *   - an EXT-HOST (out-of-process) plugin. The ext-host endpoint's method
 *     table has no Capability verbs, so the loader deliberately does not hand
 *     that branch a Broker rather than hand it a handle whose calls could not
 *     cross. Such a plugin is also NOT registered with the Broker at all, so a
 *     Capability it declares satisfies nobody's requirement.
 *
 * A plugin author checking `HOST_API_VERSION >= 1.47` must therefore still
 * guard `host.capabilities?.…` and treat absence as "this half cannot
 * compose", not as an error. Narrow this note as each path lands.
 *
 * The SAME honesty applies to the v1.48 artifact members, on BOTH halves: the
 * v1.48 freeze is CONTRACT-ONLY (`composition-artifact-contract-freeze`) — no
 * host path constructs `host.artifacts` or `services.artifactStorage` yet, so
 * both are `undefined` everywhere and a guarded call is a no-op until the
 * artifact runtimes land in their slices.
 *
 * v1.49 / v1.50 are BACKEND-side additions (out-of-band engine transport +
 * web-pane L1 external-tool host surface) — the renderer surface is unchanged.
 * v1.51 (S08 tool-hosts) adds the optional backend `toolHosts` registration port; v1.52 (`desktop-pet-window-runtime` D7) adds the renderer `host.petRuntime`
 * desktop-pet runtime port, MEANINGFULLY BACKED ONLY in the pet window's scoped
 * harness; a main-window plugin invoking it gets a no-op / logged degradation

 * (never a crash) until the pet harness lands. v1.53 (S08 notifications) adds
 * the optional backend `notifications` port — the plugin notification port
 * whose DATA-ONLY `openPath` click action is executed by the host.
 * v1.54
 * (`desktop-pet-manager-page` D2) promotes the MAIN-WINDOW construction of
 * that same member to a real management backing — `getConfig` resolves the
 * optional settings-surface fields and the optional `setConfig` verb routes to
 * the main-window-only `pet:setConfig` IPC — a promotion of the degraded
 * member, NOT a new member; the pet window's construction stays exactly v1.52.
 * v1.55 (`third-party-tool-pack-channel`) is BACKEND-side: the optional
 * `host.toolkits` skill-toolkit registration port. It is MAIN-ONLY BY
 * CONSTRUCTION, not merely unwired — the host's per-invocation toolkit
 * context carries live `logger` / media-bridge handles that are not
 * wire-safe, so the ext-host branch leaves the member `undefined` and an
 * out-of-process plugin contributes MCP servers instead. The renderer
 * surface is unchanged. v1.56 (`agent-visual-state-runtime`) adds the
 * optional pet-window character-presentation subscription; the main-window
 * management construction continues to omit that pet-window-only capability.
 * The independently developed `local-channel-transport-host` contract shares
 * v1.56 and adds the renderer Local Channel convenience API plus the
 * permission-gated flat MAIN service broker. v1.57
 * (`quick-chat-surface-host`) adds the optional backend
 * Quick Chat request port, the optional renderer Quick Chat registry, and the
 * distinct reduced Pet Host/capability consumer projection.

 */
export const HOST_API_VERSION = '1.58.0' as const;

/** The literal type of {@link HOST_API_VERSION}. */
export type HostApiVersion = typeof HOST_API_VERSION;

/**
 * Compatibility descriptor a plugin declares (or the loader computes) to gate
 * `activate()`. The loader (Child H) is the consumer; this contract only
 * defines the shape.
 *
 * @stability frozen
 */
export interface HostApiCompat {
  /**
   * The host-API version the plugin was BUILT against (the `HOST_API_VERSION`
   * present in the `@elftia/plugin-types` it compiled with). Informational —
   * used for diagnostics / "built for newer Elftia" messaging.
   */
  builtAgainst: string;
  /**
   * The MINIMUM host-API MAJOR the plugin requires to run. The loader refuses
   * to activate when `requiredMajor > running HOST_API_VERSION major`,
   * degrading with an "update Elftia" message rather than crashing.
   */
  requiredMajor: number;
  /**
   * Optional minimum MINOR within {@link requiredMajor}. When set, the loader
   * may additionally warn (not refuse) if the running MINOR is lower — an
   * additive member the plugin expects may be absent. Omitted → no minor gate.
   */
  requiredMinor?: number;
}
