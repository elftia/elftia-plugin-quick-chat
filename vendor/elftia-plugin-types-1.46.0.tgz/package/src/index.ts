/**
 * @elftia/plugin-types — the frozen v1 host-API contract for Tier-1 plugins.
 *
 * Source-only internal package (mirrors the omnicross internal-package pattern):
 * `private: true`, no `license`, `main`/`types: src/index.ts`, no build/dist, no
 * runtime `dependencies`. React is referenced only as a TYPE
 * (`typeof import('react')`), resolved from the consuming app at type-check time.
 *
 * This barrel re-exports:
 *   - `./version`  — `HOST_API_VERSION`, `HostApiCompat`, versioning policy +
 *                    the authoritative FREEZE CHECKLIST (in that file's JSDoc).
 *   - `./renderer` — `AgentUiHostApi` family (the renderer host surface).
 *   - `./backend`  — `AgentBackendHostApi` family (the main host surface).
 *
 * ── FREEZE DISCIPLINE (read before touching any host-API type) ──
 * Every future change to this package's surface MUST satisfy the 5-item freeze
 * checklist documented in `./version` (additive-or-MAJOR, 窄端口 justification,
 * no DOM↔Node cross-contamination, no bundled React/components, smoke updated).
 * The renderer module (`renderer.ts`) and the main module (`backend.ts`) are
 * INDEPENDENT (Decision D2): they never import each other; only `./version`
 * (lib-agnostic) is shared.
 *
 * @module @elftia/plugin-types
 */

// ── Version + compatibility policy + freeze checklist ────────────────────────
export type { HostApiCompat, HostApiVersion } from './version';
export { HOST_API_VERSION } from './version';

// ── Renderer host API (AgentUiHostApi family) ────────────────────────────────
// The additive sibling types (v1.1 `AgentUiCanvas`/`AgentUiDataPacks`/
// `AgentUiHostStores`/`SessionGroupDefinitionLike` + the 3 prop shapes; v1.2
// `AgentUiHostAgent`/`AgentUiHostComponents`; v1.4 `AgentUiChatPanel`/
// `HostDesignCommentsTabContext`) are re-exported from `./renderer`, so they are
// reachable here through the same module.
export type {
  AgentHelloDefinitionLike,
  AgentPageDefinitionLike,
  AgentUiActivate,
  AgentUiAgentEvents,
  AgentUiCanvas,
  AgentUiChatPanel,
  AgentUiDataPacks,
  // ADDITIVE v1.14 — the OPTIONAL renderer `deactivate` plugin-export type.
  AgentUiDeactivate,
  AgentUiHostAgent,
  AgentUiHostApi,
  AgentUiHostComponents,
  AgentUiHostStores,
  AgentUiI18n,
  // ADDITIVE v1.36 — the membership Colorful-purchase registration port.
  AgentUiMembership,
  AgentUiNewChat,
  AgentUiPetHostApi,
  // ADDITIVE v1.52 — the desktop-pet runtime port.
  AgentUiPetRuntime,
  AgentUiPrimitives,
  // ADDITIVE v1.41 — the project-planning contribution point + Project port.
  AgentUiProjectPlanning,
  AgentUiReactHandle,
  AgentUiRegistrationHandles,
  AgentUiScopedIpc,
  // ADDITIVE v1.16 — the page-level session-effect registration port.
  AgentUiSessionEffects,
  // ADDITIVE v1.18 — the per-sessionType behavior registration port.
  AgentUiSessionKinds,
  // ADDITIVE v1.20 — the settings-section registration port.
  AgentUiSettings,
  AgentUiTheme,
  // ADDITIVE v1.36 — the membership Colorful-purchase copy + registration shapes.
  ColorfulPurchaseCopy,
  ColorfulPurchaseRegistration,
  HostActiveArtifactPayload,
  HostAgentStreamEvent,
  HostBadgeProps,
  HostButtonProps,
  HostCharacterLayerStyleLike,
  HostCharacterPresentationSnapshotLike,
  HostCharacterPresentationSubjectLike,
  HostCharacterPresentationVariantLike,
  HostCharacterResolvedLayerLike,
  HostCharacterResolvedPresentationLike,
  HostCharacterVisualIdentityLike,
  HostComponentType,
  HostConfirmDialogProps,
  HostDesignCommentsTabContext,
  HostDialogContentProps,
  HostDialogProps,
  HostDropdownMenuProps,
  HostInputProps,
  HostLocalChannelClient,
  HostLocalChannelEvent,
  HostLocalChannelMessage,
  HostLocalChannels,
  HostLocalChannelSendResult,
  HostLocalChannelSnapshot,
  HostLocalChannelStatus,
  HostLocalChannelStreamEvent,
  HostNewChatDraft,
  HostNewChatDraftPatchContext,
  HostNewChatSubmitContext,
  // ADDITIVE v1.52 — the pet facts snapshot / runtime-config structural bounds.
  // ADDITIVE v1.53 — the settings-surface config patch (`desktop-pet-manager-page`).
  HostPetConfigPatch,
  HostPetFactEntryLike,
  HostPetFactsSnapshotLike,
  HostPetRuntimeConfig,
  HostPickedAgentLike,
  // ADDITIVE v1.41 — the planning diagnostic + status structural mirrors.
  HostPlanningDiagnosticLike,
  HostProjectPlanningStatusLike,
  HostReactNode,
  HostSelectOption,
  HostSelectProps,
  HostSessionEffectContext,
  HostSessionEffectWorkspace,
  // ADDITIVE v1.20 — the opaque settings-section render context.
  HostSettingsSectionContext,
  HostSliderProps,
  HostSwitchProps,
  HostThemeSnapshot,
  HostTooltipProps,
  HostUnregister,
  // ADDITIVE v1.18 — workspace preview-toggle metadata.
  HostWorkspacePreviewToggle,
  NewChatModalityDefinitionLike,
  // ADDITIVE v1.41 — the planning panel context + section definition bound.
  ProjectPlanningPanelContext,
  ProjectPlanningSectionDefinitionLike,
  QuickChatWindowActivationContext,
  QuickChatWindowActivationResult,
  QuickChatWindowDisposer,
  QuickChatWindowHost,
  QuickChatWindowLocalChannel,
  QuickChatWindowLocalChannelClient,
  QuickChatWindowModule,
  SessionEffectDefinitionLike,
  SessionGroupDefinitionLike,
  // ADDITIVE v1.18 — the session-kind behavior record.
  SessionKindBehaviorLike,
  // ADDITIVE v1.20 — the settings-section definition lower bound.
  SettingsSectionDefinitionLike,
  WorkspaceDefinitionLike,
} from './renderer';

// ── Renderer host API — additive v1.1 sibling-module port/payload types ──────
export type {
  HostCanvasMutationResult,
  HostCanvasSoftCapPayload,
  HostDataPackIdPayload,
  HostDataPackProgressEvent,
} from './host-api/platform-ipc';
export type { SessionGroupSessionRef } from './host-api/sessionGroup';
// ADDITIVE v1.19 — the lib-agnostic chat-session settings lower bound shared
// by `HostChatSessionLike` (main) and `HostChatSessionRef` (renderer).
export type { HostChatSessionSettingsLike } from './host-api/_shared';
export type {
  HostChatSessionRef,
  HostChatStorePort,
  HostDevPreviewPort,
  HostDevPreviewSnapshot,
  HostHtmlPreviewBeginInput,
  HostHtmlPreviewOpenOptions,
  HostHtmlPreviewPort,
  HostHtmlPreviewSetActiveArtifactInput,
  HostHtmlPreviewSnapshot,
  HostNewChatHandoffPort,
  HostPendingPersonaSelect,
  HostWorkspaceToolbarConfig,
  HostWorkspaceToolbarItem,
  HostWorkspaceToolbarPort,
} from './host-api/stores';

// ── Renderer host API — additive v1.2 sibling-module payload/prop types ──────
export type {
  HostAgentChatSessionRef,
  HostChatSessionListQuery,
  HostChatSessionPage,
  HostCodeCliBackend,
  HostCreateChatSessionInput,
  HostProjectFileRead,
  HostUpdateChatSessionInput,
} from './host-api/agent';
export type {
  HostCodeEditorFile,
  HostCodeEditorProps,
  HostDevPreviewPanelProps,
  HostMediaHoverCardAction,
  HostMediaHoverCardProps,
} from './host-api/components';

// ── Main host API (AgentBackendHostApi family) ───────────────────────────────
// `AgentBackendHostServices` (v1.5) is re-exported from `./backend`, reachable
// here through the same module.
export type {
  AgentBackendActivate,
  // ADDITIVE v1.14 — the OPTIONAL main `deactivate` plugin-export type.
  AgentBackendDeactivate,
  AgentBackendHostApi,
  AgentBackendHostServices,
  HostBackendUnregister,
  HostIpcMethodHandler,
  HostIpcMethodMap,
  HostMcpProviderFactory,
  HostMcpProviderLike,
} from './backend';
export type {
  HostLocalChannelAttachResult,
  HostLocalChannelEventEnvelope,
  HostLocalChannelOperationResult,
  HostLocalChannelsBackend,
} from './host-api/local-channels';

// ── Main host API — service-handle types (v1.5 opaque + v1.8 narrow A+B) ─────
// The A+B-audited handles are now narrow published interfaces (`HostLoggerLike`
// / `HostDbRpcLike` / `HostEngineDispatcherLike` / `HostDesignSystemSourceLike`,
// v1.8 `ds-standalone-contracts`); the rest stay opaque structural lower bounds.
export type {
  HostClaudeSdkEngineLike,
  HostDataPackResolverLike,
  HostDbRpcLike,
  HostDesignSystemSourceLike,
  HostEngineDispatcherLike,
  HostImageGenerationServiceLike,
  HostLoggerLike,
  HostMusicGenerationServiceLike,
  // v1.9 — plugin-storage: the storage path-grant service + project event port.
  HostProjectDeletedEvent,
  HostProjectEventsLike,
  HostProjectKind,
  HostStorageLike,
  HostVideoGenerationServiceLike,
} from './host-api/backend-services';

// ── Quick Chat surface/window ports (lib-agnostic, Electron-free) ───────────
export type {
  HostQuickChatOperation,
  HostQuickChatPlacementIntent,
  HostQuickChatSurfaceLike,
  HostQuickChatSurfaceRequest,
  HostQuickChatSurfaceResult,
  QuickChatWindowCloseIntent,
} from './host-api/quick-chat';

// ── Main host API — BYO LLM-config + write-only secrets ports (v1.21) ────────
// `byo-port-llm-config` — the first BYO host capability ports. Provider/key
// returns are renderer-MASKED; secretsWrite is write-only + namespace-guarded.
export type {
  HostKeyHealthMap,
  HostLlmConfigLike,
  // v1.50 — the explicit `revealProviderKey` result (the one outward exception).
  HostLlmKeyRevealResult,
  HostLlmOpResult,
  HostLlmProviderResult,
  HostMaskedLlmProvider,
  HostMaskedPoolKeyEntry,
  HostModelDiscoverOptions,
  // v1.27 (`byo-p2-llm-2`) — the `testModel` connectivity-diagnostic result.
  HostModelTestResult,
  HostPoolKeyMutationResult,
} from './host-api/llm-config';
export type { HostSecretsWriteLike } from './host-api/secrets-write';

// ── Main host API — BYO subscription/OAuth/CLI-account port (v1.22 + v1.26) ──
// `byo-port-subscription-auth` — the `host.services.subscriptionAuth` port. The
// PKCE verifier stays host-side (NOT in `HostOAuthInitParams`); NO return type
// carries a token / refresh-token / id-token / setup-token / api-key. v1.26
// (`byo-p2-subscription` D4) adds the manual-token write verbs (INWARD-only).
export type {
  HostAccountTokensSanitized,
  HostClaudeSubscriptionLevel,
  HostCliImportResult,
  HostOAuthExchangeRequest,
  HostOAuthInitParams,
  HostSubscriptionAccountSanitized,
  HostSubscriptionAuthLike,
  HostSubscriptionEntry,
  HostSubscriptionOpResult,
  HostSubscriptionRefreshResult,
} from './host-api/subscription-auth';

// ── Main host API — BYO agent-config + cli-runtime ports (v1.26) ─────────────
// `byo-host-agent-config-port` — the `host.services.agentConfig` port (cli
// sub-settings get/set; the general `agentBackend` engine field is NOT exposed).
// `byo-host-cli-runtime-port` — the `host.services.cliRuntime` port (Code CLI
// availability/install/launch; NO method returns a credential).
export type {
  HostAgentConfigLike,
  HostCliBackendConfig,
  HostCliBackendId,
} from './host-api/agent-config';
export type {
  HostCliAuthStatus,
  HostCliAuthStatusOptions,
  HostCliBackendInfo,
  HostCliLaunchTerminalInput,
  HostCliRuntimeLike,
  HostCliRuntimeResult,
} from './host-api/cli-runtime';

// ── Main host API — BYO secrets-pack port (v1.27) ────────────────────────────
// `byo-host-secrets-pack-port` — the `host.services.secretsPack` port (encrypted
// credential migration pack). PASSPHRASE-IN, COUNTS/PATH/STATUS-OUT: NO return
// type carries a plaintext secret, the encrypted blob, or the passphrase. Gated
// by `host:secrets-pack` (distinct from `host:secrets-write`).
export type {
  HostSecretsPackArgs,
  HostSecretsPackExportResult,
  HostSecretsPackImportCounts,
  HostSecretsPackImportResult,
  HostSecretsPackLike,
} from './host-api/secrets-pack';

// ── Main host API — BYO media-provider config port (v1.23) ───────────────────
// `byo-port-media-config` — the `host.services.mediaConfig` port (flat
// `mediaType`-discriminated, all 5 media types). MASK-ON-RETURN: the returned
// provider `config.apiKey` is structurally `?: never` (no return carries a key).
export type {
  HostMaskedMediaProvider,
  HostMaskedMediaProviderConfig,
  HostMediaConfigLike,
  HostMediaCustomProviderInput,
  HostMediaGlobalSettings,
  HostMediaGlobalSettingsResult,
  // v1.50 — the explicit `revealProviderKey`/`revealProviderSecret` result.
  HostMediaKeyRevealResult,
  HostMediaKeyWriteResult,
  HostMediaModelRefreshResult,
  HostMediaOpResult,
  HostMediaProviderResult,
  HostMediaProviderSecretField,
  HostMediaProviderUpdate,
  HostMediaType,
} from './host-api/media-config';
export type {
  HostObjectStorageConfigLike,
  HostObjectStorageCredentialsInput,
  HostObjectStorageMutationResult,
  HostObjectStorageProvider,
  HostObjectStorageProviderConfig,
  HostObjectStorageProviderPatch,
} from './host-api/object-storage-config';

// ── Main host API — BYO web-search-provider config port (v1.24) ──────────────
// `byo-port-search-config` — the `host.services.searchConfig` port (API-key
// search providers; the FINAL P1 knife). NO-SEARCH-KEY-ON-RETURN: the returned
// config `apiKey` is structurally `?: never`; `setProviderKey` returns status
// only. Routes the key write through the EXISTING guarded secrets path.
export type {
  HostMaskedSearchProviderConfig,
  HostSearchConfigLike,
  HostSearchKeyWriteResult,
  HostSearchProviderConfigInput,
  HostSearchProviderId,
  HostSearchProvidersList,
  HostSearchValidateResult,
} from './host-api/search-config';

// ── Main host API — generic host-guarded authed-fetch port (v1.29) ───────────
// `oss-channel-isolation` P3-3a — the `host.services.relayApi` port. The host
// injects the bearer + base URL and enforces a path allowlist (`/api/v1/points/`);
// TOKEN-NEVER-CROSSES (the plugin can neither read nor override `Authorization`).
export type {
  HostRelayApiLike,
  HostRelayFetchInit,
  HostRelayFetchResult,
} from './host-api/relay-api';

// ── Main host API — plugin-install path roots + narrow installer port (v1.30) ─
// `oss-channel-isolation` P3-3b-2a — the `host.services.pluginPaths` (sync
// plugin-install/userData path getters; DISTINCT from the v1.12 `platformPaths`
// DS port) + `host.services.pluginInstaller` ports (the narrow two-verb install
// port over the host's single guardrail-bearing `PluginInstaller`). The seam the
// channel-gated Steam plugin's Workshop slice consumes (P3-3b-2a-2).
export type { HostPluginInstallerLike, HostPluginInstallResult } from './host-api/plugin-installer';
export type { HostPluginPathsLike } from './host-api/plugin-paths';

// ── Main host API — narrow write-only session-sink port (v1.31 + v1.32) ──────
// `oss-channel-isolation` P3-3b-2b-i/ii — the `host.services.authSession` port. The
// channel-gated Steam plugin PUSHES locally-read Colorful DLC ownership (v1.31) +
// drives a Steam ticket-exchange login (v1.32 `applySteamSession`, host runs the
// exchange + persist) to the host; WRITE-ONLY (no token/user/session read crosses).
export type { HostAuthSessionLike, SteamSessionApplyResult } from './host-api/auth-session';

// ── Main host API — narrow in-app-content enumerate + package port (v1.34) ───
// `workshop-publish-in-app-content` — the `host.services.inAppContent` port. The
// channel-gated Steam plugin enumerates the user's publishable in-app THEMES +
// AGENTS and asks the host to materialize a chosen item into a Workshop content
// dir (manifest + content), then uploads it via the SAME `publishPlugin` path
// used for installed plugins. HARD ALLOWLIST: `'theme' | 'agent'` only (never
// `prompt-template`); the host owns the secret-free export + packaging.
export type {
  HostInAppContentItem,
  HostInAppContentKind,
  HostInAppContentLike,
  HostInAppContentPackageResult,
} from './host-api/in-app-content';

// ── Main host API — narrow write-only backup-policy sink port (v1.37) ────────
// `db-relocate-steam-backup` — the `host.services.backupPolicy` port. The
// channel-gated Steam plugin PUSHES a backup policy (fixed `<profileDir>/backups`
// target, db-only snapshot mode, retention 2, auto-on-exit defaults) so the host
// resolves the Steam backup behavior from the registered policy instead of
// branching on the build channel; WRITE-ONLY (no resolved target/settings read).
export type { BackupPolicyRegistration, HostBackupPolicyLike } from './host-api/backup-policy';

// ── Main host API — the DEEP workflow-provider port (v1.39) ──────────────────
// `rasen-single-plugin` Milestone 1 — the `host.workflow` registration namespace
// + the whole provider contract. A plugin publishes a workflow's ENTIRE tool
// surface as one wire-safe `HostWorkflowDescriptor` (names / descriptions /
// input schemas / `access` classification / toolsets / legacy aliases) and
// serves every call through a single versioned `execute(request)` entry point,
// so the host derives its tool-name set, toolset membership, safe-tool allowlist
// and alias map from the descriptor instead of hand-keeping them.
export type {
  HostWorkflowCallContext,
  HostWorkflowCapabilities,
  HostWorkflowCronRequest,
  HostWorkflowDescriptor,
  HostWorkflowDiagnostic,
  HostWorkflowError,
  HostWorkflowErrorCode,
  HostWorkflowLegacyRequest,
  HostWorkflowProjectPlanningRequest,
  HostWorkflowProvider,
  HostWorkflowRegistration,
  HostWorkflowRequest,
  HostWorkflowResponse,
  HostWorkflowShutdownReason,
  HostWorkflowToolAccess,
  HostWorkflowToolDescriptor,
  HostWorkflowToolRequest,
  HostWorkflowToolsetDescriptor,
} from './host-api/workflow';

// ── Main host API — the workflow sibling seams (v1.40) ───────────────────────
// `rasen-single-plugin` Milestone 2 — the two OPTIONAL capability handles on
// `host.workflow`. The stage runtime is a three-verb dispatch port addressed by
// an OPAQUE execution id (no callback, no live worker handle crosses it); the
// browser toolkit is a CURATED 13-verb port whose unavailability is
// reason-discriminated so a caller never fabricates a page result.
export type {
  HostBrowserAction,
  HostBrowserInvokeContext,
  HostBrowserInvokeResult,
  HostBrowserToolkitLike,
  HostBrowserUnavailableReason,
} from './host-api/workflow-browser';
export type {
  HostStageBackend,
  HostStageOutcome,
  HostStageRole,
  HostStageStartInput,
  HostStageStartResult,
  HostWorkflowStageRuntimeLike,
} from './host-api/workflow-stage-runtime';

// ── Main host API — creative-library port (v1.42) ────────────────────────────
// `unified-creative-library-phase2` — the `host.services.creativeLibrary` port.
// READ-ONLY: EXACTLY two verbs `list(scope?)` + `get(id)`. Lets any MAIN plugin
// enumerate + fetch shared prompt-template content (image-prompt + video-prompt)
// from the HOST's bundled roots. No write verb; no host path/service crosses.
export type {
  CreativeLibraryItem,
  CreativeLibraryScope,
  HostCreativeLibraryLike,
} from './host-api/creative-library';

// ── Main host API — managed-runtime port (v1.43) ─────────────────────────────
// `creative-library-managed-consumption` — the `host.services.managedRuntime`
// port. READ-ONLY: EXACTLY one verb `resolvePreparedDir(id)` returning an
// absolute path string or null. Lets any MAIN plugin discover the host-managed
// runtime dir the seeder has prepped. No write verb; no host path/service
// crosses (only the resolved path string or null).
export type { HostManagedRuntimeLike } from './host-api/managed-runtime';

// ── Main host API — native-operation ports (v1.12, plugin-proc-isolation-p1-ds-flip)
// Process-safe platform paths / native save dialog / host PDF rendering — the
// services a main-half plugin uses instead of importing `electron`.
export type {
  HostNativeDialogLike,
  HostOpenDialogOptions,
  HostOpenDialogResult,
  HostPdfMargins,
  HostPdfPageSizeInches,
  HostPdfRendererLike,
  HostPdfRenderRequest,
  HostPdfRenderResult,
  HostPlatformPathsLike,
  HostSaveDialogFilter,
  HostSaveDialogOptions,
  HostSaveDialogResult,
} from './host-api/backend-native-ops';

// ── Main host API — backend transport contract (v1.10, plugin-proc-isolation-p0)
// `WireValue` is DEFINED in `@elftia/agent-spec` and re-exported through the
// transport module (never the reverse — package cycle).
export type { BackendHostTransport, WireValue } from './host-api/backend-transport';

// ── Both halves — UNIFIED host.agents.define port (v1.44) ─────────────────────
// `host-agents-define-infra` — the single `host.agents.define(def)` entry point
// on BOTH `AgentUiHostApi` (renderer) and `AgentBackendHostApi` (backend). The
// renderer half dispatches behavior/effect/workspace/modality/group to renderer
// stores; the backend half dispatches setup→AgentSessionSetupRegistry. Both are
// OPTIONAL members (the plugin guards `host.agents?.define(...)`). The sibling
// module imports ONLY `./_shared` (lib-agnostic; both halves reference it).
export type {
  HostAgentBackendDefinition,
  HostAgentsBackend,
  HostAgentSessionSetupFn,
  HostAgentSetupInput,
  HostAgentSetupResult,
  HostAgentSetupSession,
  HostAgentSetupSpecComponents,
  HostAgentsUi,
  HostAgentUiDefinition,
} from './host-api/agents';

// ── Both halves — host.capabilities composition port (v1.47) ─────────────────
// `elftia-composition-platform` Phase 1 — the cross-plugin Capability Broker
// handle on BOTH `AgentUiHostApi` and `AgentBackendHostApi`. Per design D3 this
// is the ONE namespace that does NOT split per half: nothing in it is React-,
// DOM- or Node-specific, and `HostCapabilityTarget` carries the process
// distinction as data. (`host.artifacts`, landing in Phase 2, DOES split.)
// Frozen surface per D21 = provide / require / explain; `observe()` +
// `CapabilitySlot` are deferred until a real optional consumer exists.
// OPTIONAL member on both halves — the plugin guards `host.capabilities?.…`.
export type {
  HostAbortSignalLike,
  HostCapabilities,
  HostCapabilityAcquireScope,
  HostCapabilityAvailability,
  HostCapabilityEndpoint,
  HostCapabilityGrant,
  HostCapabilityLease,
  HostCapabilityOperationDescriptor,
  HostCapabilityProvided,
  HostCapabilityRequirement,
  HostCapabilityTarget,
  HostInjectedCapabilityContext,
  HostPetCapabilityConsumer,
  HostPetCapabilityLease,
  HostPetCapabilityRequirement,
  HostWireValue,
} from './host-api/capabilities';

// ── Split halves — host.artifacts artifact contract (v1.48) ───────────────────
// `elftia-composition-platform` Phase 2 — the Artifact layer. UNLIKE
// `host.capabilities` above, this namespace SPLITS per half (design §37 D3):
// `HostArtifactsMain` is the Main-half data plane
// (`AgentBackendHostApi.artifacts?`), `HostArtifactsRenderer` carries the
// React-shaped members (`AgentUiHostApi.artifacts?`), and `open` sits on BOTH
// halves with one pure-data signature (Gate-0 C2). Both members are OPTIONAL —
// the freeze is contract-only; the plugin guards `host.artifacts?.…`. The data
// vocabulary is a STRUCTURAL RESTATEMENT of `@elftia/shared`
// `contracts/artifact-composition.ts` (this package imports no shared type).
export type { HostArtifactStorageLike } from './host-api/artifact-storage';
export type {
  HostArtifactBadge,
  HostArtifactContext,
  HostArtifactEnvelope,
  HostArtifactErrorCode,
  HostArtifactKindDefinition,
  HostArtifactKindProvider,
  HostArtifactOpenOptions,
  HostArtifactOpenResult,
  HostArtifactRef,
  HostArtifactScope,
  HostArtifactsMain,
  HostArtifactsRenderer,
  HostArtifactState,
  HostArtifactSummary,
  HostArtifactSurfaceContext,
  HostArtifactSurfaceDefinition,
  HostArtifactSurfacePlacement,
  HostArtifactSurfaceProps,
  HostArtifactSurfaceRole,
  HostArtifactSurfaces,
  HostOpaqueArtifactLocator,
  HostSurfaceInteractionMode,
} from './host-api/artifacts';

// ── Main host API — tool-host registration port (v1.51) ──────────────────────
// Slice S08 `08-host-owned-tool-hosts`, change `s08-pane-and-tool-host-surface`
// — the `host.toolHosts` registration namespace. A MAIN plugin publishes a
// wire-safe `HostToolHostDescriptorLike` (pure data: where its daemon lives,
// how it is launched, where its rendezvous files are) and the host takes over
// supervision + the generic entry surface. EXACTLY one verb `register`;
// nothing in the contract names a specific tool (acceptance C4). OPTIONAL
// member — the plugin guards `host.toolHosts?.register(...)`.
export type {
  HostToolHostDescriptorLike,
  HostToolHostsBackend,
  HostToolHostScaffoldFileLike,
  HostToolHostScaffoldSpecLike,
} from './host-api/tool-hosts';

// ── Main host API — plugin notification port (v1.53) ─────────────────────────
// Slice S08 `08-host-owned-tool-hosts`, change `s08-notifications-and-export`
// — the `host.notifications` namespace. A MAIN plugin raises ONE system
// notification (EXACTLY one verb `notify` → void) with an optional DATA-ONLY
// `openPath` click action executed by the HOST (no callback ever crosses — a
// notification may outlive its plugin). Title/body are an OS surface
// (retained, indexed, screenshotable): tokens/credential-bearing URLs are
// forbidden by contract; the `host:notifications` manifest token is the
// review signal. OPTIONAL member — the plugin guards
// `host.notifications?.notify(...)`.
export type {
  HostNotificationAction,
  HostNotificationInput,
  HostNotificationsBackend,
} from './host-api/notifications';

// ── Main host API — skill-toolkit registration port (v1.55) ──────────────────
// Change `third-party-tool-pack-channel` — the `host.toolkits` namespace. A
// MAIN plugin registers ONE `HostToolkitSpecLike` (name + description +
// SKILL.md + function catalog) into the host's toolkit registry, so the model
// reaches it through the existing `elftia_toolkit` MCP. EXACTLY one verb
// `register`; each function's `schema` is `unknown` (no Zod in this package)
// and the host duck-types it for a callable `safeParse` at the seam, rejecting
// the WHOLE spec on any failure. OPTIONAL member, MAIN-ONLY (the toolkit
// invocation context is not wire-safe) — the plugin guards
// `host.toolkits?.register(...)`.
export type {
  HostToolkitFunctionLike,
  HostToolkitsBackend,
  HostToolkitSpecLike,
} from './host-api/skill-toolkit';
