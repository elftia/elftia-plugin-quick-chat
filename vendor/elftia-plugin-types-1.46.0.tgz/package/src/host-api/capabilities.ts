/**
 * host-api/capabilities.ts — `host.capabilities`, the cross-plugin Capability
 * composition handle (design §8).
 *
 * A plugin declares `capabilities.provides` / `requires` / `optional` in its
 * `elftia-plugin.json`, then reaches the other side of that declaration through
 * this handle. Plugins never import each other, never read each other's
 * directories, and never call each other's scoped IPC — every cross-plugin call
 * goes through a Lease minted here (design D2 / §40 principle 5).
 *
 * ---------------------------------------------------------------------------
 * ONE INTERFACE, BOTH HALVES (design D3, restated 2026-08-12)
 * ---------------------------------------------------------------------------
 * Unlike `host.artifacts` — which MUST split into Main and Renderer handles
 * because it mixes React component types with a main-side data plane — nothing
 * in this module is React-, DOM- or Node-specific, so `backend.ts` and
 * `renderer.ts` expose the SAME `HostCapabilities` shape. `CapabilityTarget`
 * carries the process distinction as DATA instead.
 *
 * DOM-PURITY INVARIANT (Decision D2): no `electron` / `WebContents` / `node:*`
 * / `react` type is referenced here. Note in particular {@link HostAbortSignalLike}:
 * the repo's `tsconfig.base.json` ships `lib: [ES2022, DOM, DOM.Iterable]`, so a
 * bare `AbortSignal` WOULD have compiled — and would have quietly put a DOM type
 * on the main-half surface, violating freeze-checklist rule 3. The structural
 * shape below is what keeps that honest; a real `AbortSignal` satisfies it.
 *
 * STRUCTURAL RESTATEMENT (the `new-chat.ts` / `agent.ts` discipline): this
 * package declares NO runtime dependencies and imports no `@elftia/shared`
 * type. The shapes below are structural lower bounds of the canonical wire
 * contract.
 * @remarks Canonical source: `@elftia/shared`
 * `contracts/capability-composition.ts` (host-private).
 *
 * FROZEN SURFACE (design D21): `provide` / `require` / `explain` only.
 * `observe()` and `CapabilitySlot` are deliberately ABSENT — deferred until a
 * real optional consumer exists, at which point adding an optional method is an
 * additive MINOR. Optional availability is readable today via {@link HostCapabilities.explain}.
 *
 * @module @elftia/plugin-types/host-api/capabilities
 */

import type { HostUnregister } from './_shared';

/** Which process half a Capability is provided in / consumed from. */
export type HostCapabilityTarget = 'main' | 'renderer';

/**
 * A structured-clone-safe payload. Not `unknown`: these values cross a process
 * boundary, so functions and class instances must be excluded at the type level
 * rather than failing at postMessage time.
 */
export type HostWireValue =
  | null
  | boolean
  | number
  | string
  | readonly HostWireValue[]
  | { readonly [key: string]: HostWireValue };

/**
 * Structural lower bound of a cancellation signal.
 *
 * Declared rather than referencing the DOM `AbortSignal` — see the DOM-PURITY
 * note in the module header. A real `AbortSignal` is assignable to this.
 */
export interface HostAbortSignalLike {
  readonly aborted: boolean;
  addEventListener(type: 'abort', listener: () => void): void;
  removeEventListener(type: 'abort', listener: () => void): void;
}

/** One callable operation, as declared by its Provider. */
export interface HostCapabilityOperationDescriptor {
  readonly name: string;
  readonly mutability: 'read' | 'write' | 'destructive';
  readonly idempotency: 'idempotent' | 'non-idempotent';
  readonly cancellable?: boolean;
  readonly inputSchemaId: string;
  readonly outputSchemaId: string;
}

/** A Consumer's dependency. `range` is a SemVer RANGE (§8.2 rule 2). */
export interface HostCapabilityRequirement {
  readonly id: string;
  readonly range: string;
  readonly target: HostCapabilityTarget;
  readonly features?: readonly string[];
}

/** A Provider's offer. `version` is EXACT (§8.2 rule 1). */
export interface HostCapabilityProvided {
  readonly id: string;
  readonly version: string;
  readonly target: HostCapabilityTarget;
  readonly cardinality: 'single' | 'multiple';
  readonly features?: readonly string[];
  readonly operations: readonly HostCapabilityOperationDescriptor[];
}

/** Why a requirement is (un)satisfiable — the payload behind `explain()`. */
export interface HostCapabilityAvailability {
  readonly state:
    | 'available'
    | 'no-provider'
    | 'version-unsatisfied'
    | 'feature-unsatisfied'
    | 'provider-conflict'
    | 'provider-unavailable'
    | 'not-declared';
  readonly capabilityId: string;
  readonly providerPluginId?: string;
  readonly negotiatedVersion?: string;
  readonly features?: readonly string[];
  readonly offeredVersions?: readonly string[];
  readonly detail?: string;
}

/**
 * Placeholder for a resolved permission grant — **never populated in v1**
 * (OQ#3 ruled (a): the Capability surface performs no enforcement, matching the
 * 24 existing `host:*` tokens, which are all zero-enforcement declarations).
 * Frozen now so enabling enforcement later fills an existing optional field.
 */
export interface HostCapabilityGrant {
  readonly tokens: readonly string[];
  readonly artifactKinds?: readonly string[];
}

/**
 * The call context that reaches a Provider.
 *
 * ---------------------------------------------------------------------------
 * READ THIS BEFORE TRUSTING A FIELD — the members are NOT equally trustworthy
 * ---------------------------------------------------------------------------
 * HOST-DERIVED (a Consumer cannot influence these; the Host stamps them from
 * the registration it already holds):
 *   `consumerPluginId`, `providerPluginId`, `traceId`, `signal`, `grant`
 *
 * CALLER-ASSERTED (the Consumer supplies these via {@link HostCapabilityAcquireScope}
 * and the Host forwards them verbatim):
 *   `projectId`, `sessionId`
 *
 * The distinction is load-bearing and this doc comment used to get it wrong —
 * it claimed a Consumer "cannot forge any of these", which is true of the first
 * group and false of the second. A Provider that scopes stored data by
 * `context.projectId` on the strength of that sentence would let any consumer
 * read or write another project's data just by passing a different id, since
 * the declaration gate checks capability id and target only.
 *
 * So: treat `projectId`/`sessionId` as a ROUTING HINT the caller chose, never
 * as an authorization boundary. If a Provider needs a trustworthy project
 * identity, it must derive it from `consumerPluginId` plus its own records.
 * v1 does not offer a host-derived project identity; adding one later is
 * additive.
 */
export interface HostInjectedCapabilityContext {
  /** HOST-DERIVED. */
  readonly consumerPluginId: string;
  /** HOST-DERIVED. */
  readonly providerPluginId: string;
  /** CALLER-ASSERTED — a routing hint, not an authorization boundary. */
  readonly projectId?: string;
  /** CALLER-ASSERTED — a routing hint, not an authorization boundary. */
  readonly sessionId?: string;
  /** Opaque `ArtifactRef` once Phase 2 lands; structurally free until then. */
  readonly artifactRef?: HostWireValue;
  readonly traceId: string;
  readonly signal: HostAbortSignalLike;
  /** v1: always absent. See {@link HostCapabilityGrant}. */
  readonly grant?: HostCapabilityGrant;
}

/** What a Provider implements and hands to {@link HostCapabilities.provide}. */
export interface HostCapabilityEndpoint {
  invoke(
    context: HostInjectedCapabilityContext,
    operation: string,
    payload?: HostWireValue
  ): Promise<HostWireValue>;

  subscribe?(
    context: HostInjectedCapabilityContext,
    topic: string,
    emit: (event: HostWireValue) => void
  ): HostUnregister;
}

/**
 * A Consumer's live handle on a resolved Provider.
 *
 * Bound to a Provider GENERATION: after the Provider is disabled or reloaded
 * the old Lease does NOT silently reattach to the new generation — it is
 * revoked and `signal` fires (§8.5 invariants 1–2). That is also what makes the
 * deferral of `observe()` safe: an `explain()` → `require()` race resolves
 * through revocation rather than needing a Slot to watch.
 */
export interface HostCapabilityLease {
  readonly capabilityId: string;
  readonly providerPluginId: string;
  readonly negotiatedVersion: string;
  readonly features: readonly string[];
  /** Increments per Provider activation; pins this Lease to one of them. */
  readonly generation: number;
  /** Fires on revoke — Provider drain, disable, or Consumer teardown. */
  readonly signal: HostAbortSignalLike;

  invoke<TOutput extends HostWireValue = HostWireValue>(
    operation: string,
    input?: HostWireValue,
    options?: { readonly timeoutMs?: number; readonly idempotencyKey?: string }
  ): Promise<TOutput>;

  subscribe<TEvent extends HostWireValue = HostWireValue>(
    topic: string,
    listener: (event: TEvent) => void
  ): HostUnregister;

  /** Releases the Lease and every subscription taken through it. */
  release(): void;
}

/** Main-target-only dependency shape published to the reduced Pet Host. */
export interface HostPetCapabilityRequirement extends Omit<HostCapabilityRequirement, 'target'> {
  readonly target: 'main';
}

/** Consumer-only Pet lease. Provider/subscription/token authority is deliberately absent. */
export interface HostPetCapabilityLease {
  readonly capabilityId: string;
  readonly providerPluginId: string;
  readonly negotiatedVersion: string;
  readonly features: readonly string[];
  readonly generation: number;
  invoke<TOutput extends HostWireValue = HostWireValue>(
    operation: string,
    input?: HostWireValue
  ): Promise<TOutput>;
  release(): Promise<void>;
}

/** Pet-scoped consumer projection: availability read plus generation-bound acquisition. */
export interface HostPetCapabilityConsumer {
  explain(requirement: HostPetCapabilityRequirement): Promise<HostCapabilityAvailability>;
  require(requirement: HostPetCapabilityRequirement): Promise<HostPetCapabilityLease>;
}

/** Scope a Lease is taken in; ties its lifetime to the Consumer's owner scope. */
export interface HostCapabilityAcquireScope {
  readonly projectId?: string;
  readonly sessionId?: string;
}

/**
 * `host.capabilities` — the composition handle.
 *
 * 窄端口 justification, per member (freeze-checklist rule 2):
 * - `provide` — the Provider side's only entry point.
 * - `require` — the Consumer side's only entry point.
 * - `explain` — required by design §39 ("Host 能解释依赖为什么不可用"), and with
 *   `observe()` deferred it is also how optional availability is read.
 *
 * `observe()` is NOT here by deliberate omission (D21), not oversight.
 */
export interface HostCapabilities {
  /**
   * Publish a Capability. The descriptor MUST match the plugin's manifest
   * declaration — a runtime `provide()` that the manifest never declared is
   * rejected (§8.2 rule 6).
   */
  provide(descriptor: HostCapabilityProvided, endpoint: HostCapabilityEndpoint): HostUnregister;

  /**
   * Acquire a Lease. Rejects with `CAPABILITY_NOT_FOUND` when the requirement
   * was never declared in the manifest (§8.2 rule 7) — the first of the two
   * real gates v1 enforces.
   */
  require(
    requirement: HostCapabilityRequirement,
    scope?: HostCapabilityAcquireScope
  ): Promise<HostCapabilityLease>;

  /** Resolve availability WITHOUT acquiring. Never throws for unavailability. */
  explain(requirement: HostCapabilityRequirement): Promise<HostCapabilityAvailability>;
}
