/**
 * host-api/components.ts — `AgentUiHostComponents`, the ADDITIVE v1.2
 * `host.components` member of `AgentUiHostApi`: host-OWNED React component bodies
 * a first-party code plugin (Design Studio) embeds but CANNOT vendor without
 * dragging a heavy host dependency into the plugin chunk (or duplicating
 * substantial host code).
 *
 * DISTINCT FROM `host.ui`: `host.ui` is the SMALL set of mandated PRIMITIVES
 * (Button/Input/…); `host.components` carries heavier host FEATURE bodies. The
 * loader injects the REAL host components (the factory imports them from their
 * canonical host modules); the plugin renders them via `host.components.<X>`
 * against `host.react` (one shared React instance — the same dual-instance
 * guarantee as `host.ui`).
 *
 * MINIMALITY (窄端口): exactly the 3 bodies DS embeds, each justified by the
 * chunk-size hazard / can't-vendor-without-dragging-heavy-deps criterion:
 *   - `CodeEditor` — codemirror-backed; host-provided keeps codemirror OFF the
 *     plugin chunk (the Phase-3 first-screen-leak lesson).
 *   - `DevPreviewPanel` — host dev-server preview machinery.
 *   - `MediaHoverCard` — a non-trivial host gallery card.
 *
 * DOM-PURITY INVARIANT (Decision D2 / D6): React-shaped only — prop shapes are
 * structural lower bounds anchored to the canonical host components; no Node/
 * Electron leak beyond `HostReactNode`. No host component is BUNDLED — these are
 * TYPE references injected by the loader.
 *
 * @module @elftia/plugin-types/host-api/components
 */
import type { HostComponentType, HostReactNode } from './_shared';

/**
 * Props for `host.components.DevPreviewPanel`.
 * @remarks Canonical: `@/features/agents/components/dev-preview`
 *   (`DevPreviewPanelProps`).
 */
export interface HostDevPreviewPanelProps {
  sessionId: string;
  hideToolbar?: boolean;
  consoleOpen?: boolean;
  onConsoleOpenChange?: (open: boolean) => void;
  [key: string]: unknown;
}

/**
 * A code-editor file descriptor (structural lower bound of `CodeEditorFile`).
 * Opaque — DS threads the `ctx.selectedFile` through.
 */
export interface HostCodeEditorFile {
  readonly [key: string]: unknown;
}

/**
 * Props for `host.components.CodeEditor`.
 * @remarks Canonical: `@/features/code/components/code-editor/CodeEditor`
 *   (`CodeEditorProps`; codemirror-backed — host-provided per the chunk mandate).
 */
export interface HostCodeEditorProps {
  file: HostCodeEditorFile;
  onClose: () => void;
  projectPath?: string | null;
  isSidebar?: boolean;
  isExpanded?: boolean;
  onToggleExpand?: (() => void) | null;
  [key: string]: unknown;
}

/** A single hover-card action (structural lower bound of `MediaHoverCardAction`). */
export interface HostMediaHoverCardAction {
  label: string;
  onClick: () => void;
  variant?: 'primary' | 'secondary';
  icon?: HostReactNode;
  iconOnly?: boolean;
  disabled?: boolean;
  [key: string]: unknown;
}

/**
 * Props for `host.components.MediaHoverCard`.
 * @remarks Canonical: `@/shared/components/media-card` (`MediaHoverCardProps`).
 *   Pins the fields DS passes; the rest stays opaque.
 */
export interface HostMediaHoverCardProps {
  media: HostReactNode;
  title: string;
  aspectRatio?: string;
  subtitle?: string;
  description?: string;
  tags?: string[];
  badge?: HostReactNode;
  topLeft?: HostReactNode;
  topRight?: HostReactNode;
  bottomRight?: HostReactNode;
  primaryAction?: HostMediaHoverCardAction;
  secondaryActions?: HostMediaHoverCardAction[];
  menu?: HostReactNode;
  onActivate?: () => void;
  footer?: 'title-tags' | 'title' | 'none';
  activateLabel?: string;
  className?: string;
  [key: string]: unknown;
}

/**
 * `host.components` — the host-provided React feature bodies. Each is a
 * `HostComponentType<…Props>` injected by the loader from its real host module;
 * the plugin renders it against `host.react`.
 *
 * @stability additive (MINOR) — only the bodies DS embeds; each justified by the
 *   chunk-size / can't-vendor criterion (freeze-checklist minimality rule).
 */
export interface AgentUiHostComponents {
  /** Host dev-server preview body. @remarks `@/features/agents/components/dev-preview`. */
  DevPreviewPanel: HostComponentType<HostDevPreviewPanelProps>;
  /** Codemirror editor (host-provided → codemirror stays off the plugin chunk).
   *  @remarks `@/features/code/components/code-editor/CodeEditor`. */
  CodeEditor: HostComponentType<HostCodeEditorProps>;
  /** Host media gallery card. @remarks `@/shared/components/media-card`. */
  MediaHoverCard: HostComponentType<HostMediaHoverCardProps>;
}
