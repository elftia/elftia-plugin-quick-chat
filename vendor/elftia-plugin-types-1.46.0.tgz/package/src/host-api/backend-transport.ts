/**
 * host-api/backend-transport.ts — the backend host TRANSPORT contract
 * (`plugin-proc-isolation-p0` Phase 0, v1.10): a deliberately LOW-LEVEL
 * request/response + event-subscription seam whose payloads are constrained to
 * structured-clone-safe `WireValue`s.
 *
 * Phase 0 posture: the shipped runtime stays IN-PROCESS — the host implements
 * this contract with a `LocalTransport` that wraps the same live singleton
 * services (zero behavior change). The contract exists so plugin-to-host
 * consumption is EXPRESSED as wire-safe payloads today; a future Phase 1
 * `utilityProcess` boundary becomes a transport substitution, not a contract
 * redesign. The transport NEVER exposes live host services or process
 * primitives — domain-specific handles (`db`, `engineDispatcher`, `storage`, …)
 * remain typed service adapters built ON TOP of it.
 *
 * `WireValue` is DEFINED in `@elftia/agent-spec` and imported/re-exported here
 * (LEAD ruling): plugin-types already depends on agent-spec (the engine seam in
 * `backend-services.ts`); the reverse import would be a package cycle.
 *
 * MINIMALITY (freeze checklist item 2): two members — `request` (the RPC shape
 * every future host method rides) and `subscribe` (the host→plugin event
 * shape). No register/dispatch verbs here; those stay on the frozen
 * `AgentBackendHostApi` members. No DOM/Node type appears (item 3): the
 * surface is `string` / `Promise` / `WireValue` / `HostUnregister` only.
 *
 * @module @elftia/plugin-types/host-api/backend-transport
 */
import type { WireValue } from '@elftia/agent-spec';

import type { HostUnregister } from './_shared';

// Re-exported so transport consumers can name the payload type without adding
// their own `@elftia/agent-spec` import edge.
export type { WireValue };

/**
 * The backend host transport: request/response + event subscription over
 * structured-clone-safe payloads. Implemented in-process by the host's
 * `LocalTransport` (Phase 0) and by a process transport later (Phase 1) —
 * consumers compile against THIS interface either way.
 *
 * @stability additive (MINOR, v1.10) — frozen once published; evolution
 *   follows the `version.ts` freeze checklist.
 */
export interface BackendHostTransport {
  /**
   * Invoke a host-side method by string id with an optional wire-safe payload
   * and await the wire-safe result. The transport REJECTS (with a wire-safety
   * error) any payload carrying a function, symbol, class instance, or other
   * non-clonable value BEFORE the host handler runs; a handler error
   * propagates to the caller unchanged.
   */
  request<T extends WireValue = WireValue>(method: string, payload?: WireValue): Promise<T>;
  /**
   * Subscribe to a host-emitted event. The handler receives wire-safe payloads
   * only; the returned unregister stops delivery (later emits never invoke an
   * unsubscribed handler).
   */
  subscribe(event: string, handler: (payload: WireValue) => void): HostUnregister;
}
