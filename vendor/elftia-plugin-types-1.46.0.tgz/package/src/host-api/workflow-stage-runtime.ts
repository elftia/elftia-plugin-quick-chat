/**
 * host-api/workflow-stage-runtime.ts — `HostWorkflowStageRuntimeLike`, the
 * wire-safe port a workflow reaches a STAGE DISPATCH substrate through
 * (`rasen-single-plugin` Milestone 2, host-API v1.40).
 *
 * WHY: a workflow's pipeline state machine has to run a stage's worker somewhere
 * — an in-process agent, an external CLI, later something else entirely. Before
 * this port the state machine held the dispatch implementation itself (a live
 * `AgentOrchestrator`) and learned its worker's session id through a CALLBACK it
 * passed down, neither of which survives a process boundary. This port is the
 * seam: THREE verbs, an OPAQUE execution id, and every value JSON
 * round-trippable, so the same contract serves the in-process path today and a
 * wire-proxied extension host later WITHOUT a shape change.
 *
 * DEEP MODULE: the interface is three verbs, but the obligations below are part
 * of the contract, not decoration. A runtime that type-checks yet violates them
 * is non-conforming. Read the per-verb JSDoc as specification.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module. It MUST NOT be
 * imported by `renderer.ts`; only `backend.ts` imports it. Every field is a
 * plain `string` / `number` / `boolean` — no DOM type, no `electron`/Node type,
 * no `@main`/`@shared` import.
 *
 * @module @elftia/plugin-types/host-api/workflow-stage-runtime
 */
import type { HostWorkflowErrorCode } from './workflow';

// ───────────────────────────────────────────────────────────────────────────
// Start input — the backend is DATA, the role is observability
// ───────────────────────────────────────────────────────────────────────────

/**
 * Which dispatch substrate a stage runs on — a CLOSED vocabulary carried as a
 * VALUE on {@link HostStageStartInput}, never as object identity.
 *
 * Carrying it as DATA is what lets a caller hold ONE runtime reference instead
 * of one object per backend, and what lets a runtime with no adapter for the
 * requested backend fall back to its default rather than failing the stage.
 * Adding a backend is a CONTRACT change, not an implementation detail.
 */
export type HostStageBackend = 'agent' | 'codex';

/**
 * Which pipeline role a dispatch serves.
 *
 * OBSERVABILITY-ONLY (design D12): no admission, routing or outcome decision may
 * branch on this value. Two dispatches differing ONLY in `role` MUST admit,
 * complete and cancel identically. The label exists so the dispatch boundary can
 * log and trace which role a worker served — before this port it was dropped at
 * the executor boundary and nothing observable carried it.
 */
export type HostStageRole = 'stage' | 'planner' | 'reviewer' | 'fixer' | 'implementer';

/**
 * Everything a runtime needs to admit ONE stage dispatch.
 *
 * WIRE-SAFETY: plain strings and numbers ONLY. NEVER a callback, NEVER a host
 * service handle, NEVER a live object. A runtime that needs a host capability
 * receives it at ITS OWN construction, not smuggled through a start input.
 */
export interface HostStageStartInput {
  /** The substrate to dispatch on — see {@link HostStageBackend}. */
  readonly backend: HostStageBackend;
  /** The pipeline role this dispatch serves. Observability-only (design D12). */
  readonly role: HostStageRole;
  /** The fully-composed prompt the worker runs. The runtime does not author it. */
  readonly prompt: string;
  /** Codebase root the worker runs in. Absent ⇒ the runtime's own default. */
  readonly projectPath?: string;
  /** Which agent to dispatch, when the backend addresses agents by id. */
  readonly agentId?: string;
  /**
   * The dispatch budget in milliseconds. The CALLER owns the budget; the runtime
   * owns ENFORCEMENT — and enforcement means terminating the real worker before
   * reporting {@link HostStageOutcome} `'timeout'`, never merely giving up on it.
   */
  readonly timeoutMs: number;
}

// ───────────────────────────────────────────────────────────────────────────
// Start result — a RESULT union, because a code must survive the wire
// ───────────────────────────────────────────────────────────────────────────

/**
 * The answer to an admission attempt — an execution id, or a NAMED failure.
 *
 * WHY A RESULT AND NOT A THROW (design D1): the two admission failures a caller
 * must branch on are "the substrate is at max concurrency, back off and retry"
 * and "the dispatch failed". A rejection carries no machine-readable code across
 * a process boundary, so expressing that distinction as a throw is unsatisfiable
 * for the very seam this port exists for.
 *
 * OBLIGATIONS:
 *   - a BUSY refusal MUST use `'stage_dispatch_busy'` — the RETRYABLE code. The
 *     caller may retry the same start input after a backoff and the stage is NOT
 *     treated as failed;
 *   - any other admission failure MUST use `'stage_dispatch_failed'`;
 *   - both codes are members of the CLOSED {@link HostWorkflowErrorCode}
 *     vocabulary the workflow port already publishes — they were added for this.
 *     Emitting a code outside that vocabulary is a contract violation, and
 *     introducing a new one is a contract change.
 */
export type HostStageStartResult =
  | {
      readonly ok: true;
      /**
       * The OPAQUE handle to the admitted execution. The caller derives no
       * backend, session or routing meaning from it, and the runtime stays free
       * to change how the value is minted without changing any caller.
       */
      readonly executionId: string;
    }
  | {
      readonly ok: false;
      readonly error: {
        /** A code from the closed workflow vocabulary — see the obligations above. */
        readonly code: HostWorkflowErrorCode;
        /** Readable message. Never a stack, never a host object. */
        readonly message: string;
      };
    };

// ───────────────────────────────────────────────────────────────────────────
// Outcome — the RAW dispatch vocabulary, not the caller's state machine
// ───────────────────────────────────────────────────────────────────────────

/**
 * What the dispatch substrate DID — reported in the RAW dispatch vocabulary
 * (design D2), deliberately NOT in the caller's state-machine vocabulary.
 *
 * WHY (design D2): different backends produce different wording for the SAME
 * status ("timed out and was cancelled" vs "timed out and was terminated").
 * Flattening the vocabulary at the port would force one caller-side mapper to
 * re-synthesize per-backend prose it no longer knows. So the runtime reports
 * what happened and COMPOSES ITS OWN `note`; a caller serving several backends
 * maps the four statuses onto its own vocabulary once and never synthesizes
 * per-backend wording.
 *
 * `'cancelled'` is its OWN status, never collapsed into `'error'`.
 */
export interface HostStageOutcome {
  /** What the substrate did. `'cancelled'` is distinct from `'error'`. */
  readonly status: 'completed' | 'timeout' | 'error' | 'cancelled';
  /**
   * The worker's session identifier, when one exists — the pointer a caller
   * persists to reach the transcript. Backend-neutral by name: a caller that
   * stores it under its own field name maps it; the runtime does not.
   */
  readonly sessionId?: string;
  /**
   * A message COMPOSED BY THE RUNTIME that dispatched, for every outcome that is
   * not a plain completion. Never assembled by the caller.
   */
  readonly note?: string;
}

// ───────────────────────────────────────────────────────────────────────────
// The port — three verbs, with behavioral obligations
// ───────────────────────────────────────────────────────────────────────────

/**
 * A stage runtime — EXACTLY three verbs, addressed only by the opaque id
 * {@link HostWorkflowStageRuntimeLike.start} returned.
 *
 * NARROW-PORT MINIMALITY (窄端口): no handle, no promise, no session object and
 * no other live reference to the dispatched worker is ever handed to the caller.
 * There is no listener, no emitter and no callback anywhere in this contract:
 * the one piece of MID-FLIGHT information a caller needs — the execution id —
 * is a RETURN VALUE, obtained in the caller's own stack frame before it awaits
 * completion.
 *
 * WIRE-SAFETY: every value crossing this port is JSON round-trippable. The port
 * neither accepts nor returns a function, a logger, a service handle, an
 * Electron object or any other live host reference.
 */
export interface HostWorkflowStageRuntimeLike {
  /**
   * Admit ONE dispatch and answer with its execution id.
   *
   * OBLIGATIONS:
   *   - resolve as soon as the execution is ADDRESSABLE, not when it completes —
   *     admission and completion are two distinct calls so the caller can record
   *     the id for cancellation in between;
   *   - answer a refusal the caller must branch on as a RESULT
   *     ({@link HostStageStartResult}), not as a rejection;
   *   - a max-concurrency refusal is `'stage_dispatch_busy'` (retryable); any
   *     other admission failure is `'stage_dispatch_failed'`;
   *   - mint an execution id unique among the runtime's LIVE executions.
   */
  start(input: HostStageStartInput): Promise<HostStageStartResult>;

  /**
   * Await the completion of a previously admitted execution.
   *
   * OBLIGATIONS:
   *   - resolve with the RAW dispatch outcome ({@link HostStageOutcome}), never
   *     the caller's state-machine vocabulary;
   *   - when the dispatch exceeds {@link HostStageStartInput.timeoutMs},
   *     TERMINATE the real worker FIRST and only then resolve `'timeout'`. A
   *     timed-out stage must never leave a worker still running and still able
   *     to write;
   *   - resolve rather than reject for a substrate failure — a failed dispatch
   *     is the `'error'` outcome carrying the runtime's own message.
   */
  wait(executionId: string): Promise<HostStageOutcome>;

  /**
   * Cancel a live execution.
   *
   * OBLIGATIONS:
   *   - VALID the moment {@link HostWorkflowStageRuntimeLike.start} resolves — a
   *     cancellation issued before `wait` resolves reaches the running worker;
   *   - route ONLY to the execution the id names. A cancellation is never
   *     broadcast to other live executions;
   *   - be INERT for an unknown or already-resolved id: resolve without throwing
   *     and without invoking any substrate;
   *   - reclaim the substrate's slot, so a cancelled execution leaves no zombie
   *     writer behind.
   */
  cancel(executionId: string, reason?: string): Promise<void>;
}
