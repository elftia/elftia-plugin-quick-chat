/**
 * host-api/agent-events.ts — `AgentUiAgentEvents`, the ADDITIVE v1.15
 * `host.agentEvents` member of `AgentUiHostApi`: a NARROW PUSH port that
 * subscribes to the host's per-session `agent:event` stream.
 *
 * 窄端口 DISCIPLINE: exposes EXACTLY ONE member — `subscribe(listener):
 * HostUnregister`. NO request/response (`invoke`), NO per-session filter
 * argument (the consumer filters by `sessionId` client-side), NO raw
 * `WebContents` / `ipcRenderer` object, NO `CHANNELS` constant. The host wires
 * `subscribe` to the existing `agent.onEvent` IPC subscription (the channel the
 * preload exposes as `window.native.agent.onEvent` / `CHANNELS.agent.onEvent`);
 * the IPC channel, routers, and main-side emission are UNCHANGED. This is the
 * single host-internal edge a `plugin://` bundle could not reach (the
 * htmlPreview WRITE side has been covered by `host.stores.htmlPreview` since
 * v1.1; persistence by the scoped `host.ipc.invoke` bridge).
 *
 * The push-subscription precedent is `host.stores.*.subscribe` /
 * `host.canvas.on*` — a distinct surface from the v1.2 request/response
 * `host.agent` port, so this is a NEW sibling member, not an addition to
 * `host.agent`.
 *
 * DOM-PURITY INVARIANT (Decision D2 / D6): this module imports ONLY
 * `./_shared`. The event payload is a structural LOWER BOUND — no `electron` /
 * `WebContents` / `node:*` type, no `@elftia/shared` agent-event type, no
 * renderer-source import, no `react` runtime dep. The host's own
 * `AgentApi.onEvent` is typed `(event: unknown) => void`, so this contract pins
 * only the three fields the `<artifact>` stream consumer reads and leaves the
 * rest opaque.
 *
 * @module @elftia/plugin-types/host-api/agent-events
 */
import type { HostUnregister } from './_shared';

/**
 * Structural LOWER BOUND of one envelope from the host's per-session
 * `agent:event` stream. Pins ONLY the fields the design `<artifact>` stream
 * consumer reads — a required `type`, an optional `sessionId`, and an optional
 * `delta` text-chunk record; everything else stays opaque
 * (`[key: string]: unknown`).
 *
 * The host's own `AgentApi.onEvent` callback is typed `(event: unknown) =>
 * void`, so this contract pulls NO `@elftia/shared` agent-event type — it is a
 * lower bound, kept structural so a newer host envelope shape still type-checks.
 *
 * @remarks Canonical: the runtime `agent:event` envelope (host-private,
 *   delivered by `window.native.agent.onEvent` / `CHANNELS.agent.onEvent`). The
 *   delta variants (`{ type:'text_delta', text }` /
 *   `{ type:'content_block_delta', delta:{ text } }`) match the parser's
 *   `inferDeltaText` (`ArtifactStreamConsumer`); the consumer filters by
 *   `sessionId` itself, processes only `type === 'streamDelta'` envelopes, and
 *   reads `delta.text` / `delta.content` / `delta.delta.text`.
 */
export interface HostAgentStreamEvent {
  /** Event discriminator, e.g. `'streamDelta'` / `'complete'`. REQUIRED. */
  readonly type: string;
  /** The session the event belongs to (the consumer filters on this). */
  readonly sessionId?: string;
  /** Streaming delta payload (text-chunk variants). Opaque-extensible. */
  readonly delta?: {
    readonly type?: string;
    readonly content?: string;
    readonly text?: string;
    readonly [key: string]: unknown;
  };
  /** Remaining members are opaque — see source. */
  readonly [key: string]: unknown;
}

/**
 * `host.agentEvents` — subscribe to the host's per-session `agent:event`
 * stream. A SINGLE-PURPOSE PUSH port (the `host.stores` / `host.canvas`
 * subscription precedent); NO request/response, no filter argument, no host
 * IPC object.
 *
 * @stability frozen (the BACKING `agent.onEvent` subscription is the contract)
 */
export interface AgentUiAgentEvents {
  /**
   * Subscribe to every `agent:event` envelope. The listener receives the raw
   * {@link HostAgentStreamEvent}; the consumer filters by `sessionId` itself.
   * Returns an unsubscribe function.
   *
   * @remarks Routes to the host `agent.onEvent(cb)` IPC subscription
   *   (`@/shared/agent` → `CHANNELS.agent.onEvent`). The IPC channel, its
   *   preload bridge, the routers, and main-side emission are UNCHANGED.
   */
  subscribe(listener: (event: HostAgentStreamEvent) => void): HostUnregister;
}
