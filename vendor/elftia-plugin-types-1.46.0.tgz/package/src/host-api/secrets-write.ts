/**
 * host-api/secrets-write.ts — `HostSecretsWriteLike`, the generic write-only
 * `host.services.secretsWrite` capability port (`byo-port-llm-config`,
 * host-API v1.21).
 *
 * WRITE-ONLY BY CONSTRUCTION (design D4): the ONLY operation is
 * `setSecret(ref, value): Promise<void>`. There is NO `getSecret`, NO list, and
 * NO return value beyond `void` — a BYO plugin can store a secret but can never
 * read one back through this port (plaintext never crosses the boundary
 * outward). The host adapter additionally guards `ref` against the shared BYO
 * namespace-prefix allowlist (`@elftia/shared` `isAllowedByoSecretRef`) and
 * rejects a foreign ref BEFORE any store interaction.
 *
 * REUSE (the keystone): the later media/search/subscription port knives DO NOT
 * define a second write port — they add their secret-ref prefix to the shared
 * allowlist and call THIS same `host.services.secretsWrite`.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports it.
 * Both members use `string`/`Promise<void>` only — no DOM/Node type leaks in.
 *
 * @module @elftia/plugin-types/host-api/secrets-write
 */

/**
 * `host.services.secretsWrite` — the generic write-only secrets port. Exactly
 * one member; backed by `SecretsService` through the host's `SecretStorePort`.
 */
export interface HostSecretsWriteLike {
  /**
   * Store `value` (encrypted at rest, sse:v1/aes:v1 — never plaintext on disk)
   * under `ref`. `ref` MUST match a BYO namespace prefix (the host adapter
   * rejects a foreign ref with a namespace error that names the ref but NOT the
   * value). Resolves `void`; NEVER returns the stored value.
   */
  setSecret(ref: string, value: string): Promise<void>;
}
