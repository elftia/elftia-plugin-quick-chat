/**
 * host-api/media-config.ts — `HostMediaConfigLike`, the `host.services.mediaConfig`
 * capability port (`byo-port-media-config`, host-API v1.23).
 *
 * Lets a Tier-1 main plugin (the future `byo-providers` plugin) drive ALL FIVE
 * media-provider types — image / video / music / tts / asr — WITHOUT the host
 * owning any BYO media-config UI: provider CRUD, model management (rides the
 * `updateProvider` patch's `models`/`modelGroups` arrays), default selection
 * (rides `updateProvider`/`setGlobalSettings`), upstream-model refresh, and the
 * image-only library reset.
 *
 * ── FLAT DISCRIMINATED SURFACE (design D1) ──
 * Every method carries a `mediaType` of {@link HostMediaType} as its first
 * argument. The 5 ConfigServices are ~9 near-identical CRUD signatures; flat +
 * a `mediaType` discriminator minimizes the contract surface vs 5×-duplicated
 * sub-handles, while per-type type-safety is preserved structurally — every
 * canonical per-type provider/state shape is structurally assignable to the
 * masked lower bounds below, and the adapter dispatches `mediaType` → the
 * matching `{ config, generation }` pair.
 *
 * ── MASK-ON-RETURN INVARIANT (the security crux, design D2) ──
 * EVERY provider this port returns (from `listProviders`, `getProvider`, or any
 * mutation result envelope) has its `config.apiKey` stripped — a `configured`
 * boolean (+ an optional `hasKey`) stands in. The mask is enforced TWICE:
 *   (a) at the adapter boundary (a `toPluginMediaProvider` strip), AND
 *   (b) STRUCTURALLY here — {@link HostMaskedMediaProviderConfig} types `apiKey`
 *       as `?: never`, so a returned provider whose `config` carried a populated
 *       `apiKey` would FAIL to type-check (a forgotten adapter strip is a
 *       compile error, not a silent leak).
 * The provider API key is written ONLY through {@link HostMediaConfigLike.setProviderKey}
 * (host-API v1.25, `byo-media-secret-hardening`), which routes the secret write
 * through `host.services.secretsWrite` under the per-type `media-<type>:<id>:apiKey`
 * ref (now allowed by `isAllowedByoSecretRef`) — media keys live in SecretsService,
 * NOT a plaintext DB column. `updateProvider`/`createCustomProvider` carry NO
 * `apiKey`; an empty/whitespace `setProviderKey` clears the stored secret. (Before
 * v1.25 the key rode the `updateProvider` patch into a plaintext column — that
 * hardening is now done.)
 *
 * ── THE REVEAL EXCEPTION (host-API v1.50) ──
 * `revealProviderKey`/`revealProviderSecret` are the ONE deliberate outward
 * exception: they return the stored secret for USER-INITIATED display (the
 * settings eye icon). The revealed value rides a dedicated
 * {@link HostMediaKeyRevealResult} — never a provider row — so the structural
 * mask above stays intact for every other method.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports it.
 * No DOM type leaks in. Like `HostLlmConfigLike`, the payload shapes are
 * STRUCTURAL LOWER BOUNDS (Node-shaped, no `@main`/`@shared` import) — the host's
 * canonical `MediaProviderState` / `TtsProviderState` / `AsrProviderState` / … are
 * structurally assignable (minus the masked `apiKey`), and the plugin re-narrows
 * what it reads.
 *
 * @module @elftia/plugin-types/host-api/media-config
 */

/** The five media-provider types, the `mediaType` discriminator (design D1). */
export type HostMediaType = 'image' | 'video' | 'music' | 'tts' | 'asr';

/**
 * The MASKED `config` of a returned provider. Pins the credential-presence
 * surface the contract guarantees; `apiKey` is typed `?: never` so it can NEVER
 * be populated on a return (a forgotten adapter strip fails to type-check — the
 * structural half of the double-enforcement). Non-secret config fields
 * (`endpoint` / `projectId` / `location` / `defaultModelId` / `enabled` / …)
 * survive through the index signature; `projectId` is NOT a secret and stays.
 */
export interface HostMaskedMediaProviderConfig {
  /**
   * STRUCTURALLY ABSENT — the port never returns a media provider API key.
   * Typed `?: never` (not merely omitted) so any masked-provider value that
   * carried a populated `apiKey` is a COMPILE error at the adapter boundary.
   */
  readonly apiKey?: never;
  /** STRUCTURALLY ABSENT — BytePlus VOD secrets are never returned. */
  readonly byteplusAk?: never;
  /** STRUCTURALLY ABSENT — BytePlus VOD secrets are never returned. */
  readonly byteplusSk?: never;
  /** Remaining non-secret config fields are opaque — see the canonical state's `config`. */
  readonly [key: string]: unknown;
}

/**
 * A renderer-shaped media provider with its credential MASKED. Pins `id` +
 * `configured` (the boolean every canonical state carries) + the masked
 * {@link HostMaskedMediaProviderConfig}; the rest of the provider row (name,
 * models, modelGroups, type, defaultModelId, …) is opaque. Canonical (per type):
 * `MediaProviderState` / `VideoProviderState` / `MusicProviderState` /
 * `TtsProviderState` / `AsrProviderState` — each structurally assignable once the
 * adapter strips `config.apiKey`.
 */
export interface HostMaskedMediaProvider {
  /** Stable provider id. */
  readonly id: string;
  /** Whether a credential is stored (the canonical `configured` boolean). */
  readonly configured: boolean;
  /** Non-reversible presence flag (mirrors `configured`; never the key). */
  readonly hasKey?: boolean;
  /** The MASKED credential config — `apiKey` is `?: never` (structurally unpopulatable). */
  readonly config: HostMaskedMediaProviderConfig;
  /** Remaining provider fields are opaque — see the canonical per-type state. */
  readonly [key: string]: unknown;
}

/**
 * The mutation/toggle/create/reset result envelope, as the IPC path returns it.
 * `provider` (when present) is ALREADY masked. Some ConfigService methods return
 * the masked provider directly (image `updateProviderConfig` / `createCustomProvider`)
 * — the adapter normalizes both into a masked provider (see `HostMaskedMediaProvider`)
 * and never lets a populated `apiKey` cross.
 */
export interface HostMediaProviderResult {
  readonly success: boolean;
  readonly message?: string;
  /** The masked provider after the mutation (absent on failure). */
  readonly provider?: HostMaskedMediaProvider;
  /** Remaining envelope fields are opaque BUT the contract guarantees no `config.apiKey`. */
  readonly [key: string]: unknown;
}

/** A plain `{ success, message? }` op result (delete). */
export interface HostMediaOpResult {
  readonly success: boolean;
  readonly message?: string;
}

/**
 * Per-`mediaType` global settings — an opaque structural record. The shapes
 * differ per type (image: concurrency/retry/resolution/aspect; video/music:
 * concurrency/retry/defaultProviderId; tts: defaultProviderId/defaultVoiceId;
 * asr: defaultProviderId/language). Carries no credential; typed opaque so each
 * canonical settings shape is assignable and the plugin re-narrows by `mediaType`.
 */
export type HostMediaGlobalSettings = { readonly [key: string]: unknown };

/** A `{ success, settings?, message? }` global-settings write envelope. */
export interface HostMediaGlobalSettingsResult {
  readonly success: boolean;
  readonly message?: string;
  readonly settings?: HostMediaGlobalSettings;
}

/**
 * The model-refresh result (`refreshUpstreamModels`). `provider` (when present)
 * is masked; `success: false` for providers without a discoverable model API.
 */
export interface HostMediaModelRefreshResult {
  readonly success: boolean;
  readonly message?: string;
  /** The masked provider after a successful refresh (absent on failure). */
  readonly provider?: HostMaskedMediaProvider;
}

/**
 * A provider-update patch. Carries the non-secret config + model-management
 * arrays ONLY. As of host-API v1.25 (`byo-media-secret-hardening`) it carries NO
 * `apiKey` — the key is written EXCLUSIVELY through
 * {@link HostMediaConfigLike.setProviderKey} (routed through `secretsWrite`). A
 * structural lower bound over each canonical `*ProviderUpdatePayload` minus the
 * key; the adapter Zod-validates per `mediaType` with the SAME schema the
 * matching IPC handler uses (the schema also drops `apiKey`).
 */
export interface HostMediaProviderUpdate {
  /**
   * STRUCTURALLY ABSENT — the key is NOT a patch field (v1.25). Typed `?: never`
   * (not merely omitted) so a plugin that still tries to set the key via the
   * patch fails to type-check; it must use `setProviderKey`.
   */
  readonly apiKey?: never;
  /** STRUCTURALLY ABSENT — use `setProviderSecret` for the BytePlus VOD AK. */
  readonly byteplusAk?: never;
  /** STRUCTURALLY ABSENT — use `setProviderSecret` for the BytePlus VOD SK. */
  readonly byteplusSk?: never;
  /** Remaining patch fields (enabled / endpoint / defaultModelId / models / modelGroups / …). */
  readonly [key: string]: unknown;
}

/** A `{ success, error? }` key-write result — NEVER carries the key. */
export interface HostMediaKeyWriteResult {
  readonly success: boolean;
  readonly error?: string;
}

/**
 * The EXPLICIT key-reveal result (host-API v1.50) — the ONE deliberate
 * exception to the mask-on-return invariant: carries the stored secret
 * OUTWARD, only on the `revealProviderKey`/`revealProviderSecret` verbs, only
 * for user-initiated display (the settings eye icon). `value` is the stored
 * plaintext (or `''` when none is stored); it lives on THIS result type —
 * outside {@link HostMaskedMediaProvider} — so a reveal value can never
 * type-check onto a provider row and the `apiKey?: never` structural mask
 * stays intact.
 */
export interface HostMediaKeyRevealResult {
  readonly success: boolean;
  /** The stored secret (plaintext); `''` when none is stored. Absent on failure. */
  readonly value?: string;
  readonly error?: string;
}

/** The only non-apiKey media secrets exposed by the narrow write-only port. */
export type HostMediaProviderSecretField = 'byteplusAk' | 'byteplusSk';

/**
 * A custom-provider create input. A structural lower bound over each canonical
 * `*CustomProviderInput` (`baseProviderId` + display fields); the adapter
 * Zod-validates per `mediaType` with the SAME schema the matching IPC handler uses.
 */
export interface HostMediaCustomProviderInput {
  readonly baseProviderId: string;
  readonly name: string;
  readonly [key: string]: unknown;
}

/**
 * `host.services.mediaConfig` — the media-provider config capability port.
 *
 * Every method takes a `mediaType` discriminator + Zod-validates its payload
 * (≥ the corresponding `mediaProviders.<type>.*` IPC handler, reusing the same
 * schemas) before delegating to the host's matching ConfigService (CRUD/settings)
 * or generation service (`refreshUpstreamModels`). Every provider RETURN is
 * masked — `config.apiKey` is structurally `?: never`, so no method is typed to
 * return a media provider API key.
 */
export interface HostMediaConfigLike {
  /** List a media type's providers (masked — no `config.apiKey`). */
  listProviders(mediaType: HostMediaType): Promise<HostMaskedMediaProvider[]>;
  /** Get one provider by id (masked, or `null` when absent). */
  getProvider(mediaType: HostMediaType, id: string): Promise<HostMaskedMediaProvider | null>;
  /**
   * Update a provider (model management rides `patch.models`/`modelGroups`;
   * default-model rides `patch.defaultModelId`). The patch carries NO secret —
   * `patch.apiKey` is `?: never` (v1.25); the key is written ONLY through
   * {@link HostMediaConfigLike.setProviderKey}. The returned envelope is masked.
   */
  updateProvider(
    mediaType: HostMediaType,
    id: string,
    patch: HostMediaProviderUpdate
  ): Promise<HostMediaProviderResult>;
  /** Enable/disable a provider; returns the masked envelope. */
  toggleProvider(
    mediaType: HostMediaType,
    id: string,
    enabled: boolean
  ): Promise<HostMediaProviderResult>;
  /** Create a custom provider (cloned from a base); returns the masked envelope. */
  createCustomProvider(
    mediaType: HostMediaType,
    input: HostMediaCustomProviderInput
  ): Promise<HostMediaProviderResult>;
  /** Delete a (custom) provider by id. */
  deleteProvider(mediaType: HostMediaType, id: string): Promise<HostMediaOpResult>;
  /** Get a media type's global settings (default provider/model/voice/concurrency/…). */
  getGlobalSettings(mediaType: HostMediaType): Promise<HostMediaGlobalSettings>;
  /** Set a media type's global settings (validated per `mediaType`). */
  setGlobalSettings(
    mediaType: HostMediaType,
    settings: HostMediaGlobalSettings
  ): Promise<HostMediaGlobalSettingsResult>;
  /** Refresh a provider's upstream model list (OpenRouter-backed types only). */
  refreshUpstreamModels(mediaType: HostMediaType, id: string): Promise<HostMediaModelRefreshResult>;
  /**
   * IMAGE-ONLY: reset a provider to its library defaults (the only media type
   * with a library reset). Returns the masked envelope.
   */
  resetProviderToDefaults(id: string): Promise<HostMediaProviderResult>;
  /**
   * Write (or clear) a provider's API key (host-API v1.25,
   * `byo-media-secret-hardening`). The ONLY way to set the key — it routes
   * through `host.services.secretsWrite` under the per-type
   * `media-<type>:<id>:apiKey` ref (allowed by `isAllowedByoSecretRef`). An
   * empty/whitespace `apiKey` clears the stored secret (provider → unconfigured).
   * Returns `{ success, error? }` ONLY — never the key.
   */
  setProviderKey(
    mediaType: HostMediaType,
    id: string,
    apiKey: string
  ): Promise<HostMediaKeyWriteResult>;
  /**
   * Write a Seedance VOD BytePlus secret (host-API v1.49). Optional and
   * video-only: this is the smallest additive surface that lets the independent
   * VOD provider persist AK/SK without reopening the ordinary provider patch.
   */
  setProviderSecret?(
    mediaType: 'video',
    id: string,
    field: HostMediaProviderSecretField,
    value: string
  ): Promise<HostMediaKeyWriteResult>;
  /**
   * Reveal a provider's stored API key (host-API v1.50) — the ONE deliberate
   * outward exception to mask-on-return, for user-initiated display (the
   * settings eye icon). Secrets-first over the per-type
   * `media-<type>:<id>:apiKey` ref with a hydrated-config fallback (the legacy
   * DB column). No key stored → `{ success: true, value: '' }`.
   */
  revealProviderKey?(
    mediaType: HostMediaType,
    id: string
  ): Promise<HostMediaKeyRevealResult>;
  /**
   * Reveal a stored video secret field (`byteplusAk`/`byteplusSk`, host-API
   * v1.50) — the `setProviderSecret` read counterpart. Video-only; rejects
   * `'apiKey'` (use {@link HostMediaConfigLike.revealProviderKey}).
   */
  revealProviderSecret?(
    mediaType: 'video',
    id: string,
    field: HostMediaProviderSecretField
  ): Promise<HostMediaKeyRevealResult>;
}
