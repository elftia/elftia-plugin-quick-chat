/**
 * host-api/search-config.ts — `HostSearchConfigLike`, the `host.services.searchConfig`
 * capability port (`byo-port-search-config`, host-API v1.24, the FINAL P1 knife).
 *
 * Lets a Tier-1 main plugin (the future `byo-providers` plugin) configure the
 * API-KEY web-search providers — tavily / jina / zhipu (+ z.ai) / grok / searxng
 * (and exa / bocha) — WITHOUT the host owning any BYO web-search-config UI:
 * non-secret provider config, status reads, and a thin `setProviderKey` that
 * routes through the EXISTING guarded secret write (the `search-provider:` ref
 * already in `BYO_SECRET_NAMESPACE_PREFIXES`, NOT a second write port).
 *
 * The KEYLESS `local-*` providers (browser-automation, login-window managed),
 * search QUERY execution, and the login-window verbs are deliberately ABSENT —
 * they are host/execution-side, out of this config port's scope.
 *
 * ── NO-SEARCH-KEY-ON-RETURN INVARIANT (the security crux, design D4) ──
 * No method returns a provider API key. `getProviderConfig` returns the host's
 * already-masked config (`WebSearchService.getProviderConfig` strips the resolved
 * key), and the config return type here ({@link HostMaskedSearchProviderConfig})
 * types `apiKey` as `?: never` — a returned config that carried a populated
 * `apiKey` would FAIL to type-check (the structural half of the enforcement, so a
 * future adapter edit can't silently leak one). `setProviderKey` returns
 * `{ success, error? }` only; an inbound `apiKey` is consumed host-side and never
 * echoed.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports it.
 * No DOM type leaks in. Like the sibling BYO ports, the payload shapes are
 * STRUCTURAL LOWER BOUNDS (Node-shaped, no `@main`/`@shared` import) — the host's
 * canonical `WebSearchProviderConfig` (minus the masked `apiKey`) is structurally
 * assignable, and the plugin re-narrows what it reads.
 *
 * @module @elftia/plugin-types/host-api/search-config
 */

/**
 * The API-KEY web-search provider ids this config port targets. A structural
 * lower bound over the host's `WebSearchProviderId` keyed subset (the keyless
 * `local-*` ids are intentionally NOT modeled here — the port does not configure
 * them). Typed as a plain `string` at the contract boundary so the host's enum
 * stays the validation SSOT (the adapter Zod-validates with the SAME
 * `webSearchProviderIdSchema` the IPC handlers use); documented for intent.
 */
export type HostSearchProviderId = string;

/**
 * The NON-SECRET provider config the configure verbs accept and the reads
 * return. Carries `id` + `enabled` + the non-secret transport fields
 * (`apiHost` for searxng, HTTP basic-auth for searxng) and DELIBERATELY NO
 * `apiKey` (the corrected post-hygiene contract — `WebSearchService.configureProvider`
 * strips any inbound `apiKey` regardless). The key is written ONLY via
 * {@link HostSearchConfigLike.setProviderKey}.
 */
export interface HostSearchProviderConfigInput {
  /** Stable provider id (an API-key provider; validated against the host enum). */
  readonly id: HostSearchProviderId;
  /** Whether the provider is enabled. */
  readonly enabled: boolean;
  /** Non-secret API host (searxng's base URL). */
  readonly apiHost?: string;
  /** Non-secret HTTP basic-auth username (searxng). */
  readonly basicAuthUsername?: string;
  /** Non-secret HTTP basic-auth password (searxng). */
  readonly basicAuthPassword?: string;
}

/**
 * The MASKED config a read returns. Pins `apiKey` as `?: never` so it can NEVER
 * be populated on a return (a forgotten adapter strip fails to type-check — the
 * structural half of the no-key invariant). Non-secret fields (`id` / `enabled`
 * / `apiHost` / basic-auth) survive through the index signature.
 */
export interface HostMaskedSearchProviderConfig {
  /**
   * STRUCTURALLY ABSENT — the port never returns a search-provider API key.
   * Typed `?: never` (not merely omitted) so any returned config that carried a
   * populated `apiKey` is a COMPILE error at the adapter boundary.
   */
  readonly apiKey?: never;
  /** Remaining non-secret config fields are opaque (see the canonical config). */
  readonly [key: string]: unknown;
}

/** The supported-provider lists the `getProviders` read returns (the existing IPC payload). */
export interface HostSearchProvidersList {
  /** The API-key provider ids the host supports configuring. */
  readonly api: readonly string[];
  /** The keyless `local-*` provider ids (returned for parity; the plugin ignores them). */
  readonly local: readonly string[];
}

/** The `validate(providerId)` status result — a host-side test search; never a key. */
export interface HostSearchValidateResult {
  readonly valid: boolean;
  readonly error?: string;
}

/** The `setProviderKey` op result — status only; NEVER carries the key. */
export interface HostSearchKeyWriteResult {
  readonly success: boolean;
  readonly error?: string;
}

/**
 * `host.services.searchConfig` — the API-key web-search-provider config port.
 *
 * Every method Zod-validates its payload (≥ the corresponding `webSearch:*` IPC
 * handler, reusing the host's `providerConfigSchema` / `setProviderKeySchema` /
 * `webSearchProviderIdSchema`) before delegating to the host's EXISTING
 * `WebSearchService` (the masked shared service). No method returns a search key
 * (`getProviderConfig`'s `apiKey` is structurally `?: never`; `setProviderKey`
 * returns status only). The keyless `local-*` providers, `search` query
 * execution, and login-window verbs are NOT exposed.
 */
export interface HostSearchConfigLike {
  /**
   * Configure a single API-key provider. The `config` carries NO `apiKey` (the
   * corrected post-hygiene contract; the host strips any inbound key regardless
   * and resolves the real key from the secret store). The key write is
   * {@link setProviderKey}.
   */
  configureProvider(config: HostSearchProviderConfigInput): Promise<HostSearchKeyWriteResult>;
  /** Bulk-configure providers (each `config` carries no `apiKey`). */
  configureProviders(configs: readonly HostSearchProviderConfigInput[]): Promise<HostSearchKeyWriteResult>;
  /** List the supported API + keyless-local provider ids (the existing IPC payload). */
  getProviders(): Promise<HostSearchProvidersList>;
  /**
   * Get a provider's stored NON-SECRET config (`null` when unconfigured). The
   * key is stripped by `WebSearchService.getProviderConfig`; the return type
   * masks `apiKey` out structurally — no key crosses.
   */
  getProviderConfig(providerId: HostSearchProviderId): Promise<HostMaskedSearchProviderConfig | null>;
  /** Whether the provider is enabled (+ configured). */
  isProviderEnabled(providerId: HostSearchProviderId): Promise<boolean>;
  /** Validate a provider via a host-side 1-result test search; returns status only. */
  validate(providerId: HostSearchProviderId): Promise<HostSearchValidateResult>;
  /**
   * Store/clear a provider's API key, routed through the EXISTING guarded secret
   * write — `SecretsService.setSecret('search-provider:<id>:apiKey', apiKey)`
   * (empty/whitespace → `deleteSecret`) THEN reconfigure so the in-memory map +
   * Jina reader refresh. The same bundled op the `webSearch:setProviderKey` IPC
   * performs (a single shared fn — no fork). An inbound `apiKey` is consumed
   * host-side and NEVER echoed; returns `{ success, error? }` only.
   */
  setProviderKey(providerId: HostSearchProviderId, apiKey: string): Promise<HostSearchKeyWriteResult>;
}
