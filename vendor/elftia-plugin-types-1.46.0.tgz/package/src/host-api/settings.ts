/**
 * host-api/settings.ts — `AgentUiSettings`, the ADDITIVE v1.20 `host.settings`
 * member of `AgentUiHostApi`: a single REGISTER port that lets a plugin
 * contribute a SETTINGS SECTION (one nav entry + one panel) the HOST renders
 * inside its settings page.
 *
 * ROUTED MECHANISM. `registerSection(def)` routes to the host's canonical
 * settings-section registry (`registerSettingsSection` in
 * `@/shared/state/settingsSectionStore`, the renderer Zustand
 * self-registration store — the `agentPageStore`/`workspaceStore` precedent).
 * The host factory injects the calling plugin's `pluginId` and keys the entry
 * by the NAMESPACED id `plugin:<pluginId>:<sectionId>`, so a plugin can never
 * forge another plugin's section namespace. The settings page appends a
 * dynamic nav group AFTER its built-in groups and renders each section's
 * panel lazily inside the host's plugin error boundary.
 *
 * 窄端口 DISCIPLINE: exposes EXACTLY ONE member — `registerSection(def):
 * HostUnregister` — the `hello`/`workspace`/`sessionGroup`/`newChat`/
 * `sessionKinds` register precedent. Rendering, nav placement, lazy-mount, and
 * error isolation stay HOST-owned.
 *
 * DOM-PURITY INVARIANT: this module imports ONLY `./_shared` (`HostReactNode`
 * + `HostUnregister`). No `react` runtime dep, no `electron`/`node:*` type, no
 * renderer-source import. `render` is a component-shaped method whose return
 * is the lib-agnostic `HostReactNode` (the `WorkspaceDefinitionLike.render` /
 * `AgentPageDefinitionLike.render` precedent — the plugin builds the node via
 * `host.react`, no `react` dep in this package).
 *
 * @module @elftia/plugin-types/host-api/settings
 */
import type { HostReactNode, HostUnregister } from './_shared';

/**
 * Structural LOWER BOUND of the opaque context the host passes a section's
 * `render(ctx)`. Deliberately EMPTY in v1 (additively extensible): a plugin
 * reaches the host through the `host.react`/`host.ui`/`host.ipc` handles it
 * already holds from `activate` — no new capability surface leaks through ctx.
 */
export interface HostSettingsSectionContext {
  /** Reserved — members are added ADDITIVELY in future minors. */
  readonly [key: string]: unknown;
}

/**
 * Structural LOWER BOUND of a collapsible PARENT grouping for contributed
 * settings sections (@since 1.28, ADDITIVE). Sections sharing the same
 * `group.id` render under ONE collapsible parent nav item. The narrowest port
 * that renders a collapsible parent: `{ id, label }` REQUIRED, everything else
 * OPTIONAL — no capability, no host-namespacing (nav presentation only).
 */
export interface SettingsSectionGroupLike {
  /** Stable group id; sections sharing it render under one collapsible parent. REQUIRED. */
  readonly id: string;
  /** Parent nav label — a plugin-resolved string OR a thunk (plugin i18n; NEVER a renderer i18n key). REQUIRED. */
  readonly label: string | (() => string);
  /** Optional parent nav icon node (built via `host.react`). */
  readonly icon?: HostReactNode;
  /** Optional inter-group sort order (ascending). Drives the group's slot within its placement block; absent ⇒ 0. */
  readonly order?: number;
  /** Optional initial expand state for the collapsible parent. Absent ⇒ expanded (host default). */
  readonly defaultExpanded?: boolean;
  /** Remaining members are opaque — additively extensible. */
  readonly [key: string]: unknown;
}

/**
 * Structural LOWER BOUND of a contributed settings section: ONE nav entry +
 * ONE panel (the same granularity as the host's built-in settings tabs). The
 * host stores it under the namespaced id `plugin:<pluginId>:<sectionId>`
 * (pluginId host-injected) and keeps everything else opaque.
 */
export interface SettingsSectionDefinitionLike {
  /** Section-local id (namespaced by the host with the plugin id). REQUIRED. */
  readonly id: string;
  /**
   * Nav label — a plugin-resolved string OR a thunk the host re-evaluates per
   * render (so a label backed by `host.i18n.registerNamespace` follows locale
   * changes). NEVER a renderer i18n key. REQUIRED.
   */
  readonly label: string | (() => string);
  /** Optional nav icon node (built via `host.react`). */
  readonly icon?: HostReactNode;
  /** Optional sort order (ascending; registration order breaks ties). */
  readonly order?: number;
  /**
   * Optional collapsible-parent grouping (@since 1.28, ADDITIVE). Sections
   * sharing the SAME `group.id` render under ONE collapsible parent positioned
   * by `group.order`. Absent ⇒ the section stays FLAT (the unchanged
   * appended-last behavior). The per-section `order` continues to govern the
   * section's slot WITHIN its parent.
   */
  readonly group?: SettingsSectionGroupLike;
  /**
   * Optional top-pinning (@since 1.28, ADDITIVE). When truthy, this section —
   * or, if it is grouped, the collapsible parent its `group` produces — renders
   * in the TOP block ABOVE the host's built-in nav groups, ordered with the
   * other pinned plugin items by the unified key (`group.order` for groups,
   * `order` for flats). Absent/false ⇒ LEGACY appended-last placement (the
   * v1.20 behavior — no regression for un-pinned contributors). A group is
   * top-pinned iff ANY of its member sections sets `pinToTop`.
   */
  readonly pinToTop?: boolean;
  /**
   * Optional profile placement (@since 1.33, ADDITIVE). When truthy, the host
   * renders this section's panel EXCLUSIVELY inside its "personal info" / account
   * hub (the `PersonalInfoTab`) and OMITS it from the standalone settings-page
   * nav — the section appears in the account hub ONLY, not as its own settings
   * tab. The SAME `render(ctx)` closure is mounted there (inside the host plugin
   * error boundary), so the panel keeps the plugin's own scoped `host` — a core
   * component never reaches the plugin's IPC directly. Absent/false ⇒ the
   * section appears ONLY in the settings page (the v1.20 behavior — no
   * regression). Account-shaped sections (sign-in, membership, wallet) set this
   * so the account hub presents them together instead of scattering them across
   * standalone settings tabs. NAV PRESENTATION ONLY: it adds NO capability and
   * crosses NO host service.
   */
  readonly showInProfile?: boolean;
  /**
   * Render the section's panel body. The host mounts it lazily (first visit)
   * inside its plugin error boundary; `ctx` is an opaque extensible context
   * object ({@link HostSettingsSectionContext}). REQUIRED.
   */
  render(ctx: HostSettingsSectionContext): HostReactNode;
  /** Remaining members are opaque — additively extensible. */
  readonly [key: string]: unknown;
}

/**
 * `host.settings` — register a settings section the HOST renders in its
 * settings page. The single registration verb; nav placement + panel mount
 * lifecycle stay host-owned.
 *
 * @stability frozen (the BACKING `settingsSectionStore` registry is the contract)
 */
export interface AgentUiSettings {
  /**
   * Register a settings section (nav entry + panel).
   * @remarks ADDITIVE v1.20 (MINOR). Routes to
   *   `registerSettingsSection(pluginId, def)` (the host
   *   `settingsSectionStore`); the host injects `pluginId` and keys the entry
   *   `plugin:<pluginId>:<sectionId>` (re-registering the same key replaces
   *   the prior entry). The returned unregister is leak-safe and
   *   owner-scope-tracked, so disabling the plugin revokes the section live.
   */
  registerSection(def: SettingsSectionDefinitionLike): HostUnregister;
}
