/**
 * host-api/secrets-pack.ts — `HostSecretsPackLike`, the `host.services.secretsPack`
 * capability port (`byo-host-secrets-pack-port`, host-API v1.27).
 *
 * Lets a Tier-1 main plugin (the `byo-providers` plugin) drive the ENCRYPTED
 * credential MIGRATION PACK — the `.epack` export/import a user runs to move
 * provider keys + multi-key pool keys + subscription tokens between machines —
 * WITHOUT the host owning that UI. Mirrors the `secretsPack:*` IPC the host
 * settings credentials area uses (`export({passphrase})` / `import({passphrase})`).
 *
 * ── PASSPHRASE-IN, COUNTS/PATH-OUT INVARIANT (design D2 — the security crux) ──
 * The plugin sends ONLY a passphrase string IN and receives ONLY status/counts/
 * path OUT. EVERYTHING ELSE stays host-side, and NOTHING here is even TYPEABLE to
 * carry a secret:
 *   1. The encrypted `.epack` blob is written/read by the HOST; its bytes never
 *      enter the plugin (no method returns or accepts the blob).
 *   2. The destination (export) / source (import) file is PICKED HOST-SIDE via the
 *      native save/open dialog; the plugin does not choose or see the path beyond
 *      the returned `path` STRING (a location label, not secret material).
 *   3. The HOST encrypts/decrypts (`SecretsPackCodec`) and ingests; the plaintext
 *      keys/tokens never cross.
 *   4. `HostSecretsPackImportCounts` has NO key/token field (counts + a `skipped`
 *      name list only); `export` returns a `path` + status; the `passphrase` is
 *      never echoed. No plaintext key, token, blob, or passphrase is typeable in
 *      any RETURN.
 * This is architecturally identical to the host renderer's OWN posture (the
 * `@elftia/shared/contracts/api/secretsPack` contract: "plaintext secrets and the
 * passphrase never round-trip") — the plugin inherits the SAME boundary the host
 * renderer already has, so no new exposure is created. The port is gated by the
 * NEW `host:secrets-pack` token, DISTINCT from `host:secrets-write` (the per-ref
 * plaintext write port) — this is encrypted bulk-migration, a different capability.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports it.
 * Both members use `string`/structural records only — no DOM/Node type leaks in.
 *
 * @module @elftia/plugin-types/host-api/secrets-pack
 */

/** The passphrase-only argument shared by `export` and `import`. */
export interface HostSecretsPackArgs {
  /**
   * The passphrase the host uses to encrypt (export) / decrypt (import) the
   * `.epack`. Carried INWARD only — the host never echoes it back; it appears in
   * NO return type.
   */
  readonly passphrase: string;
}

/**
 * The COUNTS-ONLY tally an `import` returns — never any secret material. Mirrors
 * the host `SecretsPackImportCounts` contract: how many of each credential kind
 * were applied, a duplicate count, and the names that had no destination match.
 * NO field carries a key, token, or passphrase.
 */
export interface HostSecretsPackImportCounts {
  /** Provider single/coding-plan keys applied. */
  readonly providerKeys: number;
  /** Multi-key pool keys applied. */
  readonly poolKeys: number;
  /** Subscription token sets applied. */
  readonly tokenSets: number;
  /** Media-generation provider keys applied (image/video/music/tts/asr). */
  readonly mediaKeys: number;
  /** Web-search provider keys applied (tavily/jina/…). */
  readonly searchKeys: number;
  /** Pool keys skipped because an identical key already existed (idempotent re-import). */
  readonly duplicatePoolKeys: number;
  /** Provider names from the pack with no destination match (reported, not mis-applied). */
  readonly skipped: readonly string[];
}

/**
 * The result of an `export` — status + the saved PATH only (a location label,
 * never the encrypted blob and never a secret).
 */
export interface HostSecretsPackExportResult {
  /** Whether the export succeeded. */
  readonly success: boolean;
  /** Absolute path of the written `.epack` on success (a location, not secret material). */
  readonly path?: string;
  /** True when the user dismissed the native save dialog. */
  readonly canceled?: boolean;
  /** Outcome message (e.g. a validation/IO error) — never plaintext. */
  readonly message?: string;
}

/**
 * The result of an `import` — status + the COUNTS only (never any secret).
 */
export interface HostSecretsPackImportResult {
  /** Whether the import succeeded. */
  readonly success: boolean;
  /** The applied counts on success (counts only — no key/token field). */
  readonly imported?: HostSecretsPackImportCounts;
  /** True when the user dismissed the native open dialog. */
  readonly canceled?: boolean;
  /** Outcome message (e.g. "wrong passphrase or corrupted pack") — never plaintext. */
  readonly message?: string;
}

/**
 * `host.services.secretsPack` — the encrypted credential migration-pack port.
 *
 * Both methods are PASSPHRASE-IN, COUNTS/PATH/STATUS-OUT: the host runs the
 * native save/open dialog, performs ALL encryption/decryption, writes/reads the
 * `.epack`, and ingests entirely main-side. NO method returns a plaintext secret,
 * the encrypted blob, or the passphrase. Delegates to the SAME body the host
 * `secretsPack:*` IPC uses (no fork). Gated by `host:secrets-pack` (distinct from
 * `host:secrets-write`).
 */
export interface HostSecretsPackLike {
  /**
   * Export an encrypted pack of this machine's provider/pool keys + subscription
   * tokens. The host collects + seals host-side, runs the native SAVE dialog,
   * writes the `.epack`, and returns `{ success, path?, canceled?, message? }`.
   * The plugin passes ONLY the passphrase; the blob + plaintext never cross.
   */
  export(args: HostSecretsPackArgs): Promise<HostSecretsPackExportResult>;
  /**
   * Import an encrypted pack. The host runs the native OPEN dialog, reads +
   * decrypts + validates + ingests host-side, and returns `{ success, imported?:
   * counts, canceled?, message? }`. The plugin passes ONLY the passphrase; the
   * blob + plaintext + the applied keys never cross.
   */
  import(args: HostSecretsPackArgs): Promise<HostSecretsPackImportResult>;
}
