/**
 * host-api/project-planning.ts — `AgentUiProjectPlanning`, the ADDITIVE v1.41
 * `host.projectPlanning` member of `AgentUiHostApi`: the contribution point
 * through which a Tier-1 plugin owns the planning-space area of a Project's
 * settings surface.
 *
 * TWO HALVES, and both are load-bearing (`rasen-single-plugin` Milestone 6, D2):
 *
 *   - `registerSection(def)` — the REGISTRATION verb, routed to the host's
 *     canonical `projectPlanningSectionStore` (the `settingsSectionStore`
 *     shape: entries keyed `plugin:<pluginId>:<sectionId>` with `pluginId`
 *     HOST-injected, so a plugin cannot forge another plugin's namespace).
 *   - `getStatus` / `setEnabled` — a NARROW Project port. The plugin's scoped
 *     IPC (`host.ipc.invoke`) routes ONLY to methods the plugin itself
 *     registered main-side, so it can never reach the host's Project channel,
 *     and a planning panel that cannot read the Project's planning status is
 *     not a panel. Granting the plugin the whole `projects:*` namespace to
 *     serve one consumer would widen a host-owned surface to every capability
 *     holder; this port forwards to exactly the three Project planning
 *     operations and returns the host's status shape verbatim.
 *
 * 窄端口 DISCIPLINE: EXACTLY three verbs. No Project create/update/delete, no
 * member or session operation, no store handle. Rendering, ordering and mount
 * lifecycle stay HOST-owned.
 *
 * DOM-PURITY INVARIANT: this module imports ONLY `./_shared` (`HostReactNode` +
 * `HostUnregister`). No `react` runtime dep, no `electron`/`node:*` type, no
 * renderer-source import. `render` is a component-shaped method whose return is
 * the lib-agnostic `HostReactNode` (the `SettingsSectionDefinitionLike.render`
 * precedent — the plugin builds the node via `host.react`).
 *
 * @module @elftia/plugin-types/host-api/project-planning
 */
import type { HostReactNode, HostUnregister } from './_shared';

/**
 * The context a registered planning section's `render(ctx)` receives.
 *
 * CARRIES ONLY THE PROJECT ID, deliberately (design D3). The host's Project
 * settings panel does not fetch planning status at all — the section reads it
 * itself through {@link AgentUiProjectPlanning.getStatus}, so there is ONE
 * reader and ONE cache rather than a host copy the section can drift from. It
 * also means the host holds no planning knowledge to leak through the context.
 * Additively extensible.
 */
export interface ProjectPlanningPanelContext {
  /** The Project whose settings surface is rendering this section. REQUIRED. */
  readonly projectId: string;
  /** Remaining members are opaque — additively extensible in future minors. */
  readonly [key: string]: unknown;
}

/**
 * Structural LOWER BOUND of a contributed planning section: ONE panel rendered
 * inside a Project's settings surface. The host stores it under the namespaced
 * id `plugin:<pluginId>:<sectionId>` (pluginId host-injected) and keeps
 * everything else opaque.
 */
export interface ProjectPlanningSectionDefinitionLike {
  /** Section-local id (namespaced by the host with the plugin id). REQUIRED. */
  readonly id: string;
  /**
   * Section label — a plugin-resolved string OR a thunk the host re-evaluates
   * per render (so a label backed by `host.i18n.registerNamespace` follows
   * locale changes). NEVER a renderer i18n key. REQUIRED.
   */
  readonly label: string | (() => string);
  /** Optional section icon node (built via `host.react`). */
  readonly icon?: HostReactNode;
  /** Optional sort order (ascending; registration order breaks ties). */
  readonly order?: number;
  /**
   * Render the section's body for one Project. The host mounts it inside its
   * plugin error boundary. REQUIRED.
   */
  render(ctx: ProjectPlanningPanelContext): HostReactNode;
  /** Remaining members are opaque — additively extensible. */
  readonly [key: string]: unknown;
}

/**
 * Structural mirror of ONE host planning-space diagnostic.
 *
 * `severity` is deliberately a plain `string` rather than a closed union: the
 * host's vocabulary is host-owned and MAY grow, and — per the milestone's
 * render rule — severity governs PRESENTATION only. A section must render every
 * diagnostic at every severity, so an unrecognised severity degrades to default
 * styling rather than to invisibility.
 */
export interface HostPlanningDiagnosticLike {
  /** Stable diagnostic code (styling / test anchor; never parsed for control flow). */
  readonly severity: string;
  /** Machine-readable code. */
  readonly code: string;
  /** Human-readable message the section renders. */
  readonly message: string;
  /** Optional target the diagnostic refers to. */
  readonly target?: string;
  /** Optional actionable remediation line. */
  readonly fix?: string;
  /** Remaining members are opaque — additively extensible. */
  readonly [key: string]: unknown;
}

/**
 * Structural mirror of the host's Project planning status, returned VERBATIM by
 * both port verbs (no re-shaping, no schema drift — the host owns this shape and
 * this package only describes it).
 *
 * IMPORTANT for a consumer: `enabled` describes the PROJECT's binding, not the
 * plugin's reachability. A bound logical Project reports `enabled: true` even
 * while the workflow provider is unreachable, with the unreachability riding
 * along as a low-severity diagnostic. Treating `enabled` as "everything is
 * fine" renders a control whose first click throws — ask the plugin's own
 * availability instead.
 */
export interface HostProjectPlanningStatusLike {
  /** Whether a planning space is bound for this Project. */
  readonly enabled: boolean;
  /**
   * The registered store id, for the logical-Project case. A LOWER BOUND, so it
   * is optional-and-nullable: the host's own shape declares it nullable, and a
   * structural mirror that demanded the field would refuse a host whose contract
   * is merely compatible.
   */
  readonly storeId?: string | null;
  /** The resolved planning root path; absent/null until one resolves. */
  readonly root?: string | null;
  /** The flattened doctor health. MAY be empty; never absent. */
  readonly diagnostics: readonly HostPlanningDiagnosticLike[];
  /** Remaining members are opaque — additively extensible. */
  readonly [key: string]: unknown;
}

/**
 * `host.projectPlanning` — contribute the planning-space area of a Project's
 * settings surface, and read/toggle that Project's planning space.
 *
 * @stability frozen (the BACKING `projectPlanningSectionStore` registry and the
 *   host's Project planning operations are the contract)
 */
export interface AgentUiProjectPlanning {
  /**
   * Register a planning section rendered inside a Project's settings surface.
   * @remarks ADDITIVE v1.41 (MINOR). Routes to
   *   `registerProjectPlanningSection(pluginId, def)` (the host
   *   `projectPlanningSectionStore`); the host injects `pluginId` and keys the
   *   entry `plugin:<pluginId>:<sectionId>` (re-registering the same key
   *   replaces the prior entry). The returned unregister is leak-safe and
   *   owner-scope-tracked, so disabling the plugin revokes the section live.
   */
  registerSection(def: ProjectPlanningSectionDefinitionLike): HostUnregister;
  /**
   * Read one Project's planning status. Forwards to the host's Project
   * planning-status operation and returns its result unmodified.
   */
  getStatus(projectId: string): Promise<HostProjectPlanningStatusLike>;
  /**
   * Enable or disable one Project's planning space. Forwards to the host's
   * Project enable/disable operation (idempotent host-side) and returns the
   * resulting status unmodified.
   */
  setEnabled(projectId: string, next: boolean): Promise<HostProjectPlanningStatusLike>;
}
