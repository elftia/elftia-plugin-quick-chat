/**
 * host-api/_shared.ts — the lib-agnostic structural primitives shared between
 * the frozen renderer surface (`../renderer.ts`) and the additive v1.1 sibling
 * modules (`./sessionGroup`, `./stores`, `./platform-ipc`).
 *
 * These three primitives (`HostReactNode`, `HostComponentType`, `HostUnregister`)
 * were ORIGINALLY defined inline in `renderer.ts`. They are extracted here so
 * the new sibling modules can reference them WITHOUT importing `renderer.ts`
 * (which itself imports the siblings) — breaking the would-be import cycle
 * (Decision D6). `renderer.ts` re-exports all three, so its public exports stay
 * byte-unchanged.
 *
 * DOM-PURITY INVARIANT (Decision D2): this module — like every `host-api/*`
 * module — references NO `electron` / `WebContents` / `node:*` type and has NO
 * `react` runtime dependency. The shapes are purely structural; React's concrete
 * types are reached at the consuming app's type-check time, never imported here.
 *
 * @module @elftia/plugin-types/host-api/_shared
 */

/**
 * A React element / node, declared structurally so this package needs no
 * `react` runtime dependency. The concrete type is React's `ReactNode`.
 *
 * Kept intentionally loose (`unknown`) — the plugin produces nodes via
 * `host.react` (whose `createElement` returns the real `ReactElement`); the
 * host only needs to accept "whatever React produces" without this package
 * importing React's types into its public surface.
 */
export type HostReactNode = unknown;

/** A React component type, declared structurally (no `react` dependency). */
export type HostComponentType<P> = (props: P) => HostReactNode;

/** Unregister a previously-registered definition (HMR/teardown; usually ignored). */
export type HostUnregister = () => void;

/**
 * v1.19 — structural lower bound of a chat session's `settings` blob, shared by
 * the main-surface `HostChatSessionLike` (`../backend.ts`) and the renderer
 * `HostChatSessionRef` (`./stores.ts`). Lives HERE (lib-agnostic, like the
 * three primitives above) because those two modules never import each other.
 *
 * Pins ONLY `designConfig` (the opaque blob `HostChatSessionRef` already pinned
 * at top level). Deliberately NO index signature: the host canonical
 * `ChatSessionSettings` is an `interface` (no implicit index signature), so an
 * indexed bound here would break host assignability. Canonical:
 * `ChatSessionSettings` (`@shared/chat-types`).
 */
export interface HostChatSessionSettingsLike {
  /** Plugin-opaque design config blob. */
  readonly designConfig?: unknown;
}
