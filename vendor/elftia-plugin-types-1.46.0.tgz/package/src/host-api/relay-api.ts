/**
 * host-api/relay-api.ts — `HostRelayApiLike`, the generic host-guarded
 * authed-fetch `host.services.relayApi` capability port (`oss-channel-isolation`
 * Phase 3 slice P3-3a, host-API v1.29).
 *
 * HOST-GUARDED AUTHED FETCH BY CONSTRUCTION (the security crux): the ONLY
 * operation is `fetch(path, init): Promise<HostRelayFetchResult>`. The HOST
 * injects the bearer access token + the elftia-web base URL and REJECTS any
 * `path` outside the allowlist BEFORE any network call. The plugin passes ONLY a
 * host-relative `path` + non-auth headers/method/body and receives ONLY
 * `{ status, ok, body }` (raw response text — the plugin parses JSON itself). The
 * bearer token NEVER crosses to the plugin (it can neither read nor override the
 * `Authorization` header — the host strips any plugin-supplied one and sets its
 * own last), and the plugin can only reach allowlisted paths.
 *
 * WHY (P3 context): the channel-gated Steam plugin's MAIN half (loaded
 * in-process) must call elftia-web `/api/v1/points/*` with the user's bearer —
 * but a plugin can neither import core internals nor read the session token. This
 * narrow port is the seam: a single authed-fetch verb, host-owned token + base +
 * path allowlist. P3-3b consumes it (this slice adds the dormant seam only).
 *
 * NARROW-PORT MINIMALITY (窄端口): EXACTLY one verb, lib-agnostic by
 * construction — plain `string` / `number` / `boolean` / record shapes only. NO
 * DOM `Response`/`Headers`/`Request`, NO Node type, NO streaming/abort/redirect
 * knob. The plugin pre-serializes its JSON body and parses the raw text result.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports it
 * (via `backend-services.ts`). Every member uses plain strings/records only — no
 * DOM/Node type leaks in.
 *
 * @module @elftia/plugin-types/host-api/relay-api
 */

/**
 * Request init for {@link HostRelayApiLike.fetch}. The plugin supplies a method,
 * non-auth headers, and a pre-serialized JSON body — the HOST owns
 * `Authorization` (it strips any plugin-supplied `authorization`/`Authorization`
 * and sets its own last; a plugin can neither read nor override the bearer).
 */
export interface HostRelayFetchInit {
  /** HTTP method (default `'GET'`). */
  readonly method?: string;
  /**
   * Plugin-supplied NON-AUTH headers. The host OWNS `Authorization` — any
   * `authorization`/`Authorization` key here is STRIPPED by the host before it
   * injects the bearer (the plugin can never set or read the token).
   */
  readonly headers?: Readonly<Record<string, string>>;
  /** Pre-serialized request body (e.g. a JSON string). */
  readonly body?: string;
}

/**
 * Result of {@link HostRelayApiLike.fetch}. The raw response TEXT + status only —
 * the plugin parses JSON itself. NO response auth/set-cookie header is echoed.
 */
export interface HostRelayFetchResult {
  /** HTTP status code. */
  readonly status: number;
  /** `true` iff the status is in the 2xx range (mirrors `Response.ok`). */
  readonly ok: boolean;
  /** Raw response text (the plugin parses JSON itself). */
  readonly body: string;
}

/**
 * `host.services.relayApi` — the generic host-guarded authed-fetch port. Exactly
 * one member; backed by the host's AuthSessionService bearer + the elftia-web
 * api base + a path allowlist.
 */
export interface HostRelayApiLike {
  /**
   * Authed fetch to the elftia-web API. The HOST injects the bearer + base URL
   * and REJECTS any path outside the allowlist; the plugin never sees the token.
   * `path` MUST be a host-relative path (e.g. `'/api/v1/points/balance'`) — an
   * absolute URL, a protocol-relative `//host`, a `..` traversal, or a
   * non-allowlisted path is rejected BEFORE any network call. Resolves
   * `{ status, ok, body }`; rejects (without fetching) when no bearer is
   * available or the path is disallowed.
   */
  fetch(path: string, init?: HostRelayFetchInit): Promise<HostRelayFetchResult>;
}
