/**
 * host-api/managed-runtime.ts — `HostManagedRuntimeLike`, the NARROW
 * read-only managed-runtime path-resolution `host.services.managedRuntime`
 * capability port (`creative-library-managed-consumption`, host-API v1.43).
 *
 * WHY: Phase 2 of the unified creative-library preps a host-managed runtime
 * directory (the seeder installs dependencies into
 * `<ELFTIA_HOME>/runtime/managed/<id>/`), but the plugin-side render wrappers
 * had no way to discover that path. This port closes the gap: the plugin
 * passes an id string and receives the absolute path to the prepped dir (or
 * `null` when absent / not-yet-prepped), so the plugin can point its renderer
 * at the host-managed runtime instead of bundling its own.
 *
 * NARROW-PORT MINIMALITY (窄端口): EXACTLY one read verb — `resolvePreparedDir
 * (id)` — returning a `string | null`. NO write/create/delete/update verb —
 * the host owns the runtime directory lifecycle (seeding, updates, cleanup);
 * the plugin only reads the path. No host service object crosses; no IPC
 * channel name crosses; no file handle crosses. The plugin performs its own
 * `node:fs` reads against the resolved directory (the `storage.dataDir()`
 * path-grant precedent — a wrapping file API would add surface without adding
 * a boundary, because main-half plugins run in-process with full Node).
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module. It MUST NOT be
 * imported by `renderer.ts`; only `backend.ts` imports it (via
 * `backend-services.ts`). The module imports nothing (plain `string` type
 * only) — no DOM/Node type leaks in.
 *
 * @module @elftia/plugin-types/host-api/managed-runtime
 */

/**
 * `host.services.managedRuntime` — the NARROW read-only managed-runtime
 * path-resolution port (v1.43). Lets any MAIN plugin (e.g. the html-video
 * render wrappers) resolve the host-managed runtime directory the seeder has
 * prepped for a given id, instead of each plugin guessing or bundling its own.
 *
 * EXACTLY one verb: `resolvePreparedDir(id)` (absolute path to the prepped
 * dir, or `null` when absent / not-yet-prepped). READ-ONLY — no write/create/
 * delete verb. The host owns the runtime directory lifecycle; the plugin only
 * reads the path and then performs its own `node:fs` I/O against it.
 *
 * @stability additive (MINOR, v1.43) — frozen once published; evolution follows
 *   the `version.ts` freeze checklist. Absent on a build that does not wire the
 *   `ManagedRuntimePathService` singleton (the plugin `activate` guards — the
 *   optional-dep pattern).
 */
export interface HostManagedRuntimeLike {
  /**
   * Resolve the absolute path to the prepped managed-runtime dir for `id`
   * (e.g. `'creative-library'`), or `null` when the dir is absent or does not
   * appear prepped (no `node_modules/` subdirectory — the generic prep
   * indicator). READ-ONLY — no write. The plugin performs its own `node:fs`
   * reads against the returned path.
   */
  resolvePreparedDir(id: string): string | null;
}
