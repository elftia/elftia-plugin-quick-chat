/**
 * host-api/creative-library.ts — `HostCreativeLibraryLike`, the NARROW
 * read-only creative-library enumerate + fetch `host.services.creativeLibrary`
 * capability port (`unified-creative-library-phase2`, host-API v1.42).
 *
 * WHY: Phase 2 of the unified creative-library lets any MAIN plugin list +
 * fetch shared prompt-template content (image-prompt + video-prompt) from the
 * HOST's bundled roots via a READ-ONLY API, eliminating duplication (the 18
 * HyperFrames video templates were duplicated byte-identically across host and
 * producer repos).
 *
 * NARROW-PORT MINIMALITY (窄端口): EXACTLY two read verbs — `list(scope?)`
 * (enumerate items, optionally filtered by scope) and `get(id)` (fetch ONE item
 * by id). NO write/create/delete/update verb — the host owns the bundled roots
 * and the curation; the plugin only reads. No host service object crosses; no
 * file paths cross; no IPC channel names cross.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module. It MUST NOT be
 * imported by `renderer.ts`; only `backend.ts` imports it (via
 * `backend-services.ts`). Every member uses plain `string` / `readonly` /
 * `Promise` shapes only — no DOM/Node type leaks in.
 *
 * @module @elftia/plugin-types/host-api/creative-library
 */

/**
 * The creative-library content scope. Each scope maps to a host-side content
 * root: `image-prompt` from `prompt-templates/image/` JSON files,
 * `video-prompt` from `prompt-templates/video/` JSON files.
 */
export type CreativeLibraryScope = 'image-prompt' | 'video-prompt';

/**
 * One creative-library item — the unified shape BOTH DS and Video Studio
 * consume. This is a SUPERSET of the existing `CommunityTemplateSummary` that
 * preserves `category`, `aspect`, `previewImageUrl`, `previewVideoUrl`, `tags`,
 * and `source` from the raw JSON (fields that were lost when projecting through
 * `CommunityTemplateSummary`).
 */
export interface CreativeLibraryItem {
  /** Stable id (derived from the template's `id` field). */
  readonly id: string;
  /** The content scope this item belongs to. */
  readonly scope: CreativeLibraryScope;
  /** Display title. */
  readonly title: string;
  /** Short description, or `null` when the source manifest omits it. */
  readonly summary: string | null;
  /** Gallery category tag, or `null`. */
  readonly category: string | null;
  /** Search/filter tags. */
  readonly tags: readonly string[];
  /** Aspect ratio hint (e.g. `'16:9'`), or `null`. */
  readonly aspect: string | null;
  /** Static preview image URL (the gallery fetches separately), or `null`. */
  readonly previewImageUrl: string | null;
  /** Video preview URL (the gallery fetches separately), or `null`. */
  readonly previewVideoUrl: string | null;
  /** The prompt text. */
  readonly prompt: string;
  /** Optional attribution / provenance. */
  readonly source?: {
    readonly author?: string;
    readonly repo?: string;
    readonly license?: string;
    readonly url?: string;
  };
}

/**
 * `host.services.creativeLibrary` — the NARROW read-only creative-library
 * enumerate + fetch port (v1.42). Lets any MAIN plugin (DS, Video Studio) list
 * + fetch shared prompt-template content from the HOST's bundled roots, instead
 * of each plugin bundling its own copy.
 *
 * EXACTLY two verbs: `list(scope?)` (enumerate items, optionally filtered by
 * scope) + `get(id)` (fetch ONE item by id). READ-ONLY — no write/create/
 * delete verb. The host owns the bundled roots and the curation; the plugin
 * only reads.
 *
 * @stability additive (MINOR, v1.42) — frozen once published; evolution follows
 *   the `version.ts` freeze checklist. Absent on a build that does not wire the
 *   `CreativeLibraryService` singleton (the plugin `activate` guards — the
 *   optional-dep pattern).
 */
export interface HostCreativeLibraryLike {
  /**
   * Enumerate creative-library items. When `scope` is omitted, returns ALL
   * scopes; when provided, returns only that scope's items.
   */
  list(input?: { scope?: CreativeLibraryScope }): Promise<readonly CreativeLibraryItem[]>;
  /**
   * Fetch ONE item by id. Returns `null` when unknown (the plugin guards).
   */
  get(id: string): Promise<CreativeLibraryItem | null>;
}
