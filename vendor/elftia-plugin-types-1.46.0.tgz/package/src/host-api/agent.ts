/**
 * host-api/agent.ts — `AgentUiHostAgent`, the ADDITIVE v1.2 `host.agent` member
 * of `AgentUiHostApi`: a NARROW typed port into the host agent IPC client
 * (`@/shared/agent`).
 *
 * 窄端口 DISCIPLINE: exposes EXACTLY the request/response operations the Design
 * Studio renderer audit recorded (`agent-ui-extensions-2/planning-context.md`
 * §F14) — `chatSessions.{list,create,update}`, `files.read`, and the
 * CLI-backend resolver — never the whole agent API. These are GENERAL
 * session/file/model-resolution operations DS reuses; they are DISTINCT from the
 * 39 `design:*` channels (which reach main via the scoped `host.ipc.invoke`).
 * The factory forwards each to the real `agent` client at a single cast
 * boundary; the underlying IPC is UNCHANGED.
 *
 * DOM-PURITY INVARIANT (Decision D2 / D6): structural shapes + `_shared`
 * primitives ONLY — no `electron` / `WebContents` / `node:*` type, no `react`
 * runtime dep. Payload/result types are structural lower bounds; the SSOT stays
 * `@elftia/shared` / the agent-client types — this package imports none of them.
 *
 * @module @elftia/plugin-types/host-api/agent
 */

/**
 * Structural lower bound of a chat session row the port returns. Pins only the
 * `id`; the rest stays opaque (the full `ChatSession` schema is renderer-owned).
 *
 * @remarks Canonical: `ChatSession` (`@/shared/agent` chat types). Named
 *   `HostAgentChatSessionRef` to avoid colliding with the main-surface
 *   `HostChatSessionLike` (`../backend.ts`) and the `host.stores`
 *   `HostChatSessionRef` (`./stores.ts`) in the barrel.
 */
export interface HostAgentChatSessionRef {
  readonly id: string;
  readonly [key: string]: unknown;
}

/**
 * Structural lower bound of `chatSessions.list` result (a paged session list).
 * Pins only `sessions`; the rest (cursor/total/…) stays opaque.
 *
 * @remarks Canonical: `ChatSessionPage` (`@/shared/agent`).
 */
export interface HostChatSessionPage {
  readonly sessions: readonly HostAgentChatSessionRef[];
  readonly [key: string]: unknown;
}

/** Structural lower bound of the `chatSessions.list` query (all fields optional). */
export interface HostChatSessionListQuery {
  limit?: number;
  [key: string]: unknown;
}

/** Structural lower bound of `chatSessions.create` input. */
export interface HostCreateChatSessionInput {
  [key: string]: unknown;
}

/** Structural lower bound of `chatSessions.update` input. */
export interface HostUpdateChatSessionInput {
  [key: string]: unknown;
}

/**
 * Structural lower bound of the `files.read` result. The real client returns
 * `{ path; content; mtime? }` (NOT a bare string) — DS reads `result.content`.
 * Pins `content` (the field DS consumes); `path`/`mtime` opaque-optional.
 *
 * @remarks Canonical: `AgentFilesApi.read` (`@/shared/agent` core types).
 */
export interface HostProjectFileRead {
  readonly content: string;
  readonly path?: string;
  readonly mtime?: number;
  readonly [key: string]: unknown;
}

/**
 * Structural lower bound of a resolved CLI backend descriptor.
 *
 * @remarks Canonical: `CodeCliBackend` (`@shared/contracts/code-cli-types`),
 *   resolved by `getCodeCliBackend` (`@/shared/hooks/code/useCodeCliProviders`).
 *   Opaque — the port only needs the host fn's return value passed through.
 */
export interface HostCodeCliBackend {
  readonly [key: string]: unknown;
}

/**
 * `host.agent` — the narrow agent-IPC port. Forwards to the real `@/shared/agent`
 * client (`agent.chatSessions.*` / `agent.files.read`) and `getCodeCliBackend`.
 *
 * @stability additive (MINOR) — a new op is MINOR; only audited ops are exposed
 *   (speculative surface rejected per 窄端口).
 */
export interface AgentUiHostAgent {
  /** General chat-session operations DS reuses (NOT the `design:*` channels). */
  chatSessions: {
    /** List recent chat sessions. Forwards `agent.chatSessions.list`. */
    list(query?: HostChatSessionListQuery): Promise<HostChatSessionPage>;
    /** Create a chat session. Forwards `agent.chatSessions.create`. */
    create(input: HostCreateChatSessionInput): Promise<HostAgentChatSessionRef>;
    /** Update a chat session. Forwards `agent.chatSessions.update`. */
    update(
      id: string,
      input: HostUpdateChatSessionInput,
    ): Promise<HostAgentChatSessionRef | null>;
  };
  /** Project file reads DS uses to seed the artifact preview. */
  files: {
    /** Read a project file. Forwards `agent.files.read` (`{ content, path?, mtime? }`). */
    read(projectId: string, filePath: string): Promise<HostProjectFileRead>;
  };
  /**
   * Resolve a CLI backend from a provider/model ref. Forwards `getCodeCliBackend`
   * (host-owned; transitively pulls model caches / CLI availability — kept a
   * forward op so the plugin does not drag that machinery into its chunk).
   */
  resolveCodeCliBackend(
    providerId: string | undefined,
    modelId: string | undefined,
  ): HostCodeCliBackend | null;
}
