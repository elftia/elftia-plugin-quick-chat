/**
 * host-api/new-chat.ts — `AgentUiNewChat` + the structural lower bounds for
 * `host.newChat.registerModality(def)` (an ADDITIVE v1.13 member of
 * `AgentUiHostApi`).
 *
 * The new-chat MODALITY registry generalizes the host's previously-hardcoded
 * "design modality" new-chat path into a generic, plugin-contributed port. A
 * plugin (or a transitional host-side bridge) registers a
 * `NewChatModalityDefinitionLike` keyed by the agent ids it applies to; the
 * host's generic new-chat surface resolves the active modality from the
 * registry and dispatches the draft lifecycle + submit through it, WITHOUT any
 * hardcoded knowledge of "design".
 *
 * This module freezes only the HANDLE + context shapes; the backing fn
 * (`registerNewChatModality`) is the contract, mirroring the
 * `hello`/`workspace`/`sessionGroup` precedent (Decision D3). The draft bag is
 * a deliberate opaque `Record<string, unknown>` seam (the same discipline as
 * `AgentHelloDraft`): the host treats modality draft state as opaque, flows it
 * verbatim into per-tab snapshots + the active hello entry's `ctx.draft`, and
 * each modality reads/writes only its own namespaced keys.
 *
 * DOM-PURITY INVARIANT (Decision D2): structural shapes + `_shared` primitives
 * ONLY — no `electron` / `WebContents` / `node:*` type, no `@elftia/shared` /
 * renderer-source import, no `react` runtime dep. The shapes are purely
 * structural; concrete host types are reached at the consuming app's
 * type-check time, never imported here.
 *
 * @module @elftia/plugin-types/host-api/new-chat
 */
import type { HostUnregister } from './_shared';

/**
 * The opaque per-tab new-chat modality draft bag. A loose record at the
 * contract boundary BY DESIGN: the host treats it as opaque draft state that
 * flows verbatim into per-tab snapshots + the active hello entry's `ctx.draft`,
 * while each modality reads/writes only its own namespaced keys. Mirrors the
 * renderer's `AgentHelloDraft` seam.
 */
export type HostNewChatDraft = Record<string, unknown>;

/**
 * Structural LOWER BOUND of the host's picked-agent value the modality hooks
 * read. Pins only the stable `id` (the registry key); the engine fields are
 * optional and the rest stays opaque (`[key: string]: unknown`) so this freeze
 * does not lock the renderer-owned `PickedAgent` shape into the package.
 *
 * @remarks Canonical source: `@elftia/shared` `PickedAgent` (host-private).
 */
export interface HostPickedAgentLike {
  /** Stable agent id (the modality's registry key). REQUIRED. */
  readonly id: string;
  /** The agent's engine type (e.g. `'chat'` / `'agent'` / `'api'`). */
  readonly engineType?: string;
  /** The agent's serialized engine config (opaque to this contract). */
  readonly engineConfig?: unknown;
  /** Remaining members are opaque — see source. */
  readonly [key: string]: unknown;
}

/**
 * Context passed to a modality's draft lifecycle hooks (`resetDraft` /
 * `applyPrefill`). Carries the picked agent (or `null`), the current draft
 * bag, and an optional handoff `prefill` payload the modality maps into a
 * draft patch.
 */
export interface HostNewChatDraftPatchContext {
  /** The currently-picked agent (or `null`). */
  readonly pickedAgent: HostPickedAgentLike | null;
  /** The current opaque modality draft bag. */
  readonly draft: HostNewChatDraft;
  /** Optional handoff prefill payload (modality-specific shape; opaque here). */
  readonly prefill?: unknown;
  /** Remaining members are opaque — see source. */
  readonly [key: string]: unknown;
}

/**
 * Context passed to a modality's `submit(ctx)` handler. Carries the resolved
 * common new-chat inputs (message, provider/model, project path, playground
 * flag), the opaque draft bag, and the two host actions a modality needs to
 * land the user in the created chat (`bindSessionToActiveTab` + `focusInput`).
 * Extensible (`[key: string]: unknown`) so the host MAY thread additional
 * fields additively without a contract bump.
 */
export interface HostNewChatSubmitContext {
  /** The picked agent driving the submit (the modality's registry key owner). */
  readonly pickedAgent: HostPickedAgentLike;
  /** The trimmed composer message. */
  readonly message: string;
  /** The selected LLM provider id (empty when not applicable). */
  readonly providerId: string;
  /** The selected model id (empty when not applicable). */
  readonly model: string;
  /** The selected project path (empty when playground / not applicable). */
  readonly projectPath: string;
  /** Whether the new-chat surface is in playground (no-folder) mode. */
  readonly isPlayground: boolean;
  /** The opaque modality draft bag at submit time. */
  readonly draft: HostNewChatDraft;
  /** Bind the created session to the active tab (or navigate if no tab). */
  readonly bindSessionToActiveTab: (sessionId: string, title: string) => void;
  /** Re-focus the composer input (the empty-message degradation path). */
  readonly focusInput: () => void;
  /** Remaining members are opaque / additively extensible — see source. */
  readonly [key: string]: unknown;
}

/**
 * Structural LOWER BOUND of a registered new-chat modality definition.
 *
 * Pins the REQUIRED identity members the real registry demands — a stable
 * `id`, the `agentIds` it applies to, and the `submit` handler — so a plugin
 * that omits any of them fails to compile (matching what
 * `registerNewChatModality` would reject). The draft lifecycle hooks are
 * OPTIONAL; everything else stays opaque (`[key: string]: unknown`).
 *
 * Mirrors the `AgentHelloDefinitionLike` / `SessionGroupDefinitionLike`
 * pattern.
 *
 * @remarks Canonical source:
 *   `renderer/src/shared/state/newChatModalityStore.ts`
 *   (`NewChatModalityDefinition`). Backed by `registerNewChatModality(def)`.
 * @stability frozen (identity members pinned; the BACKING fn is the contract)
 */
export interface NewChatModalityDefinitionLike {
  /** Stable modality id (e.g. `'design-studio'`). REQUIRED. */
  readonly id: string;
  /** Agent ids this modality is registered under (one def may own several). REQUIRED. */
  readonly agentIds: readonly string[];
  /**
   * When `true`, picking an agent backed by this modality defaults the
   * new-chat surface to playground (no-folder) mode (the host still shows the
   * folder selector so the user may switch). OPTIONAL.
   */
  readonly defaultsToPlayground?: boolean;
  /** Produce the modality's initial draft bag on a fresh tab / reset. OPTIONAL. */
  createInitialDraft?(): HostNewChatDraft;
  /**
   * Reset the modality's draft state (e.g. switching away from this agent).
   * Returns the next draft bag. OPTIONAL.
   */
  resetDraft?(ctx: HostNewChatDraftPatchContext): HostNewChatDraft;
  /**
   * Map a handoff prefill payload into a draft PATCH (merged into the current
   * draft bag). Returns `undefined` when there is nothing to apply. OPTIONAL.
   */
  applyPrefill?(ctx: HostNewChatDraftPatchContext): HostNewChatDraft | undefined;
  /**
   * Handle send/start for this modality. The host calls this before its
   * generic agent/chat/api fallback paths. REQUIRED.
   */
  submit(ctx: HostNewChatSubmitContext): void | Promise<void>;
  /** Remaining members are opaque — see source. */
  readonly [key: string]: unknown;
}

/**
 * The new-chat modality contribution handle (ADDITIVE v1.13 member of
 * `AgentUiHostApi`). The API EXPOSES registration; it does NOT redefine the
 * registry (Decision D3).
 *
 * @stability frozen
 */
export interface AgentUiNewChat {
  /**
   * Register a new-chat modality for the def's agent ids.
   * @remarks Routes to `registerNewChatModality(def)` →
   *   `useNewChatModalityRegistry.getState().register`
   *   (`renderer/src/shared/state/newChatModalityStore.ts`). Last-registration-
   *   wins per agent id; the returned unregister is leak-safe (a stale
   *   unregister never removes a newer def for the same id).
   */
  registerModality(def: NewChatModalityDefinitionLike): HostUnregister;
}
