/**
 * host-api/artifact-storage.ts — `host.services.artifactStorage`, the
 * Artifact layer's storage path-grant port (composition platform Phase 2,
 * design §13.1, Gate-0 C5).
 *
 * ---------------------------------------------------------------------------
 * WHY A SEPARATE PORT — THE LIFETIME SEAM (C5)
 * ---------------------------------------------------------------------------
 * `host.services.storage`'s `dataDir()` is a HYGIENE grant: uninstall deletes
 * `<userData>/plugin-data/<pluginId>/`. Artifacts live under the OPPOSITE
 * lifetime (user-ruled OQ#2, 2026-08-12, + design §13.3): artifact directories
 * are RETAINED on both disable and uninstall — a work product outlives the
 * plugin that made it. Two seams with opposite lifetimes must never be
 * conflated: artifact storage is FORBIDDEN under the uninstall-removed
 * `storage.dataDir()` tree (implementations use `<projectRoot>/.elftia/artifacts/…`
 * and `<AppPaths.dataRoot>/artifacts/…` roots instead). This port is therefore
 * a SIBLING of `storage`, not an extension of it.
 *
 * EXACTLY three verbs — one per directory-tree lifecycle owner:
 *   `payload/` Provider-canonical (retain) · `derived/` host-sweepable
 *   rebuildable cache (no persistence guarantee) · `exports/` user output
 *   (retain). A single `artifactDir()` root grant is deliberately ABSENT: it
 * would hand the provider the whole artifact root including the HOST-owned
 * `envelope.json` (§13.2's ownership line). The root stays ungranted;
 * `envelope.json` is unreachable through this port.
 *
 * Paths ONLY (the `storage` port's VSCode `storageUri` pattern): the port
 * returns directory paths and does NO I/O; the plugin performs its own
 * `node:fs` work in them. Hygiene-under-install-trust honesty carries over
 * verbatim — this is data hygiene, not a security boundary.
 *
 * Scope discipline: every verb takes the HOST-MINTED
 * {@link HostOpaqueArtifactLocator} — one grant can never name another
 * artifact's directory. Runtime (directory creation, sweeping, migration,
 * catalog integration) belongs to the storage slice (§13.1's closing
 * sentence); this module is the CONTRACT only.
 *
 * @module @elftia/plugin-types/host-api/artifact-storage
 */

import type { HostOpaqueArtifactLocator } from './artifacts';

/**
 * `host.services.artifactStorage` — locator-scoped artifact directory paths.
 *
 * 窄端口 justification, per member (freeze-checklist rule 2):
 * - `payloadDir` — the Provider-canonical payload location; without it a
 *   provider has nowhere to write its own artifact bytes.
 * - `derivedDir` — the rebuildable-cache location providers and surfaces
 *   regenerate thumbnails/previews into; granting it separately lets the host
 *   sweep it without negotiating with providers.
 * - `exportsDir` — the user-output location (`export` flows write here so
 *   re-exports and user-visible exports land in a retained, discoverable tree).
 * - NO `artifactDir()` root grant — see the module header (envelope.json stays
 *   host-owned and unreachable).
 * @remarks Canonical shape: design doc §13.1 (the locator type's canonical
 * source is `@elftia/shared` `contracts/artifact-composition.ts`
 * `OpaqueArtifactLocator`; restated here as {@link HostOpaqueArtifactLocator}).
 */
export interface HostArtifactStorageLike {
  /**
   * `<root>/artifacts/<safe-kind>/<artifact-id>/payload/` — RETAINED on
   * disable AND uninstall (OQ#2). Provider-canonical bytes live here.
   */
  payloadDir(locator: HostOpaqueArtifactLocator): Promise<string>;

  /**
   * `…/derived/` — rebuildable cache. The host may sweep it at any time; NO
   * persistence guarantee attaches to anything written here.
   */
  derivedDir(locator: HostOpaqueArtifactLocator): Promise<string>;

  /**
   * `…/exports/` — user output / export records. RETAINED on disable and
   * uninstall.
   */
  exportsDir(locator: HostOpaqueArtifactLocator): Promise<string>;
}
