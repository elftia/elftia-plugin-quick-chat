/**
 * host-api/workflow.ts — `HostWorkflowProvider`, the DEEP `host.workflow`
 * capability port a workflow provider registers through (`rasen-single-plugin`
 * Milestone 1, host-API v1.39).
 *
 * WHY: a "workflow" (today: rasen's spec-workflow) owns a whole tool surface —
 * which tools exist, their schemas, which are safe to auto-run, which toolset
 * they belong to, their legacy aliases — plus the operations behind them. Before
 * this port that surface was hardcoded across three unrelated HOST modules and
 * the operations were reachable only through a host-constructed service, so
 * nothing outside the host process could supply either. This port is the seam:
 * a provider PUBLISHES its surface as a wire-safe {@link HostWorkflowDescriptor}
 * and SERVES it through exactly one {@link HostWorkflowProvider.execute} entry
 * point, so the host never learns the provider's internal method surface.
 *
 * DEEP MODULE (the crux, and why this is not a thin passthrough): the interface
 * is THREE verbs, but the obligations below are part of the contract, not
 * decoration. A provider that type-checks yet violates them is non-conforming.
 * Read the per-verb JSDoc as specification.
 *
 * NARROW-PORT MINIMALITY (窄端口): EXACTLY three verbs and ONE registration
 * method. No per-operation host method, no host-visible provider internals, no
 * callback in the call context, no host service handle crossing inward.
 *
 * WIRE-SAFETY (D7 of the source plan — ext-host readiness): every value that
 * crosses this port is JSON round-trippable. The descriptor carries no function,
 * no Electron object and no live schema instance; the request `input` and the
 * response `data` are opaque JSON; the call context carries only host-owned
 * identity/selector strings. Nothing here assumes the provider shares a process
 * with the host, so the same contract serves the in-process path today and a
 * wire-proxied extension host later WITHOUT a shape change.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module. It MUST NOT be
 * imported by `renderer.ts`; only `backend.ts` imports it. Every field is a
 * plain `string` / `number` / `boolean` / `unknown` — no DOM type, no
 * `electron`/Node type, no `@main`/`@shared` import.
 *
 * @module @elftia/plugin-types/host-api/workflow
 */
import type { HostUnregister } from './_shared';
import type { HostBrowserToolkitLike } from './workflow-browser';
import type { HostWorkflowStageRuntimeLike } from './workflow-stage-runtime';

// ───────────────────────────────────────────────────────────────────────────
// Descriptor — the wire-safe SSOT for a workflow's tool surface
// ───────────────────────────────────────────────────────────────────────────

/**
 * A tool's access classification — a CLOSED three-value set.
 *
 * The host derives its auto-allow (safe-tool) classification from this value
 * and nothing else: `read` ⇒ exempt from the sensitive-tool confirmation gate;
 * `write` and `interactive` ⇒ confirmed.
 *
 * `interactive` is DISTINCT from `read` even for a tool that only observes: a
 * tool that drives a live external surface the user owns (a real browser, a
 * terminal) carries a risk a pure read does not, and collapsing it into `read`
 * would silently auto-allow it. A provider MUST classify per TOOL, not per
 * operating mode — the host gate sees only the tool name, so a tool with some
 * read-shaped modes still declares the strongest access any of its modes needs
 * and records the nuance in {@link HostWorkflowToolDescriptor.note}.
 */
export type HostWorkflowToolAccess = 'read' | 'write' | 'interactive';

/**
 * ONE tool in a workflow's surface — the complete externally-observable
 * definition of that tool.
 *
 * WIRE-SAFETY: every field is JSON-serializable. `inputSchema` is a PLAIN JSON
 * Schema object — NOT a live Zod/Ajv/validator instance, not a class, not a
 * function. A provider that validates with a schema library MUST emit the plain
 * JSON Schema here and keep the live validator inside its own process.
 */
export interface HostWorkflowToolDescriptor {
  /** Unique tool name within the descriptor (the LLM-visible function name). */
  readonly name: string;
  /** Human/LLM-readable description. Non-empty. */
  readonly description: string;
  /**
   * The tool's JSON Schema, as a PLAIN serializable object (typed `unknown`
   * because this contract does not republish a JSON-Schema type). No function,
   * no live schema instance, no class.
   */
  readonly inputSchema: unknown;
  /** Access classification — see {@link HostWorkflowToolAccess}. */
  readonly access: HostWorkflowToolAccess;
  /**
   * OPTIONAL reviewer-facing note recording a classification nuance the
   * `access` value deliberately does not encode (e.g. "this `write` tool has
   * read-shaped modes; the gate is per-tool"). Display/review only — no code
   * path branches on it.
   */
  readonly note?: string;
}

/**
 * A named group of this workflow's tools the host exposes as one unit.
 *
 * Every member name MUST also appear in {@link HostWorkflowDescriptor.tools};
 * the host rejects the registration otherwise (fail-closed).
 */
export interface HostWorkflowToolsetDescriptor {
  /** Toolset name (the host-visible group id). */
  readonly name: string;
  /** Member tool names — each MUST be a declared tool of this descriptor. */
  readonly tools: readonly string[];
  /**
   * Whether the host enables this toolset by default. `false` ⇒ opt-in: the
   * tools are registered but stay invisible until a session enables the
   * toolset explicitly.
   */
  readonly enabledByDefault: boolean;
}

/**
 * Capability flags a workflow declares — which host integration surfaces it
 * claims to serve. Declaration/review data: the host reads them for display and
 * for deciding which optional surfaces to offer, never as a grant.
 */
export interface HostWorkflowCapabilities {
  /** Serves the project planning-space lifecycle. */
  readonly projectPlanning: boolean;
  /** Contributes per-session context (the working-set / reference index). */
  readonly sessionContext: boolean;
  /** Serves scheduled pipeline execution. */
  readonly cronPipeline: boolean;
  /** Ships a renderer surface. */
  readonly renderer: boolean;
}

/**
 * The workflow descriptor — the SINGLE SOURCE OF TRUTH for a workflow's tool
 * surface. The host derives EVERY classification from it: the tool name set,
 * toolset membership, the safe-tool allowlist and the legacy alias map. No host
 * module may keep an independently authored copy of any of them.
 *
 * PURE + REPEATABLE: {@link HostWorkflowProvider.describe} returns an equivalent
 * value on every call (see its JSDoc).
 *
 * WIRE-SAFE: the whole value survives a JSON round-trip deeply equal. A
 * descriptor containing a function, a circular reference, or an `undefined`
 * property value is REJECTED at registration time — before any projection
 * consumes it.
 *
 * VERSIONED: {@link protocolVersion} is checked exactly. A host that does not
 * implement the declared version REFUSES the registration rather than
 * interpreting the descriptor as the version it does implement.
 */
export interface HostWorkflowDescriptor {
  /** Stable workflow id (e.g. `'rasen'`). At most one active provider per id. */
  readonly id: string;
  /** The request/descriptor protocol this descriptor is written against. */
  readonly protocolVersion: 1;
  /** Human-readable workflow name (display only). */
  readonly displayName: string;
  /** Every tool this workflow contributes. At least one. */
  readonly tools: readonly HostWorkflowToolDescriptor[];
  /** Toolsets this workflow contributes; each member must be a declared tool. */
  readonly toolsets: readonly HostWorkflowToolsetDescriptor[];
  /**
   * Legacy alias map: `<legacy name>` → `<declared tool name>`. Read-time only
   * (a persisted legacy name resolves to the canonical tool); no persisted row
   * is rewritten. Every VALUE must name a declared tool. An alias KEY is never
   * itself auto-allowed — the safe-tool projection reads declared tools only.
   *
   * Carried explicitly rather than derived from a naming rule so a tool whose
   * legacy name is NOT the mechanical transform is still expressible.
   */
  readonly aliases: Readonly<Record<string, string>>;
  /** Which host integration surfaces this workflow claims to serve. */
  readonly capabilities: HostWorkflowCapabilities;
}

// ───────────────────────────────────────────────────────────────────────────
// Request — one versioned discriminated union, one entry point
// ───────────────────────────────────────────────────────────────────────────

/**
 * Host-owned identity + selector fields that travel with every request.
 *
 * MINIMALITY + WIRE-SAFETY: plain optional strings ONLY. NEVER a callback,
 * NEVER a host service handle, NEVER a live object. A provider that needs a
 * host capability receives it at construction through its own plugin host API,
 * not smuggled through a call context.
 *
 * PRECEDENCE: these are the session's DEFAULTS. A selector the caller supplied
 * in the request `input` takes precedence over the matching context field.
 */
export interface HostWorkflowCallContext {
  /** Working directory the operation resolves relative to (session project). */
  readonly cwd?: string;
  /** Host project id the session is bound to. */
  readonly projectId?: string;
  /** Host session id issuing the request. */
  readonly sessionId?: string;
  /** Host agent id issuing the request. */
  readonly agentId?: string;
  /** The session's bound store id — a DEFAULT selector, overridable by input. */
  readonly storeId?: string;
  /**
   * OPTIONAL host-generated idempotency key for a WRITE-classified operation.
   * When present, the provider MUST treat a repeated key as the SAME logical
   * operation (re-answer, do not re-apply). The host generates it only where it
   * owns the retry; a provider must not require it to be present.
   */
  readonly idempotencyKey?: string;
}

/** Invoke one declared tool by name with its raw, host-untyped input. */
export interface HostWorkflowToolRequest {
  readonly protocolVersion: 1;
  readonly kind: 'tool';
  /** A tool name declared by this workflow's descriptor. */
  readonly tool: string;
  /** The raw tool input, passed through OPAQUELY — the host does not type it. */
  readonly input: unknown;
  readonly context: HostWorkflowCallContext;
}

/** Drive the project planning-space lifecycle. */
export interface HostWorkflowProjectPlanningRequest {
  readonly protocolVersion: 1;
  readonly kind: 'project-planning';
  readonly action: 'enable' | 'disable' | 'status' | 'context';
  readonly input: unknown;
  readonly context: HostWorkflowCallContext;
}

/** Drive a scheduled pipeline tick. */
export interface HostWorkflowCronRequest {
  readonly protocolVersion: 1;
  readonly kind: 'cron';
  readonly action: 'pipeline';
  readonly input: unknown;
  readonly context: HostWorkflowCallContext;
}

/**
 * Invoke one named operation of the workflow's full operation surface — the
 * transitional kind an IPC router or another in-host consumer addresses while it
 * still speaks in operation names rather than tool names.
 */
export interface HostWorkflowLegacyRequest {
  readonly protocolVersion: 1;
  readonly kind: 'legacy';
  /** Operation name (provider-defined; an unknown name is `invalid_request`). */
  readonly operation: string;
  readonly input: unknown;
  readonly context: HostWorkflowCallContext;
}

/**
 * The request union — ONE entry point, versioned and discriminated.
 *
 * WHY ALL FOUR KINDS ARE DEFINED AT ONCE: adding a variant to a union the
 * PROVIDER must handle widens the provider's obligation — a BREAKING change for
 * a third-party provider, not an additive one. All four are therefore declared
 * in the first release; a provider that does not yet serve a kind answers it
 * `invalid_request` with a diagnostic saying so ("declared, not yet served"),
 * exactly as this vocabulary's declaration-only permission tokens do.
 */
export type HostWorkflowRequest =
  | HostWorkflowToolRequest
  | HostWorkflowProjectPlanningRequest
  | HostWorkflowCronRequest
  | HostWorkflowLegacyRequest;

// ───────────────────────────────────────────────────────────────────────────
// Response — one envelope, one closed error vocabulary
// ───────────────────────────────────────────────────────────────────────────

/**
 * The CLOSED error-code vocabulary. A consumer branches on these and nothing
 * else; adding a code is a CONTRACT change, not an implementation detail.
 *
 *   - `workflow_unavailable`   — no provider is registered for the workflow id.
 *   - `dependency_unavailable` — the provider is up but a dependency it needs
 *                                is not (degraded, retryable later).
 *   - `invalid_request`        — structurally illegal payload, unknown tool /
 *                                operation, or a kind the provider does not serve.
 *   - `invalid_selector`       — the selector (store / root / change) does not
 *                                resolve to something addressable.
 *   - `legacy_root_read_only`  — the addressed root is a read-only legacy overlay.
 *   - `run_already_active`     — a run this request would start is already active.
 *   - `shutdown_in_progress`   — the provider is draining; the request was
 *                                refused rather than raced into it. DISTINCT
 *                                from `workflow_unavailable` on purpose.
 *   - `stage_dispatch_busy`    — the stage runtime is at max concurrency;
 *                                RETRYABLE (the caller backs off and retries).
 *   - `stage_dispatch_failed`  — the stage runtime failed to dispatch or the
 *                                dispatched worker failed; not retryable as-is.
 *   - `internal_error`         — an implementation fault, including any throw
 *                                the host converted. Names the owner id.
 */
export type HostWorkflowErrorCode =
  | 'workflow_unavailable'
  | 'dependency_unavailable'
  | 'invalid_request'
  | 'invalid_selector'
  | 'legacy_root_read_only'
  | 'run_already_active'
  | 'shutdown_in_progress'
  | 'stage_dispatch_busy'
  | 'stage_dispatch_failed'
  | 'internal_error';

/** A call-level failure. Wire-safe: plain strings only. */
export interface HostWorkflowError {
  /** The closed-vocabulary code a consumer branches on. */
  readonly code: HostWorkflowErrorCode;
  /** Readable message. Never a stack, never a host object. */
  readonly message: string;
  /**
   * The owner id the host attributed the failure to (the registering plugin id,
   * or the built-in owner id for an in-tree provider). Set by the HOST for a
   * contained provider fault; a provider may leave it absent.
   */
  readonly ownerId?: string;
}

/**
 * A structured, non-fatal note attached to a response. Domain-level failure
 * detail travels inside the opaque `data` payload, NOT here — diagnostics are
 * for facts about the CALL (e.g. "this request kind is declared but not served
 * in this release").
 */
export interface HostWorkflowDiagnostic {
  readonly level: 'info' | 'warning' | 'error';
  /** Stable machine-readable code. */
  readonly code: string;
  readonly message: string;
}

/**
 * The response envelope — ONE shape, discriminated on `ok`.
 *
 * `ok` answers **"did the call reach the operation"**, NOT "did the user get
 * what they wanted" (design D5):
 *
 * | Situation                                            | Envelope   | Payload                       |
 * |------------------------------------------------------|------------|-------------------------------|
 * | Operation ran and succeeded                           | `ok: true` | the provider's opaque result  |
 * | Operation ran, DOMAIN failure (missing change, bad    | `ok: true` | the result, carrying its own  |
 * | root, validation)                                     |            | structured failure diagnostics |
 * | Unregistered / draining / unknown tool / illegal      | `ok: false`| `error.code` from the closed  |
 * | payload / provider fault                              |            | vocabulary                    |
 *
 * The alternative — mapping domain failure to `ok: false` — would force the
 * host to synthesize a domain payload for every failing call and would make
 * `workflow_unavailable` indistinguishable from "change not found" at the
 * envelope level. A consumer can therefore branch on `ok` WITHOUT inspecting
 * the opaque payload.
 */
export type HostWorkflowResponse =
  | {
      readonly ok: true;
      /** The provider's result, passed through OPAQUELY (the host never parses it). */
      readonly data: unknown;
      readonly diagnostics?: readonly HostWorkflowDiagnostic[];
    }
  | {
      readonly ok: false;
      readonly error: HostWorkflowError;
      readonly diagnostics?: readonly HostWorkflowDiagnostic[];
    };

// ───────────────────────────────────────────────────────────────────────────
// Provider — three verbs, with behavioral obligations
// ───────────────────────────────────────────────────────────────────────────

/** Why the host is shutting a provider down. */
export type HostWorkflowShutdownReason = 'disable' | 'reload' | 'app-quit';

/**
 * The workflow provider — EXACTLY three verbs. The obligations in each verb's
 * JSDoc are part of the contract: a provider that satisfies the TypeScript
 * signatures but violates them is non-conforming.
 *
 * ACTIVATION RE-ENTRANCY (a whole-provider obligation): a plugin's `activate`
 * MAY run more than once in a single process (disable → re-enable reuses the
 * cached module). Each activation MUST construct a FRESH provider runtime — no
 * executor, disposer, cache or registration from a previous activation may be
 * reused.
 *
 * NO RETAINED HOST MUTABLE GLOBAL (a whole-provider obligation): a provider
 * holds ONLY the values passed to it at construction. It retains no long-lived
 * reference to a mutable host global, and reaches host capability through its
 * own injected host API, never through ambient host state.
 */
export interface HostWorkflowProvider {
  /**
   * Publish this workflow's surface.
   *
   * OBLIGATIONS — `describe()` is PURE and REPEATABLE:
   *   - calling it more than once on the same instance returns an EQUIVALENT
   *     descriptor each time;
   *   - it performs NO I/O, mutates NO state and has NO observable side effect;
   *   - the returned value is wire-safe (see {@link HostWorkflowDescriptor}).
   *
   * The host calls it ONCE at registration and caches the validated result. A
   * throw here FAILS the registration closed — no tool, toolset or alias from
   * this provider is exposed anywhere.
   */
  describe(): HostWorkflowDescriptor;

  /**
   * Serve one request. The single entry point for every kind.
   *
   * OBLIGATIONS:
   *   - A BUSINESS failure is DATA, not a throw. When an operation fails for a
   *     domain reason (a missing change, an unresolvable root, a validation
   *     failure) `execute` RESOLVES — `{ ok: true, data }` — and the failure
   *     rides inside the payload as structured diagnostics. See
   *     {@link HostWorkflowResponse}.
   *   - A PROTOCOL violation MAY reject. When the host sends a request whose
   *     `protocolVersion` or `kind` the provider does not implement, or whose
   *     payload is structurally illegal, the provider may reject; the host
   *     CONVERTS the rejection into an `internal_error` response naming the
   *     owner. A provider is NEVER required to guess a meaning for an illegal
   *     payload — answering `invalid_request` is equally conforming.
   *   - A WRITE operation supports a host-generated
   *     {@link HostWorkflowCallContext.idempotencyKey}: when the host supplies
   *     one, a repeat with the same key is the SAME logical operation.
   *   - `input` is parsed by the PROVIDER (its own schema), never by the host.
   */
  execute(request: HostWorkflowRequest): Promise<HostWorkflowResponse>;

  /**
   * Drain this provider.
   *
   * OBLIGATIONS:
   *   - CANCEL or DRAIN in-flight work and release timers, listeners and
   *     handles;
   *   - DELETE NOTHING: no store, no run-state, no project root, no global
   *     user data. `shutdown` is a lifecycle stop, never a cleanup of the
   *     user's content;
   *   - the host has ALREADY revoked the registration and started refusing new
   *     requests before calling this, so a provider need not self-gate;
   *   - it must not throw for a reason it can contain (the host logs and
   *     continues either way).
   */
  shutdown(reason: HostWorkflowShutdownReason): Promise<void>;
}

/**
 * `host.workflow` — the registration namespace: one verb and two optional
 * capability handles.
 *
 * A NAMESPACE OBJECT rather than a fourth top-level `registerX` method so the
 * sibling workflow seams (a stage runtime, a browser toolkit) land beside it
 * without another top-level member. v1.40 lands exactly those two seams here,
 * as the reservation above anticipated.
 *
 * OWNER IDENTITY IS HOST-INJECTED: the host closes over the registering
 * plugin's id and records it as the owner. No plugin-supplied identity is
 * accepted — a plugin can neither name its own owner id nor register on behalf
 * of another plugin.
 *
 * The returned teardown is the SAME `() => void` shape as
 * `HostBackendUnregister` (`../backend`) — declared here as the lib-agnostic
 * {@link HostUnregister} primitive because `backend.ts` imports this module and
 * `_shared.ts` exists precisely to break that cycle (Decision D6). The host
 * also feeds the teardown into its own per-plugin teardown drain, so disabling
 * the owner revokes the registration even if the plugin never calls it.
 */
export interface HostWorkflowRegistration {
  /**
   * Register `provider` as the active provider for the workflow id its
   * descriptor declares.
   *
   * FAILS (throws) when the descriptor is invalid, or when the id already has
   * an active provider — the incumbent keeps serving, and last-registration
   * NEVER wins.
   */
  register(provider: HostWorkflowProvider): HostUnregister;

  /**
   * ADDITIVE v1.40 — the stage-dispatch capability a workflow's pipeline runs
   * its stage workers through. See {@link HostWorkflowStageRuntimeLike}.
   *
   * OPTIONAL (design D6): a required member would be a MAJOR break by this
   * package's freeze checklist, and a host build that wires no stage runtime is
   * a SUPPORTED shape — the member is ABSENT rather than present-and-throwing,
   * and a provider that guards for it activates normally without
   * stage-execution capability.
   *
   * WIRE-PROXIED by the protocol-v3 extension host. The host brokers
   * start/wait/cancel and the child receives the same synchronous namespace
   * shape as the in-process path; absence still means the capability was not
   * granted or wired.
   */
  readonly stageRuntime?: HostWorkflowStageRuntimeLike;

  /**
   * ADDITIVE v1.40 — the curated live-browser capability a workflow's browse
   * driver drives a real browser through. See {@link HostBrowserToolkitLike}.
   *
   * OPTIONAL (design D6), for the same reasons as {@link stageRuntime}: absence
   * is a supported host shape, and a provider that guards for it activates
   * normally without browser capability.
   *
   * NAMED `browserToolkit`, NOT `browser` (design D7): the static permission
   * scanner matches a BARE PROPERTY NAME anywhere in a bundle, and `.browser`
   * would fire on nearly any bundle. The distinctive name is a decision made FOR
   * the scanner.
   *
   * WIRE-PROXIED by the protocol-v3 extension host through a permission-gated
   * invoke broker; see {@link stageRuntime}.
   */
  readonly browserToolkit?: HostBrowserToolkitLike;
}
