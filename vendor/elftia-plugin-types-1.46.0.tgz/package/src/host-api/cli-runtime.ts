/**
 * host-api/cli-runtime.ts — `HostCliRuntimeLike`, the `host.services.cliRuntime`
 * capability port (`byo-host-cli-runtime-port`, host-API v1.26).
 *
 * Lets a Tier-1 main plugin (the `byo-providers` plugin) drive the Code CLI
 * runtime UI — availability badges, install buttons, terminal launch, the
 * per-backend enable toggle — WITHOUT the host owning that UI. Mirrors the
 * `window.native.codeCli.*` IPC the host CodeCliTab uses:
 * `getAuthStatus` / `setEnabled` / `install` / `launchTerminal` / `listBackends`.
 *
 * ── NO-CREDENTIAL-ON-RETURN INVARIANT (design D3) ──
 * No method returns a credential. `getAuthStatus` returns availability
 * DESCRIPTORS only ({@link HostCliAuthStatus} — installed / authenticated /
 * backendId / display fields, NEVER a token); `install` / `launchTerminal` are
 * HOST-RUN actions (a package install, a PTY spawn) returning a status envelope
 * ({@link HostCliRuntimeResult}); `setEnabled` flips a host-side toggle.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports it.
 * No DOM type leaks in. Like the sibling BYO ports, the payload shapes are
 * STRUCTURAL LOWER BOUNDS (Node-shaped, no `@main`/`@shared` import) — the host's
 * canonical `CliAuthStatus` is structurally assignable, and the plugin re-narrows
 * what it reads.
 *
 * @module @elftia/plugin-types/host-api/cli-runtime
 */

/**
 * A single Code CLI backend's availability/auth DESCRIPTOR (display-only). Pins
 * the fields the runtime UI reads (`backendId` / `displayName` / `installed` /
 * `authenticated` / `enabled` + the non-secret display extras) and DELIBERATELY
 * carries NO token. Canonical host `CliAuthStatus`; the index signature keeps the
 * rest opaque BUT the contract guarantees no credential is typeable.
 */
export interface HostCliAuthStatus {
  /** Stable backend id (e.g. `'claude-code'`, `'codex'`, `'gemini-cli'`). */
  readonly backendId: string;
  /** Human-friendly display name. */
  readonly displayName: string;
  /** Whether the CLI binary is installed + found on PATH. */
  readonly installed: boolean;
  /** Whether valid auth credentials exist — a BOOLEAN, never the credential. */
  readonly authenticated: boolean;
  /** Whether the per-backend enable toggle is on. */
  readonly enabled: boolean;
  /** Account email/identifier display (when authenticated) — non-secret. */
  readonly email?: string;
  /** Auth-method display (`'oauth' | 'manual' | 'setup_token'`) — non-secret. */
  readonly authMethod?: string;
  /** Whether the host knows how to install this CLI (UI gates the Install button). */
  readonly installable?: boolean;
  /** Stream protocol family (`'standard' | 'acp'`) — a UI label. */
  readonly protocol?: 'standard' | 'acp';
  /** Status-check error message (never a credential). */
  readonly error?: string;
  /** Remaining display fields opaque — see canonical `CliAuthStatus`. */
  readonly [key: string]: unknown;
}

/** Optional `getAuthStatus` options — `force` busts the host availability cache. */
export interface HostCliAuthStatusOptions {
  /** Bust the availability + model caches before re-probing. */
  readonly force?: boolean;
}

/** A registered CLI backend (the `listBackends` payload) — display descriptor. */
export type HostCliBackendInfo = { readonly [key: string]: unknown };

/** A status-only host-run-action result (install / launch) — NEVER a credential. */
export interface HostCliRuntimeResult {
  /** Whether the host action succeeded. */
  readonly ok: boolean;
  /** Machine-readable failure reason (never a credential). */
  readonly error?: string;
}

/**
 * The terminal-launch request the plugin relays. Carries ONLY the backend id +
 * non-secret launch options (`cwd`, `injectProviderEnv`); no credential. The host
 * resolves any provider env host-side and spawns the PTY itself.
 */
export interface HostCliLaunchTerminalInput {
  /** Which CLI backend to launch. */
  readonly backendId: string;
  /** Optional working directory the CLI runs in (validated host-side). */
  readonly cwd?: string;
  /** Whether to inject Elftia's resident provider proxy env (host-resolved). */
  readonly injectProviderEnv?: boolean;
}

/**
 * `host.services.cliRuntime` — the Code CLI availability / install / launch port.
 *
 * Every method delegates to the host's EXISTING `codeCli:*` runtime (the same
 * services the IPC handlers call); install/launch are host-run actions returning
 * a status envelope. NO method returns a credential — `getAuthStatus` returns
 * availability descriptors only.
 */
export interface HostCliRuntimeLike {
  /**
   * Per-backend availability/auth DESCRIPTORS (installed / authenticated /
   * backendId + display fields). NO credential crosses. `force: true` busts the
   * host availability cache before re-probing.
   */
  getAuthStatus(options?: HostCliAuthStatusOptions): Promise<HostCliAuthStatus[]>;
  /** Flip a backend's host-side enable toggle; status only. */
  setEnabled(backendId: string, enabled: boolean): Promise<HostCliRuntimeResult>;
  /** Install a CLI backend host-side (runs the platform package install); status only. */
  install(backendId: string): Promise<HostCliRuntimeResult>;
  /** Open a system terminal + start the CLI host-side; status only (no credential). */
  launchTerminal(input: HostCliLaunchTerminalInput): Promise<HostCliRuntimeResult>;
  /** List the registered CLI backends (display descriptors). */
  listBackends(): Promise<HostCliBackendInfo[]>;
}
