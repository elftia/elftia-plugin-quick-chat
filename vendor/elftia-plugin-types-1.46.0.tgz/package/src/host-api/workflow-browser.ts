/**
 * host-api/workflow-browser.ts — `HostBrowserToolkitLike`, the CURATED
 * browser-driving port a workflow reaches a live browser through
 * (`rasen-single-plugin` Milestone 2, host-API v1.40).
 *
 * WHY: a workflow's browse driver has to drive a real browser to verify a
 * running app. Before this port the driver reached a module-level host global at
 * execute time and addressed the underlying toolkit BY FUNCTION NAME, so nothing
 * outside the host process could serve it and no test could exercise it without
 * mocking a host module. This port is the seam.
 *
 * CURATED, NOT PASSTHROUGH (design D9): the vocabulary is the 13 VERBS the
 * browse driver offers — NOT the underlying toolkit's function catalog. No
 * toolkit function name appears anywhere in this module, and a caller cannot
 * address the toolkit by function name through it. Resolving a verb to a
 * concrete function (including the verbs whose target depends on the parameters
 * supplied) is the ADAPTER's job, on the far side of this port. Publishing the
 * function names instead would not be a curated port at all.
 *
 * HONEST DEGRADATION: when the browser cannot be driven, the port answers a
 * REASON-DISCRIMINATED unavailability ({@link HostBrowserUnavailableReason}), so
 * the caller renders remediation naming what is actually wrong. It never
 * fabricates a page result.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module. It MUST NOT be
 * imported by `renderer.ts`; only `backend.ts` imports it. Every field is a
 * plain `string` / `boolean` / `unknown` — no DOM type, no `electron`/Node type,
 * no `@main`/`@shared` import. In particular NO LOGGER crosses this port
 * (design D10): the adapter is constructed with the logger it needs.
 *
 * @module @elftia/plugin-types/host-api/workflow-browser
 */

// ───────────────────────────────────────────────────────────────────────────
// The action vocabulary — 13 curated verbs, closed
// ───────────────────────────────────────────────────────────────────────────

/**
 * The CLOSED set of browser actions this port serves — exactly the curated verbs
 * the workflow's browse driver offers, and nothing else.
 *
 * Adding an action is a CONTRACT change, not an implementation detail. An action
 * outside this union is refused before any toolkit, registry or browser
 * connection is touched.
 *
 *   - `check`      — connection/health gate. Run first.
 *   - `open`       — create a background tab.
 *   - `navigate`   — go to a URL.
 *   - `read`       — extract DOM (text, or a named attribute).
 *   - `click`      — interact (element click, or a real coordinate mouse click).
 *   - `screenshot` — visual evidence to a file.
 *   - `eval`       — arbitrary JS/DOM in the page.
 *   - `wait`       — await a selector or an expression.
 *   - `close`      — tear a tab down.
 *   - `snapshot`   — interactive-DOM tree with stable handles.
 *   - `perf`       — page performance metrics.
 *   - `viewport`   — emulate a device viewport.
 *   - `responsive` — audit across breakpoints.
 */
export type HostBrowserAction =
  | 'check'
  | 'open'
  | 'navigate'
  | 'read'
  | 'click'
  | 'screenshot'
  | 'eval'
  | 'wait'
  | 'close'
  | 'snapshot'
  | 'perf'
  | 'viewport'
  | 'responsive';

// ───────────────────────────────────────────────────────────────────────────
// Invoke context — plain identity, and nothing else
// ───────────────────────────────────────────────────────────────────────────

/**
 * Host-owned identity that travels with every invocation.
 *
 * MINIMALITY + WIRE-SAFETY (design D10): plain optional strings ONLY. NEVER a
 * logger, NEVER a callback, NEVER a host service handle, NEVER a live object.
 * The host-side implementation of this port builds whatever richer context its
 * substrate wants from these plain values plus the dependencies it was
 * CONSTRUCTED with — it does not receive them through a call.
 */
export interface HostBrowserInvokeContext {
  /** Workspace/codebase root the calling session is bound to. */
  readonly workspacePath?: string;
  /** Host agent id issuing the call. */
  readonly agentId?: string;
  /** Host session id issuing the call. */
  readonly sessionId?: string;
}

// ───────────────────────────────────────────────────────────────────────────
// Result — reason-discriminated unavailability, never a fabricated page
// ───────────────────────────────────────────────────────────────────────────

/**
 * WHY the browser could not be driven — a CLOSED discriminator, because the
 * three cases need three different remediations:
 *
 *   - `not_initialized`       — the host's toolkit substrate has not finished
 *                               initializing (boot incomplete). Transient.
 *   - `toolkit_not_registered`— no browser toolkit is registered in this build.
 *                               Not transient; the capability is absent.
 *   - `not_connected`         — the substrate is present but the browser itself
 *                               is not connected. The user must launch it.
 */
export type HostBrowserUnavailableReason =
  | 'not_initialized'
  | 'toolkit_not_registered'
  | 'not_connected';

/**
 * The answer to one invocation — THREE branches, discriminated on `ok` and then
 * on the presence of `unavailable`.
 *
 * OBLIGATIONS:
 *   - an UNAVAILABLE result is never a fabricated page result. A caller renders
 *     remediation naming the reason and states that no page was driven;
 *   - a substrate rejection is CONTAINED into the `error` branch — nothing
 *     propagates as an unhandled rejection;
 *   - `data` is the substrate's own payload, passed through OPAQUELY. The port
 *     does not type it and the caller does not parse it.
 */
export type HostBrowserInvokeResult =
  | {
      readonly ok: true;
      /** The substrate's result, passed through OPAQUELY. */
      readonly data: unknown;
    }
  | {
      readonly ok: false;
      /** The browser could not be driven at all — see the reason. */
      readonly unavailable: {
        readonly reason: HostBrowserUnavailableReason;
        /**
         * Readable detail about this particular failure.
         *
         * ADVISORY, not the remediation text. A caller is expected to key its
         * user-facing remediation off {@link HostBrowserUnavailableReason} — the
         * reason is the closed, stable discriminator, while this string is a
         * free-form diagnostic that varies by implementation. A caller whose
         * output is pinned by a contract test therefore renders reason-keyed
         * text and may ignore this field entirely; one that logs or surfaces
         * diagnostics should include it.
         */
        readonly message: string;
      };
    }
  | {
      readonly ok: false;
      /** The browser was driven and the action itself failed. */
      readonly error: {
        /** Readable message. Never a stack, never a host object. */
        readonly message: string;
      };
    };

// ───────────────────────────────────────────────────────────────────────────
// The port — one verb
// ───────────────────────────────────────────────────────────────────────────

/**
 * A browser toolkit — ONE verb, over the closed {@link HostBrowserAction}
 * vocabulary.
 *
 * NARROW-PORT MINIMALITY (窄端口): no registry, no toolkit handle, no function
 * catalog and no way to reach a function the vocabulary does not name is
 * exposed. The DEPTH is behind the verb: resolving an action to a concrete
 * substrate function — including the actions whose target depends on the
 * parameters supplied — happens on the implementation side.
 */
export interface HostBrowserToolkitLike {
  /**
   * Perform ONE curated browser action.
   *
   * OBLIGATIONS:
   *   - resolve the action to its substrate function INTERNALLY; the caller
   *     supplies only the verb and its parameters;
   *   - forward `params` OPAQUELY — they are validated by the substrate's own
   *     schema, not by the caller. An omitted parameter object is an EMPTY
   *     parameter object;
   *   - answer `check` with an UNAVAILABLE `not_connected` result when the
   *     connection check reports a disconnected browser, rather than a
   *     successful check carrying a not-connected payload;
   *   - CONTAIN a substrate rejection into the `error` branch;
   *   - never fabricate a page result.
   */
  invoke(
    action: HostBrowserAction,
    params: Record<string, unknown>,
    ctx: HostBrowserInvokeContext,
  ): Promise<HostBrowserInvokeResult>;
}
