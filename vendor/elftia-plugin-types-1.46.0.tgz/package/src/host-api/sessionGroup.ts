/**
 * host-api/sessionGroup.ts — `SessionGroupDefinitionLike`, the structural lower
 * bound for `host.sessionGroup.register(def)` (an ADDITIVE v1.1 member of
 * `AgentUiHostApi`).
 *
 * The Child-J session-group registry (`sessionGroupStore` + `registerSessionGroup`)
 * shipped AFTER the original four-registry freeze, so the frozen v1 had no
 * `sessionGroup` handle. This module freezes only the HANDLE shape; the backing
 * fn (`registerSessionGroup`) is the contract, mirroring the `hello`/`workspace`
 * precedent.
 *
 * DOM-PURITY INVARIANT (Decision D2): structural shapes + `_shared` primitives
 * ONLY — no `electron` / `WebContents` / `node:*` type, no `react` runtime dep.
 *
 * @module @elftia/plugin-types/host-api/sessionGroup
 */
import type { HostReactNode } from './_shared';

/**
 * A sidebar session item, declared structurally (the predicate + renderer only
 * read these fields). Mirrors the canonical `SessionGroupSessionLike` WITHOUT an
 * index signature, so the sidebar's concrete `SessionItem` stays assignable.
 *
 * @remarks Canonical source: `renderer/src/shared/state/sessionGroupStore.ts`
 *   (`SessionGroupSessionLike`).
 */
export interface SessionGroupSessionRef {
  readonly id: string;
  readonly sessionType?: string;
  readonly agentId?: string | null;
  readonly cronJobId?: string | null;
}

/**
 * Structural LOWER BOUND of the shipped `SessionGroupDescriptor`.
 *
 * Pins the REQUIRED identity members the real descriptor demands — the section
 * `key`, the `match` predicate, the resolved `label`, and the `renderSection`
 * renderer — so a plugin that omits any of them fails to compile (matching what
 * `registerSessionGroup` would reject). Everything else (the optional
 * `defaultOrder` / `collapseStorageKey` / `onNameClick` / `absorbsAgentIds` /
 * `hideable`) stays opaque (`[key: string]: unknown`), so the freeze does not
 * lock a renderer-owned contract's full field set into this package. The
 * `renderSection` props are renderer-owned and typed opaquely (lower bound).
 *
 * Mirrors the `AgentHelloDefinitionLike` / `WorkspaceDefinitionLike` pattern.
 *
 * @remarks Canonical source: `renderer/src/shared/state/sessionGroupStore.ts`
 *   (`SessionGroupDescriptor`). Backed by `registerSessionGroup(def)`.
 * @stability frozen (identity members pinned; the BACKING fn is the contract)
 */
export interface SessionGroupDefinitionLike {
  /** Sidebar top-level section id (e.g. `'design-studio'`). REQUIRED. */
  readonly key: string;
  /** Pure classifier predicate — replaces the host's literal branch. REQUIRED. */
  match(session: SessionGroupSessionRef): boolean;
  /** Resolved display name (header / drag aria / context-menu title). REQUIRED. */
  readonly label: string;
  /** Render the section body (header + flat session list). REQUIRED. */
  renderSection(props: unknown): HostReactNode;
  /** Remaining members (defaultOrder, collapseStorageKey, …) are opaque — see source. */
  readonly [key: string]: unknown;
}
