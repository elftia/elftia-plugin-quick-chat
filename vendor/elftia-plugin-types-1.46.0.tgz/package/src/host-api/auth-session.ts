/**
 * host-api/auth-session.ts — `HostAuthSessionLike`, the NARROW write-only
 * `host.services.authSession` capability port (`oss-channel-isolation` Phase 3
 * slices P3-3b-2b-i [v1.31] + P3-3b-2b-ii [v1.32]).
 *
 * WHY (P3 context): the channel-gated Steam plugin's in-process MAIN half does
 * two Steam-local reads — Colorful DLC ownership (steamworks `apps.isDlcInstalled`)
 * and the steamworks web-API auth ticket — and hands the HOST the bare facts. The
 * HOST owns the session: `AuthSessionState` (+ the `hasColorfulAccess()` gate) and
 * the elftia-web ticket EXCHANGE + token persist. This port is the write seam:
 * the plugin reports what it observed; the host applies it. The plugin never reads
 * or owns session state, and NO token/user/session field ever crosses back.
 *
 * WRITE-ONLY / NARROW (窄端口, the `secretsWrite` shape): TWO write verbs and NO
 * session READ —
 *   - `setSteamColorfulDlcOwned(owned)` (v1.31) — push DLC ownership; the host
 *     folds it into `AuthSessionState.steamColorfulDlcOwned` + emits a state update.
 *   - `applySteamSession(ticketHex, identity)` (v1.32) — drive a Steam
 *     ticket-exchange login: the plugin hands ONLY the hex + identity; the HOST
 *     runs the elftia-web exchange + session apply/persist (TOKENS NEVER CROSS) and
 *     owns the NO-CLOBBER guard (a present valid session short-circuits the
 *     exchange). Returns a narrow status only.
 * The port deliberately exposes NO `getState`/`hasColorfulAccess`/token/user/
 * channel — a plugin cannot read who is signed in, cannot read the access token,
 * and cannot read the gate result; it can only report facts it observed.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports it
 * (via `backend-services.ts`). Every member uses a plain `boolean` / `string` /
 * `Promise` / plain-object only — no DOM/Node type, no `@main`/`electron` import.
 *
 * @module @elftia/plugin-types/host-api/auth-session
 */

/**
 * Result of {@link HostAuthSessionLike.applySteamSession} (v1.32). A NARROW
 * status ONLY — NO token / user / session / access field crosses back to the
 * plugin (the host ran the exchange + persist host-side).
 *   - `applied: true` — the ticket exchange succeeded + the session was persisted;
 *   - `applied: false` + `skipped: true` — the host's NO-CLOBBER guard
 *     short-circuited (a present valid session was preserved; no exchange ran);
 *   - `applied: false` + `reason` — a bad-ticket reject (`'bad_ticket'`) or the
 *     exchange error message (no exchange/persist outcome leaked beyond the text).
 */
export interface SteamSessionApplyResult {
  /** `true` iff the ticket exchange succeeded and the session was persisted. */
  readonly applied: boolean;
  /** `true` iff the no-clobber guard preserved a present session (no exchange). */
  readonly skipped?: boolean;
  /** A failure reason — `'bad_ticket'` or the exchange error message. */
  readonly reason?: string;
}

/**
 * `host.services.authSession` — the NARROW write-only session-sink port. TWO
 * write verbs, no session read; backed by the host's `AuthSessionService` (the
 * SAME singleton the v1.29 `relayApi` port draws the bearer from).
 */
export interface HostAuthSessionLike {
  /**
   * Push the locally-read Steam Colorful DLC ownership to the host so the
   * main-side `hasColorfulAccess()` gate reflects it. WRITE-ONLY: the host folds
   * `owned` into `AuthSessionState.steamColorfulDlcOwned` (idempotently) and
   * emits a state update; NOTHING is returned (no read, no gate result, no
   * session/token/user field is exposed by this port). Resolves once the host
   * has applied the value.
   */
  setSteamColorfulDlcOwned(owned: boolean): Promise<void>;
  /**
   * v1.32 — drive a Steam ticket-exchange login. The plugin reads the steamworks
   * web-API ticket locally and hands ONLY the `ticketHex` + `identity` here; the
   * HOST runs the elftia-web exchange + session apply/persist (TOKENS NEVER CROSS
   * back to the plugin). The host owns the NO-CLOBBER guard — a present valid
   * session short-circuits the exchange (`{ applied: false, skipped: true }`).
   * Resolves a narrow {@link SteamSessionApplyResult} (status only — no token/
   * user/session field). A bad ticket rejects host-side without an exchange.
   */
  applySteamSession(ticketHex: string, identity: string): Promise<SteamSessionApplyResult>;
}
