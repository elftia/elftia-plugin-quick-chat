/**
 * host-api/in-app-content.ts — `HostInAppContentLike`, the NARROW in-app-content
 * enumerate + package `host.services.inAppContent` capability port
 * (`workshop-publish-in-app-content`, host-API v1.34).
 *
 * WHY: the channel-gated Steam plugin's MAIN half can publish a user's
 * self-created in-app content (a custom THEME or AGENT) to the Workshop, not only
 * installed plugin packages. Enumerating those items + materializing a chosen one
 * into a valid Workshop content directory is CORE-OWNED work: it reads core
 * storage (the `custom_agents` table, the theme service) and runs the SECRET-FREE
 * export paths (`AgentManagementService.exportAgent` / `ThemeService.exportProfile`).
 * Threading raw `host.services.db` into the plugin would be a WIDE, unaudited port
 * (it exposes every table) AND the plugin would have to re-implement the
 * secret-free projection + built-in filter the host already does correctly — a
 * drift risk (a future agent field carrying a secret would leak). This narrow port
 * is the seam: the plugin asks the host to enumerate, then to package one item,
 * and feeds the returned content dir to the SAME `publishPlugin` upload path used
 * for installed plugins. No item content crosses the renderer; the host owns
 * secret-stripping + packaging.
 *
 * NARROW-PORT MINIMALITY (窄端口): EXACTLY two verbs — `list()` (enumerate the
 * user's publishable in-app items) and `package({ kind, id })` (materialize ONE
 * item into a Workshop content dir). NO update/delete/read-body verb (the plugin
 * never edits in-app content, only publishes it), no generic DB passthrough.
 *
 * ALLOWLIST IS A HARD HOST BOUNDARY: the publishable-in-app `kind` is the union
 * `'theme' | 'agent'` ONLY. `list()` NEVER returns a `prompt-template` (or any
 * other) kind; `package()` THROWS for any kind outside the allowlist. This is the
 * Steam-review / portrait / IP guardrail enforced at the host, not merely hidden
 * in the UI.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports it
 * (via `backend-services.ts`). Every member uses plain `string` / record /
 * `Promise` shapes only — no DOM/Node type leaks in.
 *
 * @module @elftia/plugin-types/host-api/in-app-content
 */

/**
 * The publishable-in-app `kind` union — the HARD allowlist. A host enumerator
 * may only surface these kinds, and the host packager rejects anything else.
 * Deliberately EXCLUDES `prompt-template` (hard-blocked from Workshop publishing)
 * and the not-yet-shipped `design-system` / `tool-pack` / `app-extension`.
 */
export type HostInAppContentKind = 'theme' | 'agent';

/**
 * One publishable in-app item the host enumerates. The `id` is the STABLE in-app
 * id (`custom_agents.id` for an agent, the theme pack/item id for a theme) — it
 * is the publish payload's `itemId`. The host guarantees `kind` is on the
 * allowlist and the item is user-created (built-in/bundled items are excluded).
 */
export interface HostInAppContentItem {
  /** Stable in-app id (`custom_agents.id` / theme item id) — the publish `itemId`. */
  readonly id: string;
  /** Publishable kind — host guarantees one of the allowlist (never `prompt-template`). */
  readonly kind: HostInAppContentKind;
  /** Display label for the picker. */
  readonly displayName: string;
  /** Optional secondary label (e.g. an agent's category). */
  readonly description?: string;
}

/**
 * Result of {@link HostInAppContentLike.package}. A descriptor of a freshly
 * materialized Workshop content dir the plugin's MAIN feeds DIRECTLY to its
 * existing `publishPlugin` upload path (NOT a `pluginsRootDir`+id pair).
 */
export interface HostInAppContentPackageResult {
  /**
   * Absolute path to a freshly-materialized Workshop content dir (a real plugin
   * bundle: `elftia-plugin.json` + the contributed content file), under a
   * host-owned temp root. The plugin publishes THIS dir; the host authored it
   * (no user-supplied path crossed).
   */
  readonly contentDir: string;
  /** The kind tag the publish path applies (mirrors the bundle's `manifest.kind`). */
  readonly kind: HostInAppContentKind;
  /**
   * The deterministic, flat-safe plugin-id slug for the bundle
   * (`inapp-<kind>-<itemId>`, charset-sanitized) — the publication-record key.
   * Stable across re-publishes of the SAME item so re-publish UPDATES the
   * existing Workshop item; namespaced so it never collides with a real plugin id.
   */
  readonly pluginId: string;
}

/**
 * `host.services.inAppContent` — the NARROW in-app-content enumerate + package
 * port (v1.34). The host owns enumeration (user-created + allowlisted-kind only),
 * secret-stripping, and content-dir materialization; the plugin only selects an
 * id and uploads the returned dir.
 *
 * @stability additive (MINOR, v1.34) — frozen once published; evolution follows
 *   the `version.ts` freeze checklist. Absent on a build that does not wire the
 *   agent/theme singletons (the plugin `activate` guards — the optional-dep pattern).
 */
export interface HostInAppContentLike {
  /**
   * Enumerate the user's publishable in-app content. Returns ONLY user-created,
   * allowlisted-kind items (built-in agents (`isBuiltin`) and bundled built-in
   * theme packs are excluded; `prompt-template` is never returned).
   */
  list(): Promise<HostInAppContentItem[]>;
  /**
   * Materialize ONE chosen item into a Workshop content dir under a host-owned
   * temp root and return its descriptor. The host writes the bundle itself (no
   * user path crosses) and strips secrets via the existing secret-free export
   * paths. THROWS if the id is unknown, the item is built-in, or `kind` is not on
   * the publishable-in-app allowlist (`{ theme, agent }`).
   *
   * `title` (OPTIONAL, additive) is the user's chosen Workshop title from the
   * publish form. The host uses it to NAME the materialized pack (so e.g. the
   * published theme pack's `name` matches what the user typed, instead of a
   * generic placeholder). Absent ⇒ the host derives a sensible default.
   */
  package(input: {
    kind: HostInAppContentKind;
    id: string;
    title?: string;
  }): Promise<HostInAppContentPackageResult>;
}
