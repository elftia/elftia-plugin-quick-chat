/**
 * host-api/session-kinds.ts — ADDITIVE v1.18 sibling module: the per-sessionType
 * BEHAVIOR registration port (`ds-extract-1c-kind-generalize`, design D3).
 *
 * A plugin that owns a session kind (e.g. Design Studio's `'design'`) declares
 * the cheap data FLAGS the host renderer's chat/panel/workspace surfaces
 * consult instead of hardcoded `sessionType === '<kind>'` literals. The host
 * backs this with its `sessionKindStore` (Zustand IoC registry, the
 * `sessionGroupStore` pattern, per-kind last-registration-wins, leak-safe
 * unregister). No registration ⇒ every consumer treats all flags as falsy ⇒
 * the kind degrades to plain-chat rendering (the R5 degradation contract).
 *
 * MINIMALITY (窄端口): one registration verb carrying a flags RECORD — no host
 * store object, no callback, no React handle crosses. The flags are exactly the
 * audited set of host branch points the `'design'` literals used to gate.
 *
 * This module imports ONLY `./_shared` (lib-agnostic; no DOM/Node type).
 *
 * @module @elftia/plugin-types/host-api/session-kinds
 */
import type { HostUnregister } from './_shared';

/**
 * The per-sessionType behavior flags a plugin declares. Structural — the host
 * store consumes this shape directly (it is data, not a lower bound of a
 * richer renderer type).
 */
export interface SessionKindBehaviorLike {
  /** The session kind this behavior applies to (e.g. `'design'`). REQUIRED. */
  readonly kind: string;
  /**
   * Whether sessions of this kind ride the AGENT runtime: `agent:event`
   * streaming subscription, files/git side tabs, and the agent-style
   * edit/regenerate branch-switch path. REQUIRED (the load-bearing flag).
   */
  readonly agentLike: boolean;
  /**
   * Collapse the input area / model picker to the plain-chat profile (the
   * former `'design' → 'chat'` session-type collapse). Only `'chat'` is
   * defined today; absent ⇒ no collapse.
   */
  readonly inputProfile?: 'chat';
  /**
   * @deprecated Workspace binding is now AGENT-keyed (the agent's
   * `workspacePreview`, resolved via the workspace registry), no longer
   * sessionType-keyed. The host no longer consumes this field; declaring it is
   * harmless (ignored) but has no effect. Kept in the published contract to
   * avoid a MAJOR bump for an optional-field removal. Do not use.
   */
  readonly workspaceView?: string;
  /**
   * Session-list organizer bucket (the panel `sessionType` grouping value,
   * e.g. `'design'`). Absent ⇒ the host's default bucket mapping.
   */
  readonly organizerBucket?: string;
  /**
   * Strip inline `<artifact>` / question-form blocks from assistant markdown
   * (they render as dedicated cards instead). Absent ⇒ no stripping.
   */
  readonly stripInlineArtifacts?: boolean;
}

/**
 * ADDITIVE v1.18 (MINOR) — the `host.sessionKinds` member: register a
 * session-kind behavior record. Routes to the host `registerSessionKind`
 * (`sessionKindStore`, per-kind last-registration-wins; a stale unregister
 * never removes a newer registration). The returned {@link HostUnregister} is
 * owner-scope-tracked by the host so disabling the plugin revokes it.
 */
export interface AgentUiSessionKinds {
  register(behavior: SessionKindBehaviorLike): HostUnregister;
}
