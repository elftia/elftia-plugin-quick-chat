/**
 * host-api/agent-config.ts — `HostAgentConfigLike`, the `host.services.agentConfig`
 * capability port (`byo-host-agent-config-port`, host-API v1.26).
 *
 * Lets a Tier-1 main plugin (the `byo-providers` plugin) read and write ONLY the
 * CLI-related `MagiConfig` sub-settings the relocated "Code CLI" UI configures —
 * `cliBackendId` / `cliTimeout` / `cliPtyMode` / `cliPtyCols` / `cliPtyRows` —
 * WITHOUT the host owning that sub-settings panel.
 *
 * ── THE GENERAL ENGINE FIELD STAYS HOST (the crux, design D2) ──
 * This port DELIBERATELY does NOT expose the general `agentBackend` field
 * (`tinyelf | cli`). Engine selection is an EXECUTION concern present
 * in ALL builds (the host's general agent-backend selector writes it directly via
 * `magi.updateConfig`); a plugin must not be able to flip the engine. The host
 * adapter whitelists ONLY the 5 cli keys and ignores/rejects any `agentBackend`
 * field on a `setCliBackendConfig` payload — so the structural shape here is
 * narrow and the adapter enforces it again at runtime ("agent def ≠ backend").
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports it.
 * No DOM type leaks in. Like the sibling BYO ports, the payload shapes are
 * STRUCTURAL LOWER BOUNDS (Node-shaped, no `@main`/`@shared` import) — the host's
 * canonical `MagiConfig` (restricted to these cli keys) is structurally
 * assignable, and the plugin re-narrows what it reads.
 *
 * @module @elftia/plugin-types/host-api/agent-config
 */

/** The CLI backend id the cli sub-settings target (`MagiConfig.cliBackendId`). */
export type HostCliBackendId = 'claude-code' | 'codex-cli' | 'gemini-cli';

/**
 * The CLI-related `MagiConfig` sub-settings the port reads/writes. EXACTLY the 5
 * cli keys the relocated sub-settings panel configures — and DELIBERATELY NOT the
 * general `agentBackend` field (that stays host-owned; the adapter rejects it).
 * Every field is optional (a fresh config has none set; a patch sets a subset).
 */
export interface HostCliBackendConfig {
  /** Which Code CLI tool the `cli` engine drives (`claude-code` / `codex-cli` / `gemini-cli`). */
  readonly cliBackendId?: HostCliBackendId;
  /** Per-turn CLI timeout in seconds (30–3600). */
  readonly cliTimeout?: number;
  /** Whether the CLI runs in PTY (pseudo-terminal) mode. */
  readonly cliPtyMode?: boolean;
  /** PTY columns (40–500) when `cliPtyMode` is on. */
  readonly cliPtyCols?: number;
  /** PTY rows (10–200) when `cliPtyMode` is on. */
  readonly cliPtyRows?: number;
  /**
   * STRUCTURALLY ABSENT — the general engine field is NOT part of this port.
   * Typed `?: never` (not merely omitted) so a payload that carried `agentBackend`
   * is a COMPILE error at the call site (the structural half of the enforcement;
   * the host adapter also strips it at runtime). Engine selection stays host-owned.
   */
  readonly agentBackend?: never;
}

/**
 * `host.services.agentConfig` — the cli-sub-settings config port.
 *
 * Both methods Zod-validate their payload (≥ the `magi:updateConfig` handler,
 * reusing the same schema fields) before delegating to the host's EXISTING
 * `magi.getConfig` / `magi.updateConfig` for EXACTLY the 5 cli keys. The general
 * `agentBackend` field is NEVER read or written through this port — the read
 * projects only the cli keys, and the write whitelists only the cli keys + drops
 * any `agentBackend` the plugin tries to supply.
 */
export interface HostAgentConfigLike {
  /**
   * Read the current CLI sub-settings (a projection of `magi.getConfig` to the 5
   * cli keys only). The general `agentBackend` field is NOT included.
   */
  getCliBackendConfig(): Promise<HostCliBackendConfig>;
  /**
   * Patch one or more CLI sub-settings (delegating to `magi.updateConfig` for the
   * whitelisted cli keys only). Any `agentBackend` field on the patch is
   * ignored/rejected — the general engine field is not writable through this port.
   * Returns status only.
   */
  setCliBackendConfig(patch: HostCliBackendConfig): Promise<{ success: boolean; error?: string }>;
}
