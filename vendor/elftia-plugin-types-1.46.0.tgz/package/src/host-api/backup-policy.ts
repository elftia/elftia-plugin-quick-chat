/**
 * host-api/backup-policy.ts — `HostBackupPolicyLike`, the NARROW write-only
 * `host.services.backupPolicy` capability port (`db-relocate-steam-backup` §3,
 * host-API v1.37).
 *
 * WHY: the Steam-specific backup behavior (fixed `<profileDir>/backups` target,
 * db-only snapshot mode, small per-device retention, auto-on-exit defaults) must
 * be INJECTED by the channel-gated Steam plugin — NOT branched on
 * `channel === 'steam'` in the open-source host. This port is the write seam: the
 * plugin PUSHES a backup policy at `activate`; the host's target / retention /
 * db-only / auto-default resolution READS the registered policy (absent a policy
 * → the official default: user-picked folder / WebDAV, full-state, disabled).
 * Mirrors the `host.services.authSession` write-only sink shape exactly.
 *
 * WRITE-ONLY / NARROW (窄端口, the `secretsWrite`/`authSession` shape): EXACTLY
 * one write verb `register(policy)` and NO read — a plugin pushes the policy but
 * cannot read the resolved target, the effective settings, or any session /
 * entitlement / channel. `register` returns an unregister teardown (last
 * registration wins; the single-slot IoC precedent).
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports it
 * (via `backend-services.ts`). Every field is a plain `string` / `boolean` /
 * `number` — no DOM/Node type, no token/secret/session field, no `@main`/
 * `electron` import.
 *
 * @module @elftia/plugin-types/host-api/backup-policy
 */
import type { HostUnregister } from './_shared';

/**
 * The wire-safe backup policy a plugin registers. Carries ONLY backup-shaping
 * config — NO token, secret, host service object, or session field.
 */
export interface BackupPolicyRegistration {
  /**
   * Absolute default backup folder (the plugin computes
   * `<profileDir>/backups`). When the user has not picked an explicit folder,
   * the host defaults the target here. A non-absolute value is dropped at the
   * host boundary (→ no policy default). Optional: a policy may shape only
   * retention / db-only / auto-defaults without pinning a folder.
   */
  readonly targetFolderPath?: string;
  /** db-only snapshot mode — the manifest entry-set becomes `['elftia.db']`. */
  readonly dbOnly: boolean;
  /** Per-device snapshots to keep (the Steam plugin registers `2`, for quota). */
  readonly retention: number;
  /**
   * Defaults applied when no machine-local auto-backup settings file exists
   * (the Steam plugin registers enabled / 6h). Absent ⇒ the host's official
   * default (disabled / 6h) applies.
   */
  readonly autoBackupDefaults?: {
    readonly autoBackupEnabled: boolean;
    readonly autoBackupIntervalHours: number;
  };
}

/**
 * `host.services.backupPolicy` — the NARROW write-only backup-policy sink port.
 * ONE write verb, no read; backed by the host's single-slot `BackupPolicyRegistry`.
 */
export interface HostBackupPolicyLike {
  /**
   * Register (last-wins) the host backup policy. The host folds the policy into
   * its single-slot registry; the target / retention / db-only / auto-default
   * resolvers read it. WRITE-ONLY: nothing about the resolved backup state is
   * returned (no target / settings / session read). Returns an
   * {@link HostUnregister} teardown that clears the slot iff this registration is
   * still the active one.
   */
  register(policy: BackupPolicyRegistration): HostUnregister;
}
