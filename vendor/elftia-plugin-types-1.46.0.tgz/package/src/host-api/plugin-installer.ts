/**
 * host-api/plugin-installer.ts — `HostPluginInstallerLike`, the NARROW
 * plugin-install `host.services.pluginInstaller` capability port
 * (`oss-channel-isolation` Phase 3 slice P3-3b-2a, host-API v1.30).
 *
 * WHY (P3 context): the channel-gated Steam plugin's MAIN half installs
 * UNTRUSTED Workshop UGC. It must NOT vendor its own installer — the host owns
 * the SINGLE guardrail-bearing `PluginInstaller` (manifest validation,
 * symlink + zip-slip + size rejection, containment-safe uninstall, Tier-1 trust
 * classification). Vendoring a copy in the plugin would DRIFT from those
 * guardrails over time — exactly the divergence this contract exists to prevent.
 * This narrow port is the seam: the plugin hands the host an on-disk source path
 * and the host runs its own install pipeline; the plugin never reaches a single
 * guardrail itself.
 *
 * SHAPE PIN (the integration crux): this interface MUST stay structurally
 * IDENTICAL to the host's `WorkshopSyncInstaller` interface
 * (`@main/.../platform/steam/workshop/workshopSync.ts`) so the relocated
 * `WorkshopService` reconciliation can consume `host.services.pluginInstaller`
 * DIRECTLY as its injected installer — no wrapper, no adapter on the plugin side.
 * `installLocal` returns ONLY the three reconciliation reads (`id` / `trust` /
 * `dir`); `trust` is a plain `string` (the host's `PluginTrust` union is
 * structurally assignable) so no host trust-enum type crosses the boundary.
 *
 * NARROW-PORT MINIMALITY (窄端口): EXACTLY the two verbs Workshop reconciliation
 * uses — `installLocal({ path })` and `uninstall(id)`. NO `inspectLocal`, no
 * `installFromGit`, no trust/signing/scan verb (those stay host/management-side;
 * the plugin installs from a Steam-resolved on-disk content dir only). The full
 * `PluginInstaller` surface is NOT republished.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports it
 * (via `backend-services.ts`). Every member uses plain `string` / record /
 * `Promise` shapes only — no DOM/Node type leaks in.
 *
 * @module @elftia/plugin-types/host-api/plugin-installer
 */

/**
 * Result of {@link HostPluginInstallerLike.installLocal}. The three fields
 * Workshop reconciliation reads off a successful install — a structural LOWER
 * BOUND of the host's `InstallResult` (which carries more; only these three
 * cross). `trust` is a plain `string` (the host `PluginTrust` union —
 * `'bundled' | 'trusted' | 'restricted'` — is assignable) so no host enum type
 * leaks into `@elftia/plugin-types`; the consumer compares it as a string
 * (e.g. `trust === 'restricted'`).
 */
export interface HostPluginInstallResult {
  /** The resolved installed plugin id (= sanitized manifest `name`). */
  readonly id: string;
  /** Trust classification, as a plain string (`'bundled'|'trusted'|'restricted'`). */
  readonly trust: string;
  /** The absolute install directory the bundle was placed in. */
  readonly dir: string;
}

/**
 * `host.services.pluginInstaller` — the NARROW host-guarded install port. EXACTLY
 * two verbs; backed by the host's single `PluginInstaller` (constructed against
 * the shared plugins-install + plugin-data roots), so every guardrail applies to
 * the plugin's installs verbatim.
 */
export interface HostPluginInstallerLike {
  /**
   * Copy-install a plugin bundle from an on-disk `source.path` through the host's
   * guarded install pipeline (manifest validation, symlink/zip-slip/size
   * rejection, trust classification). Resolves the install facts the consumer
   * reads (`{ id, trust, dir }`); rejects on a guardrail failure (the host's own
   * install error). The plugin supplies ONLY the source directory path.
   */
  installLocal(source: { path: string }): Promise<HostPluginInstallResult>;
  /**
   * Uninstall a previously installed plugin by id through the host's
   * containment-safe removal (the same path the plugin-management surface uses).
   * Synchronous, like the host installer's `uninstall`.
   */
  uninstall(id: string): void;
}
