/**
 * host-api/tool-hosts.ts — `HostToolHostsBackend`, the `host.toolHosts`
 * registration port a plugin registers a TOOL-HOST daemon descriptor through
 * (Slice S08 `08-host-owned-tool-hosts`, change `s08-pane-and-tool-host-surface`,
 * host-API v1.51).
 *
 * WHY: a "tool host" is a long-lived local daemon that owns the user's project
 * directories and serves an authenticated web editor for each one. Before this
 * port the host process could supervise such daemons (C1's
 * `ToolHostSupervisor`) but nothing outside the host could SUPPLY one — every
 * spawn would have had to be hard-coded host knowledge, exactly what the
 * plugin contract forbids. This port is the seam: the plugin's main half —
 * the code that already knows where its own runtime lives — publishes a plain
 * {@link HostToolHostDescriptorLike} at activation time, and the host takes
 * over supervision (spawn, rendezvous, ownership, idle sweep) plus the generic
 * renderer entry surface. The descriptor stays PURE DATA (loggable, diffable,
 * reviewable); the host never executes plugin code to interpret it.
 *
 * NO TOOL IDENTIFIER: nothing in this contract names a specific tool. Which
 * daemons exist is decided by which plugins register — the host surface
 * (acceptance C4) renders whatever arrives through this port.
 *
 * NARROW-PORT MINIMALITY (窄端口): EXACTLY one verb, `register`. No
 * status/stop verbs here (the host OWNS supervision; the user reaches them
 * through the host's own IPC surface, not through the registering plugin), no
 * callback handle, no host service object crossing inward. The teardown is
 * the only return value.
 *
 * WIRE-SAFETY: every field of the descriptor is JSON round-trippable —
 * strings, string arrays, plain records. No function, no `electron`/Node
 * object, no live handle. This matters even though today's registrant is
 * in-process: the descriptor must remain interpretable by a host that never
 * loads the plugin's code.
 *
 * F1 — THE FRAMING TERM (spec `tool-host-embedding`, part of this contract,
 * not decoration): the host embeds the daemon's editor in the app's web pane
 * (an iframe over the daemon's loopback HTTP endpoint). The host checks the
 * framing headers ONCE at open time, against the endpoint this descriptor's
 * `healthPath` names, and compares them with the app's own origin:
 *   - a response carrying `x-frame-options: DENY` or `SAMEORIGIN` violates;
 *   - a CSP `frame-ancestors` directive that admits NEITHER `*` NOR the app
 *     origin violates;
 *   - an unreachable/unparseable endpoint yields NO verdict (`unknown` — no
 *     warning, never a false positive).
 * A violating daemon still opens (the pane renders), but the user sees a
 * visible diagnostic instead of a silent blank frame. A daemon author who
 * intends to be embedded MUST therefore NOT send those headers from the
 * editor origin — the check reads whatever the health endpoint answers and
 * treats it as the daemon's framing policy.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module. It MUST NOT be
 * imported by `renderer.ts`; only `backend.ts` imports it. Every field is a
 * plain `string` / string-array / plain-record type — no DOM type, no
 * `electron`/Node type, no `@main`/`@shared` import.
 *
 * @module @elftia/plugin-types/host-api/tool-hosts
 */
import type { HostUnregister } from './_shared';

/**
 * One file the host writes when scaffolding a brand-new project directory.
 * WIRE-SAFE plain data. `relativePath` MUST stay inside the new project
 * directory — the host VALIDATES containment and rejects a descriptor whose
 * scaffold tries to escape (e.g. `../`-prefixed or absolute paths); a plugin
 * never gets a file write outside its tool's own project space from this port.
 */
export interface HostToolHostScaffoldFileLike {
  /** Path relative to the new project directory. Containment is validated. */
  readonly relativePath: string;
  /** File content written verbatim (UTF-8). */
  readonly content: string;
}

/** The set of files the host writes into a freshly-created project dir. */
export interface HostToolHostScaffoldSpecLike {
  readonly files: readonly HostToolHostScaffoldFileLike[];
}

/**
 * A plugin-registered tool host — the lib-agnostic structural mirror of the
 * host's internal `ToolHostDescriptor` (main
 * `services/platform/tool-hosts/types.ts`). Deliberately declared HERE
 * instead of imported: this contract imports no host source (the
 * `HostMcpProviderLike` discipline), so the two shapes evolve independently
 * and the host-side adapter VALIDATES + rebuilds its own copy at registration
 * — a plugin never hands the host a live reference to its own object graph.
 *
 * Computed by the plugin's main-half code at ACTIVATION time, from knowledge
 * only that code has (where its own runtime binary lives, where its own
 * rendezvous files live). That is what makes a data-only shape work under the
 * plugin contract's "no manifest-declared executables" rule: the manifest
 * declares nothing executable; the activated code does.
 */
export interface HostToolHostDescriptorLike {
  /**
   * Stable identifier for this tool host (e.g. the plugin's own id). Must be
   * unique among registered tool hosts — a duplicate registration FAILS
   * closed (the incumbent keeps serving). Never hard-coded by the host.
   */
  readonly toolId: string;
  /** Human-readable name for host UI surfaces. */
  readonly displayName: string;
  /** Project directories live at `<workingFolder>/<projectsDirName>/<project>/`. */
  readonly projectsDirName: string;
  project: {
    /**
     * File/dir names whose presence marks a directory as a valid project of
     * this tool. An empty list is invalid — the host could not recognize
     * (nor safely re-open) anything.
     */
    readonly markers: readonly string[];
    /**
     * The launch argument substituted for "the project": `null` ⇒ the project
     * directory itself; a string ⇒ `<projectDir>/<entryPath>`.
     */
    readonly entryPath: string | null;
    /** Files written into a project dir created through the host surface. */
    readonly scaffold: HostToolHostScaffoldSpecLike;
  };
  launch: {
    /** Executable command for the daemon. An absolute path or a resolvable command. */
    readonly command: string;
    /** Launch arguments. May contain the `{project}` placeholder (host substitutes). */
    readonly args: readonly string[];
    /** Optional working directory for the daemon. */
    readonly cwd?: string;
    /** Optional extra environment for the daemon. */
    readonly env?: Readonly<Record<string, string>>;
  };
  registry: {
    /**
     * Absolute path to the tool's OWN rendezvous index file. The host only
     * READS it (never writes); it waits for this file to name the spawned
     * daemon before considering the open successful.
     */
    readonly indexPath: string;
    /**
     * `{id}`-templated absolute path to the per-target secret file (the
     * daemon writes `{port}` + auth `{token}` there; the host reads it to
     * authenticate). MUST contain the `{id}` placeholder — a descriptor
     * without it cannot address a per-project secret and is rejected.
     */
    readonly secretPathTemplate: string;
  };
  /**
   * `{port}`/`{token}`-templated editor URL, e.g.
   * `http://127.0.0.1:{port}/session/{token}`. MUST contain BOTH
   * placeholders — the host substitutes the daemon's actual port and the
   * per-session token, and a template without them cannot produce a working
   * editor URL.
   */
  readonly editorUrlTemplate: string;
  /**
   * Root-relative path on the daemon's loopback origin the host probes
   * (token-authenticated) for liveness, identity AND the F1 framing check
   * (see the module doc's framing term). Root-relative — it must NOT carry
   * scheme/host, since the host owns the port the daemon actually took.
   */
  readonly healthPath: string;
}

/**
 * `host.toolHosts` — the registration namespace: EXACTLY one verb.
 *
 * A NAMESPACE OBJECT (the `workflow` discipline) so sibling seams, if any
 * ever land, sit beside `register` without another top-level `backend.ts`
 * member.
 *
 * FAILS CLOSED: `register` throws when the descriptor is invalid (the host
 * names the offending fields) or when `toolId` is already registered — the
 * incumbent keeps serving, last-registration never wins.
 *
 * The returned teardown is the SAME `() => void` shape as
 * `HostBackendUnregister` (`../backend`) — declared here as the lib-agnostic
 * {@link HostUnregister} primitive because `backend.ts` imports this module
 * and `_shared.ts` exists precisely to break that cycle (Decision D6). The
 * host also feeds the teardown into its per-plugin teardown drain, so
 * disabling or hot-toggling the owner revokes the registration even if the
 * plugin never calls it. Teardown UNREGISTERS the descriptor; it never stops
 * a live daemon (daemons outlive plugins — the supervisor's ownership and
 * idle sweep govern their lifetime, not the registering plugin).
 */
export interface HostToolHostsBackend {
  /**
   * Register `descriptor` as an available tool host. The host validates it
   * (structure, placeholder presence, scaffold containment), rebuilds its own
   * copy, and from then on owns every spawn/stop/list/open for this `toolId`.
   * Returns the unregister handle.
   */
  register(descriptor: HostToolHostDescriptorLike): HostUnregister;
}
