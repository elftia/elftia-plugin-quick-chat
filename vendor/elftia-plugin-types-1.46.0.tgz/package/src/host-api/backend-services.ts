/**
 * host-api/backend-services.ts — `AgentBackendHostServices`, the `host.services`
 * member of `AgentBackendHostApi` (the MAIN host API): the runtime service
 * singletons a first-party main plugin (Design Studio) needs to construct its
 * service layer inside `activate`.
 *
 * ── NARROW TYPED CONTRACTS (v1.8, `ds-standalone-contracts` Decision 5) ──
 * The A+B-audited handles DS actually consumes (`logger`, `db`, `engineDispatcher`,
 * `designSystemPluginSource`) are now NARROW PUBLISHED INTERFACES (`HostLoggerLike`
 * / `HostDbRpcLike` / `HostEngineDispatcherLike` / `HostDesignSystemSourceLike`)
 * exposing ONLY the members DS uses, instead of opaque `{ [k: string]: unknown }`
 * handles DS had to cast to host-private `@main` service classes. DS now codes
 * against these published contracts directly — it no longer imports `LoggerService`
 * / `DbRpc` / `EngineDispatcher` / `DesignSystemPluginSource` from `@main`.
 * `HostEngineDispatcherLike` imports `SpecApplicableEngine` from `@elftia/agent-spec`
 * (the engine seam). These contracts are ADDITIVE to the backend host API and
 * import NO `@main` service classes.
 *
 * The REMAINING service handles DS composes (image/video/music generation, the
 * code-cli engine, the data-pack resolver) stay opaque structural lower bounds
 * (the `HostMcpProviderLike` discipline) — they are out of A+B's scope and DS
 * still casts them to the real `@main` type at its construction boundary.
 *
 * DOM-PURITY INVARIANT (Decision D2): this is a MAIN-context module (Node/
 * Electron shapes are fine here). It MUST NOT be imported by `renderer.ts`; only
 * `backend.ts` imports it. No DOM type leaks in.
 *
 * @module @elftia/plugin-types/host-api/backend-services
 */
import type { PluginEngineSessionContext } from '@elftia/agent-spec';

import type { HostUnregister } from './_shared';
import type { HostAgentConfigLike } from './agent-config';
import type { HostArtifactStorageLike } from './artifact-storage';
import type { HostAuthSessionLike } from './auth-session';
import type {
  HostNativeDialogLike,
  HostPdfRendererLike,
  HostPlatformPathsLike,
} from './backend-native-ops';
import type { HostBackupPolicyLike } from './backup-policy';
import type { HostCliRuntimeLike } from './cli-runtime';
import type { HostCreativeLibraryLike } from './creative-library';
import type { HostInAppContentLike } from './in-app-content';
import type { HostLlmConfigLike } from './llm-config';
import type { HostLocalChannelsBackend } from './local-channels';
import type { HostManagedRuntimeLike } from './managed-runtime';
import type { HostMediaConfigLike } from './media-config';
import type { HostObjectStorageConfigLike } from './object-storage-config';
import type { HostPluginInstallerLike } from './plugin-installer';
import type { HostPluginPathsLike } from './plugin-paths';
import type { HostQuickChatSurfaceLike } from './quick-chat';
import type { HostRelayApiLike } from './relay-api';
import type { HostSearchConfigLike } from './search-config';
import type { HostSecretsPackLike } from './secrets-pack';
import type { HostSecretsWriteLike } from './secrets-write';
import type { HostSubscriptionAuthLike } from './subscription-auth';

/** Opaque structural lower bound — DS casts to the real `@main` service type. */
type HostServiceHandle = { readonly [key: string]: unknown };

// ───────────────────────────────────────────────────────────────────────────
// NARROW typed A+B service contracts (v1.8 — `ds-standalone-contracts`)
// ───────────────────────────────────────────────────────────────────────────

/**
 * Logger singleton — the NARROW members DS uses. @remarks Canonical `@main`:
 * `LoggerService`. DS use: materialization / dispatch error logging
 * (`error(msg, err?)`), plus best-effort `warn` for non-fatal persistence.
 * The host `LoggerService` is structurally assignable (it has these methods).
 */
export interface HostLoggerLike {
  /** Log an error (DS passes the message + optional `Error`). */
  error(message: string, error?: Error): void;
  /** Log a warning (optional — DS uses it for non-fatal persistence misses). */
  warn?(message: string, meta?: unknown): void;
  /** Log an info line (optional). */
  info?(message: string, meta?: unknown): void;
  /** Log a debug line (optional). */
  debug?(message: string, meta?: unknown): void;
}

/**
 * Database client singleton — the GENERIC RPC seam ONLY. @remarks Canonical
 * `@main`: `DbClient` (`DbRpc`). DS use: `DesignProjectService` ctor + the file
 * stores' id→root resolution + the session handler, all via plain channel
 * strings (`'projects:get'`, `'projects:list'`, …). Exposes ONLY `send<T>` so
 * NO typed project / DB-worker method leaks into `@elftia/plugin-types`.
 */
export interface HostDbRpcLike {
  /**
   * Invoke a DB worker channel by string id and await the typed result. Variadic
   * `...params` to match the host `DbRpc.send` (some channels take multiple
   * positional args, e.g. `send('projects:patchDesignMetadata', id, json)`); the
   * `<T>` result type is supplied by the caller. This is the GENERIC escape-hatch
   * seam ONLY — no typed project / DB-worker method is exposed.
   */
  send<T>(channel: string, ...params: unknown[]): Promise<T>;
}

/**
 * Engine dispatcher singleton — the NARROW members DS uses. @remarks Canonical
 * `@main`: `EngineDispatcher`. DS use: `getEngine(type)` to obtain an engine
 * handle for an internal design session, then `dispatch(type, ctx)` to start it.
 * `dispatch` is the start-session call DS schedules after folding the spec;
 * `ctx` is the published `PluginEngineSessionContext` subset the host's full
 * `EngineSessionContext` is structurally assignable to.
 */
export interface HostEngineDispatcherLike {
  /** Get an engine handle by type id (opaque — no spec-session methods remain). */
  getEngine(type: string): unknown;
  /** Start a session on the engine for `type` with the folded context. */
  dispatch(type: string, ctx: PluginEngineSessionContext): Promise<void>;
}

/**
 * Design-system plugin source — the NARROW members DS uses. @remarks Canonical
 * `@main`: `DesignSystemPluginSource`. DS use: `design:designSystems.listPluginSystems`
 * (`listSystems()`) + the `DesignSystemService` cache-miss body fallback
 * (`getDetail(id)` / `getBody(id)`). Result shapes are host/plugin-owned design
 * domain — typed `unknown` / `string | null` here so NO design-domain type leaks
 * into `@elftia/plugin-types`; the `DesignSystemService` consumer re-narrows the
 * `getDetail` result. (This is the design-system SOURCE's own narrow surface — it
 * is NOT the generic `HostDbRpcLike` seam, which stays `send`-only.)
 */
export interface HostDesignSystemSourceLike {
  /** List the plugin-contributed design systems (shape resolved by the consumer). */
  listSystems(): unknown;
  /** Resolve one system's detail by id on a cache miss (consumer re-narrows). */
  getDetail(id: string): Promise<unknown>;
  /** Resolve one system's frontmatter-stripped DESIGN.md body by id. */
  getBody(id: string): Promise<string | null>;
}

// ───────────────────────────────────────────────────────────────────────────
// Opaque handles for the remaining (non-A+B) composed services
// ───────────────────────────────────────────────────────────────────────────

// ───────────────────────────────────────────────────────────────────────────
// NARROW typed storage path-grant contract (v1.9 — `plugin-storage`)
// ───────────────────────────────────────────────────────────────────────────

/**
 * `host.services.storage` — the per-plugin storage PATH-GRANT service (spec
 * `plugin-storage`, v1.9). Grants directory PATHS the host resolves and lazily
 * creates; the in-process plugin performs its own I/O with `node:fs` (the
 * VSCode `storageUri` pattern — a wrapping file API would add surface without
 * adding a boundary, because main-half plugins run in-process with full Node).
 *
 * The plugin id is HOST-INJECTED at handle construction (closed over) — never a
 * caller parameter — so every resolved path is host-derived
 * (`<userData>/plugin-data/<pluginId>/`, `<projectRoot>/.elftia/<pluginId>/`).
 *
 * TRUST HONESTY (spec `plugin-storage`): these grants are DATA HYGIENE under
 * install-time trust (uninstall = remove the data dir; export = copy a dir;
 * project data colocated with the user-owned folder) — NOT a security boundary.
 * A loaded Tier-1 main-half plugin holds full Node API; the host does not (and
 * honestly cannot) police its fs access at runtime.
 *
 * @remarks Absent on a host that wired no plugin-data root (the optional-dep
 *   pattern — the plugin `activate` guards `host.services.storage`).
 */
export interface HostStorageLike {
  /**
   * Resolve + lazily create this plugin's PRIVATE data dir
   * (`<userData>/plugin-data/<pluginId>/`) and return its absolute path.
   * Removed on plugin uninstall (the hygiene contract).
   */
  dataDir(): Promise<string>;
  /**
   * Resolve + lazily create this plugin's dir INSIDE a project
   * (`<projectRoot>/.elftia/<pluginId>/`) and return its absolute path.
   * Project-colocated data lives and dies with the user-owned project folder —
   * no host cascade, orphan sweep, or deletion event is needed for it.
   * Rejects an empty or non-absolute `projectRoot`.
   */
  projectDir(projectRoot: string): Promise<string>;
}

// ───────────────────────────────────────────────────────────────────────────
// NARROW typed project lifecycle event port (v1.9)
// ───────────────────────────────────────────────────────────────────────────

/** The kind of a host-owned project row (the design-relevant subset + null). */
export type HostProjectKind = 'design' | 'workspace' | 'channel' | null;

/**
 * Payload of an `onProjectDeleted` event. Carries the deleted project id and its
 * last-known `kind` so a plugin can filter (e.g. DS ignores non-`design`) without
 * querying the already-deleted row.
 */
export interface HostProjectDeletedEvent {
  /** The deleted host-owned project id. */
  readonly id: string;
  /** The project's last known `kind` (so plugins filter without a re-query). */
  readonly kind: HostProjectKind;
}

/**
 * `host.services.projectEvents` — the NARROW host→plugin project lifecycle event
 * port (v1.9). MINIMALITY (design D5): project-COLOCATED plugin data
 * (`storage.projectDir`) needs NO event — it lives and dies with the user-owned
 * folder. But a plugin keying `dataDir()`-side caches or indexes by project id
 * has no other way to observe a host project deletion (the host deletes only
 * the project ROW), so this one optional member exists. The host emit is
 * best-effort but observable in tests.
 *
 * @remarks Implemented host-side over the `DbClient` project-deleted DB-worker
 *   notification. Absent on a host without the port (the plugin `activate`
 *   guards `host.services.projectEvents`).
 */
export interface HostProjectEventsLike {
  /** Subscribe to host project deletion; returns a teardown that unsubscribes `cb`. */
  onProjectDeleted(cb: (event: HostProjectDeletedEvent) => void | Promise<void>): HostUnregister;
}

/**
 * Image-generation service. @remarks Canonical `@main`: `ImageGenerationService`.
 * DS use: `ClaudeSdkBackendAdapter` + `DesignMediaProvider`.
 */
export type HostImageGenerationServiceLike = HostServiceHandle;

/**
 * Video-generation service. @remarks Canonical `@main`: `VideoGenerationService`.
 * DS use: `ClaudeSdkBackendAdapter` + `DesignMediaProvider`.
 */
export type HostVideoGenerationServiceLike = HostServiceHandle;

/**
 * Music-generation service. @remarks Canonical `@main`: `MusicGenerationService`.
 * DS use: `ClaudeSdkBackendAdapter` + `DesignMediaProvider`.
 */
export type HostMusicGenerationServiceLike = HostServiceHandle;

/**
 * Claude SDK engine singleton. @remarks Canonical `@main`: `ClaudeSdkEngine`.
 * DS use: `setBackendAdapterRegistry` wiring.
 */
export type HostClaudeSdkEngineLike = HostServiceHandle;

/**
 * Data-pack content-root resolver — the HOST's data-pack precedence mechanism
 * (`@main/.../plugins/pluginDirs`). The host owns "given a plugin's bundled
 * content root, which root is in effect (bundled vs an installed data pack)".
 * A plugin (e.g. Design Studio) PROVIDES its bundled root + pack id and the host
 * (CONSUMER of the data-pack mechanism) resolves — the plugin never reaches into
 * the host's platform internals. DS casts to `{ resolveContentRoot(bundledRoot,
 * packId), classifyResolution(bundledRoot, packId), resolveLockCommit(bundledRoot,
 * packId) }`. Absent on an older host ⇒ the plugin degrades to its bundled root.
 */
export type HostDataPackResolverLike = HostServiceHandle;

/**
 * `host.services` — the runtime service singletons the DS main `activate`
 * composes its service layer from. Each is the LIVE boot singleton (threaded
 * through `loadMainExtensions`), or `undefined` when a build omits it (DS
 * `activate` guards — the optional-dep pattern).
 *
 * @stability additive (MINOR) — a service-handle port. The A+B-audited handles
 *   (`logger` / `db` / `engineDispatcher` / `designSystemPluginSource`) are now
 *   narrow published interfaces (v1.8); the rest stay opaque structural lower
 *   bounds. No member was removed and no signature narrowed in a breaking way
 *   (the narrow interfaces are SUPERTYPES of what DS read off the old opaque
 *   handle via cast), so a plugin built against an earlier version still compiles.
 */
export interface AgentBackendHostServices {
  /** `LoggerService` (narrow: `HostLoggerLike`). */
  readonly logger?: HostLoggerLike;
  /** `DbClient` (`DbRpc`) — generic `send<T>` only (narrow: `HostDbRpcLike`). */
  readonly db?: HostDbRpcLike;
  /** `ImageGenerationService`. */
  readonly imageGeneration?: HostImageGenerationServiceLike;
  /** `VideoGenerationService`. */
  readonly videoGeneration?: HostVideoGenerationServiceLike;
  /** `MusicGenerationService`. */
  readonly musicGeneration?: HostMusicGenerationServiceLike;
  /** `ClaudeSdkEngine`. */
  readonly claudeSdkEngine?: HostClaudeSdkEngineLike;
  /** `DesignSystemPluginSource` (narrow: `HostDesignSystemSourceLike`). */
  readonly designSystemPluginSource?: HostDesignSystemSourceLike;
  /** `EngineDispatcher` (narrow: `HostEngineDispatcherLike`). */
  readonly engineDispatcher?: HostEngineDispatcherLike;
  /**
   * Host data-pack content-root resolver (v1.7) — a plugin provides its bundled
   * root + pack id; the host resolves which root is in effect. Lets a plugin
   * stop importing the host's `pluginDirs` platform internals directly.
   */
  readonly dataPackResolver?: HostDataPackResolverLike;
  /**
   * Per-plugin storage PATH GRANTS (v1.9 — spec `plugin-storage`): `dataDir()`
   * (`<userData>/plugin-data/<pluginId>/`, removed on uninstall) and
   * `projectDir(projectRoot)` (`<projectRoot>/.elftia/<pluginId>/`, colocated
   * with the user-owned project folder). Paths only — the in-process plugin
   * does its own `node:fs` I/O; the grants are data hygiene under install-time
   * trust, NOT a security boundary. Absent on a host without a wired
   * plugin-data root (the plugin `activate` guards). @see {@link HostStorageLike}
   */
  readonly storage?: HostStorageLike;
  /**
   * Host→plugin project lifecycle events (v1.9). `onProjectDeleted(cb)` lets a
   * plugin invalidate `dataDir()`-side per-project caches/indexes when a
   * host-owned project row is deleted (project-COLOCATED data needs no event —
   * it lives with the user-owned folder; that minimality justification is the
   * reason this port is one optional member). Absent on a host without the port
   * (the plugin `activate` guards). @see {@link HostProjectEventsLike}
   */
  readonly projectEvents?: HostProjectEventsLike;
  /**
   * Platform path/resource roots (v1.12 — `plugin-proc-isolation-p1-ds-flip`):
   * host-owned `userDataDir()` / `agentWorkspacesRootDir()` /
   * `bundledResourcesDir()` path strings. MINIMALITY: the three audited DS
   * path needs only — no generic Electron `getPath(name)` passthrough. Lets a
   * main-half plugin drop its `app` import (required before ext-host
   * execution, where Electron main APIs do not exist). Absent on an older
   * host (the plugin `activate` guards). @see {@link HostPlatformPathsLike}
   */
  readonly platformPaths?: HostPlatformPathsLike;
  /**
   * Native dialog service (v1.12): a wire-safe `showSaveDialog(options)` →
   * `{ canceled, filePath? }`. The host owns Electron's `dialog`; no dialog
   * object crosses. MINIMALITY: save-only (the audited DS export/save-as
   * need). Absent on an older host (the plugin `activate` guards).
   * @see {@link HostNativeDialogLike}
   */
  readonly nativeDialog?: HostNativeDialogLike;
  /**
   * Host PDF renderer (v1.12): `renderHtmlFileToPdf({ sourceFilePath,
   * destPath, … })` — the host loads the file in a hidden window, optionally
   * injects print CSS, prints to PDF, and writes `destPath`. MINIMALITY: one
   * file-in/file-out method; no `BrowserWindow`/`WebContents` and no PDF
   * bytes cross the boundary. Absent on an older host (the plugin `activate`
   * guards). @see {@link HostPdfRendererLike}
   */
  readonly pdfRenderer?: HostPdfRendererLike;
  /**
   * LLM-config capability port (v1.21 — `byo-port-llm-config`): provider CRUD,
   * the multi-key pool, provider presets, and the default-model router config —
   * the surface a future `byo-providers` plugin drives so the host owns no
   * BYO-key UI. Every provider/key return is renderer-MASKED (never a plaintext
   * key); writes ride `secretsWrite`. Absent on a build that does not wire the
   * LLM-config deps (the plugin `activate` guards). @see {@link HostLlmConfigLike}
   */
  readonly llmConfig?: HostLlmConfigLike;
  /**
   * Generic write-only secrets port (v1.21 — `byo-port-llm-config`): EXACTLY
   * `setSecret(ref, value): Promise<void>`, guarded by the shared BYO
   * namespace-prefix allowlist. No read/list/return-value member. Reused by the
   * media/search/subscription knives (they extend the allowlist, not the port).
   * Absent on a build that does not wire the secret store (the plugin `activate`
   * guards). @see {@link HostSecretsWriteLike}
   */
  readonly secretsWrite?: HostSecretsWriteLike;
  /**
   * Subscription / OAuth / CLI-account port (v1.22 — `byo-port-subscription-auth`):
   * OAuth flow initiation, CLI-login import, account add/remove/switch, and the
   * OpenCodeGo static-bearer subscription config — the surface a future
   * `byo-providers` plugin drives so the host owns no subscription-sign-in UI.
   * TOKEN-NEVER-CROSSES: OAuth init returns a public auth URL + `state` only (the
   * PKCE verifier stays host-side keyed by `state`); reads return sanitized
   * `has*Token` descriptors; exchange/refresh/mutate return status only. No
   * method returns an access/refresh/id/setup token or api key. Absent on a build
   * that does not wire the `TokensService` deps (the plugin `activate` guards).
   * @see {@link HostSubscriptionAuthLike}
   */
  readonly subscriptionAuth?: HostSubscriptionAuthLike;
  /**
   * Media-provider config capability port (v1.23 — `byo-port-media-config`):
   * the flat `mediaType`-discriminated surface (image/video/music/tts/asr) a
   * future `byo-providers` plugin drives so the host owns no BYO media-config
   * UI — provider CRUD, model management, default selection, upstream-model
   * refresh, and the image-only library reset. MASK-ON-RETURN: every provider
   * the port returns has `config.apiKey` stripped (structurally `?: never`); an
   * inbound key is consumed host-side and never echoed. UNLIKE the LLM knife
   * this port does NOT touch `secretsWrite` — media keys are plaintext DB
   * columns, not BYO secret-refs (the plugin writes a key via
   * `updateProvider({ apiKey })`). Absent on a build that does not wire the media
   * ConfigServices/generation services (the plugin `activate` guards).
   * @see {@link HostMediaConfigLike}
   */
  readonly mediaConfig?: HostMediaConfigLike;
  /**
   * Object-storage configuration port (v1.46). Credentials are write-only and
   * provider returns are masked; uploads stay inside the host media layer.
   */
  readonly objectStorageConfig?: HostObjectStorageConfigLike;
  /**
   * Web-search-provider config capability port (v1.24 — `byo-port-search-config`,
   * the FINAL P1 knife): the API-key search providers (tavily/jina/zhipu(+z.ai)/
   * grok/searxng/exa/bocha) a future `byo-providers` plugin configures so the host
   * owns no BYO web-search-config UI — non-secret config (`configureProvider`/
   * `configureProviders`, NO inbound key), status reads (`getProviders`/
   * `getProviderConfig`/`isProviderEnabled`/`validate`), and a thin
   * `setProviderKey`. NO-SEARCH-KEY-ON-RETURN: `getProviderConfig`'s `apiKey` is
   * structurally `?: never`; `setProviderKey` returns status only. UNLIKE the media
   * knife (DB columns) this port's key write routes through the EXISTING guarded
   * `secretsWrite` path — the `search-provider:` namespace ALREADY in the BYO
   * allowlist (reused, not a second write port). The keyless `local-*` providers,
   * `search` query execution, and login-window verbs are NOT exposed. Absent on a
   * build that does not wire the `WebSearchService` + secret store (the plugin
   * `activate` guards). @see {@link HostSearchConfigLike}
   */
  readonly searchConfig?: HostSearchConfigLike;
  /**
   * Agent-config port for CLI sub-settings (v1.26 — `byo-host-agent-config-port`):
   * the cli-related `MagiConfig` fields (`cliBackendId`/`cliTimeout`/`cliPtyMode`/
   * `cliPtyCols`/`cliPtyRows`) the relocated "Code CLI" sub-settings panel writes,
   * via `getCliBackendConfig`/`setCliBackendConfig`. It DELIBERATELY does NOT expose
   * the general `agentBackend` engine field (engine selection stays host-owned; the
   * adapter rejects any `agentBackend` on a write). Delegates to the host's
   * `magi.getConfig`/`magi.updateConfig`. Absent on a build that does not wire the
   * magi options service (the plugin `activate` guards). @see {@link HostAgentConfigLike}
   */
  readonly agentConfig?: HostAgentConfigLike;
  /**
   * CLI runtime port (v1.26 — `byo-host-cli-runtime-port`): the Code CLI
   * availability/install/launch surface the relocated runtime UI drives —
   * `getAuthStatus` (availability descriptors, NO credential)/`setEnabled`/
   * `install`/`launchTerminal`/`listBackends`, mirroring `window.native.codeCli.*`.
   * NO-CREDENTIAL-ON-RETURN: `getAuthStatus` returns descriptors only; install/launch
   * are host-run actions returning a status envelope. Delegates to the host's
   * existing `codeCli:*` runtime. Absent on a build that does not wire the CLI
   * dispatch/availability deps (the plugin `activate` guards).
   * @see {@link HostCliRuntimeLike}
   */
  readonly cliRuntime?: HostCliRuntimeLike;
  /**
   * Encrypted credential migration-pack port (v1.27 — `byo-host-secrets-pack-port`):
   * the `.epack` export/import a future `byo-providers` plugin drives so the host
   * owns no migration-pack UI. PASSPHRASE-IN, COUNTS/PATH/STATUS-OUT: the host runs
   * the native save/open dialog + ALL encryption/decryption + the file I/O + the
   * ingest entirely main-side; the plugin passes ONLY a passphrase and receives ONLY
   * counts/path/status — the encrypted `.epack` blob, the plaintext keys/tokens, and
   * the passphrase NEVER cross to the plugin (no return type can carry them). Gated by
   * the NEW `host:secrets-pack` token, DISTINCT from `host:secrets-write` (per-ref
   * plaintext writes) — this is encrypted bulk-migration, a different capability.
   * Delegates to the host's `SecretsPackService` (the same body `secretsPack:*` uses).
   * Absent on a build that does not wire the secrets-pack deps (the plugin `activate`
   * guards). @see {@link HostSecretsPackLike}
   */
  readonly secretsPack?: HostSecretsPackLike;
  /**
   * Generic host-guarded authed-fetch port (v1.29 — `oss-channel-isolation` P3-3a):
   * EXACTLY `fetch(path, init): Promise<{ status, ok, body }>`. The HOST injects the
   * bearer access token (from its AuthSessionService) + the elftia-web base URL and
   * REJECTS any path outside the allowlist (P3-3a = `/api/v1/points/`) BEFORE any
   * network call. TOKEN-NEVER-CROSSES: the plugin supplies ONLY a host-relative
   * `path` + non-auth method/headers/body and receives ONLY raw response text +
   * status — it can neither read nor override the `Authorization` header (the host
   * strips any plugin-supplied one and sets its own last). Lets the channel-gated
   * Steam plugin's in-process main call `/api/v1/points/*` without importing core
   * internals or reading the session token. Absent on a build that does not wire the
   * auth-session token source (the plugin `activate` guards). @see {@link HostRelayApiLike}
   */
  readonly relayApi?: HostRelayApiLike;
  /**
   * Plugin-install path roots (v1.30 — `oss-channel-isolation` P3-3b-2a): three
   * SYNC read-only getters (`getPluginsRootDir` / `getPluginDataRootDir` /
   * `getUserDataDir`) returning host-resolved absolute path STRINGS. Lets the
   * channel-gated Steam plugin's in-process main resolve the SHARED
   * plugins-install + plugin-data + userData roots WITHOUT importing
   * `@main`/`ElftiaPaths`/`electron`. DISTINCT from the v1.12 `platformPaths`
   * port (DS userData/agent-workspaces/bundled-resources, async) — this is the
   * plugin-install path domain, sync. MINIMALITY: three audited getters, no
   * generic `getPath(name)` passthrough. Absent on a build that does not wire the
   * path roots (the plugin `activate` guards). @see {@link HostPluginPathsLike}
   */
  readonly pluginPaths?: HostPluginPathsLike;
  /**
   * Narrow plugin-install port (v1.30 — `oss-channel-isolation` P3-3b-2a):
   * EXACTLY `installLocal({ path })` + `uninstall(id)`, backed by the host's
   * SINGLE guardrail-bearing `PluginInstaller` (manifest validation /
   * symlink+zip-slip+size rejection / containment-safe uninstall / trust
   * classification). Lets the channel-gated Steam plugin install UNTRUSTED
   * Workshop UGC through the host's guardrails instead of vendoring + drifting a
   * copy. Shape-pinned to the host's `WorkshopSyncInstaller` so the relocated
   * `WorkshopService` consumes it directly. MINIMALITY: the two reconciliation
   * verbs only (no inspect/git/trust/scan verb). Absent on a build that does not
   * wire the installer roots (the plugin `activate` guards).
   * @see {@link HostPluginInstallerLike}
   */
  readonly pluginInstaller?: HostPluginInstallerLike;
  /**
   * Narrow write-only session-sink port (v1.31 — `oss-channel-isolation`
   * P3-3b-2b-i): EXACTLY `setSteamColorfulDlcOwned(owned)`. Lets the channel-gated
   * Steam plugin PUSH the locally-read Steam Colorful DLC ownership to the host so
   * the main-side `hasColorfulAccess()` gate reflects it. WRITE-ONLY: the port
   * exposes NO session read (no state/token/user/gate) — the plugin reports one
   * boolean it observed and the host folds it into `AuthSessionState`
   * (idempotently) + emits a state update. Backed by the host's
   * `AuthSessionService` (the SAME singleton `relayApi` draws the bearer from), so
   * there is no new boot dependency. Absent on a build that does not wire the
   * auth-session singleton (the plugin `activate` guards).
   * @see {@link HostAuthSessionLike}
   */
  readonly authSession?: HostAuthSessionLike;
  /**
   * Narrow in-app-content enumerate + package port (v1.34 —
   * `workshop-publish-in-app-content`): EXACTLY `list()` (enumerate the user's
   * publishable in-app THEMES + AGENTS — user-created + allowlisted-kind only) +
   * `package({ kind, id })` (materialize ONE item into a Workshop content dir).
   * Lets the channel-gated Steam plugin publish a user's self-created in-app
   * content through the SAME ISteamUGC upload path used for installed plugins,
   * WITHOUT reading core storage directly. The host owns enumeration
   * (built-in/bundled excluded), the secret-free export paths
   * (`exportAgent`/`exportProfile`), and the content-dir materialization; the
   * plugin only selects an id and uploads the returned dir. HARD ALLOWLIST: the
   * publishable kind is `'theme' | 'agent'` ONLY — `list()` never returns
   * `prompt-template` and `package()` THROWS for any kind outside the allowlist
   * (the Steam-review guardrail enforced at the host boundary). Absent on a build
   * that does not wire the agent/theme singletons (the plugin `activate` guards).
   * @see {@link HostInAppContentLike}
   */
  readonly inAppContent?: HostInAppContentLike;
  /**
   * Narrow write-only backup-policy sink port (v1.37 — `db-relocate-steam-backup`):
   * EXACTLY `register(policy)`. Lets the channel-gated Steam plugin PUSH a backup
   * policy (`{ targetFolderPath: <profileDir>/backups, dbOnly: true, retention: 2,
   * autoBackupDefaults: enabled/6h }`) so the host's target / retention / db-only
   * / auto-default resolution reads it INSTEAD of branching on
   * `channel === 'steam'`. WRITE-ONLY: the port exposes NO read (no resolved
   * target / settings / session / entitlement). Absent a policy → the official
   * default (user-picked folder / WebDAV, full-state, disabled). Absent on a
   * build that does not wire the registry (the plugin `activate` guards).
   * @see {@link HostBackupPolicyLike}
   */
  readonly backupPolicy?: HostBackupPolicyLike;
  /**
   * Narrow read-only creative-library enumerate + fetch port (v1.42 —
   * `unified-creative-library-phase2`): EXACTLY `list(scope?)` (enumerate items,
   * optionally filtered by scope) + `get(id)` (fetch ONE item by id). Lets any
   * MAIN plugin (DS, Video Studio) list + fetch shared prompt-template content
   * (image-prompt + video-prompt) from the HOST's bundled roots instead
   * of each plugin bundling its own copy. READ-ONLY — no write/create/delete
   * verb. The host owns the bundled roots and the curation; the plugin only
   * reads. Absent on a build that does not wire the `CreativeLibraryService`
   * singleton (the plugin `activate` guards). @see {@link HostCreativeLibraryLike}
   */
  readonly creativeLibrary?: HostCreativeLibraryLike;
  /**
   * Narrow read-only managed-runtime path-resolution port (v1.43 —
   * `creative-library-managed-consumption`): EXACTLY `resolvePreparedDir(id)`
   * returning the absolute path to the prepped managed-runtime dir for `id`
   * (e.g. `'creative-library'`), or `null` when absent / not-yet-prepped. Lets
   * any MAIN plugin (e.g. the html-video render wrappers) discover the
   * host-managed runtime directory the seeder has prepped, instead of guessing
   * or bundling its own. READ-ONLY — no write/create/delete verb. The host owns
   * the runtime directory lifecycle; the plugin reads the path and performs its
   * own `node:fs` I/O. Absent on a build that does not wire the
   * `ManagedRuntimePathService` singleton (the plugin `activate` guards).
   * @see {@link HostManagedRuntimeLike}
   */
  readonly managedRuntime?: HostManagedRuntimeLike;
  /**
   * Artifact storage PATH-GRANT port (v1.48 — `elftia-composition-platform`
   * Phase 2, design §13.1, Gate-0 C5): EXACTLY three lifetime-scoped
   * directory verbs — `payloadDir` / `derivedDir` / `exportsDir` — each taking
   * the host-minted `HostOpaqueArtifactLocator` (one grant can never name
   * another artifact's directory). A SIBLING of `storage?` above, NOT an
   * extension: `storage.dataDir()` is deleted on uninstall while artifact
   * directories are RETAINED on disable AND uninstall (user-ruled OQ#2), so
   * artifact storage is FORBIDDEN under the `storage.dataDir()` tree and this
   * port deliberately grants NO artifact root (`envelope.json` stays
   * host-owned and unreachable through the port). Paths only — the plugin does
   * its own `node:fs` I/O; hygiene under install-time trust, NOT a security
   * boundary (the same honesty as `storage?`). Absent on a build that does not
   * wire the artifact storage runtime (contract-only freeze; the plugin
   * `activate` guards). @see {@link HostArtifactStorageLike}
   */
  readonly artifactStorage?: HostArtifactStorageLike;
  /**
   * Owner-scoped Local Channel transport (v1.56). The host closes over the
   * verified plugin id; no method accepts a plugin principal. The flat shape is
   * extension-host wire-safe and events are attachment-addressed.
   */
  readonly localChannels?: HostLocalChannelsBackend;
  /** Selected, live, in-process Quick Chat owner's narrow native-surface request port. */
  readonly quickChatSurface?: HostQuickChatSurfaceLike;
}
