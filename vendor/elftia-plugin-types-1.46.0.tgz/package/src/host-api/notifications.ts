/**
 * host-api/notifications.ts — `HostNotificationsBackend`, the
 * `host.notifications` port a plugin raises a SYSTEM notification through
 * (Slice S08 `08-host-owned-tool-hosts`, change `s08-notifications-and-export`,
 * host-API v1.53).
 *
 * WHY: before this port, no host-API member let a plugin reach the user
 * OUTSIDE the app window — a tool-host export that finished while the user
 * was elsewhere landed silently on disk. `NotificationService` existed
 * (host-internal, CronService's channel) but was unreachable from plugin
 * code, and had no click action, so "a notification whose click opens the
 * project directory" had no mechanism at any layer. This port is the seam:
 * the plugin's main half supplies title/body plus an optional DATA-ONLY
 * action; the host shows the OS notification, attributes it, and executes
 * the action itself on click.
 *
 * NARROW-PORT MINIMALITY (窄端口): EXACTLY one verb, `notify`, returning
 * `void`. No history read, no cancel, no notification id — an id would only
 * matter for a cancel verb that does not exist; every one of those is
 * additive later if a consumer appears. Delivery is fire-and-forget: the
 * OS owns retention and display.
 *
 * THE ACTION IS DATA-ONLY (design D2, the load-bearing decision): the ONLY
 * supported shape is `{ kind: 'openPath'; path }` — plain data the HOST
 * executes (focus the main window, re-validate, `shell.openPath`). No
 * callback, handler, or executable reference ever crosses this seam, so a
 * notification MAY outlive the plugin that raised it (a click after a
 * disable runs zero plugin code) — the plugin-disable dangling-callback
 * problem is dissolved by construction, not solved with a registry. The
 * action path is validated at `notify()` time (fail-loud at the adapter
 * seam) and re-validated at click time (a gone path is a logged no-op).
 *
 * OS-SURFACE PAYLOAD DISCIPLINE (the egress lens): `title` and `body` are
 * rendered by the OPERATING SYSTEM's notification surface — screenshotable,
 * retained in notification-center history, indexed by the OS, possibly
 * shown on a lock screen. A plugin MUST NOT place tokens, credentials, or
 * credential-bearing URLs in title or body. The host does not censor
 * content (free-text filtering is infeasible and the plugin is
 * main-trusted); the `host:notifications` manifest declaration token is
 * the review signal that this capability is in play.
 *
 * WIRE-SAFETY: every field is JSON round-trippable — strings and one plain
 * discriminated record. Same trust posture as `tool-hosts.ts`: interpretable
 * by a host that never loads the plugin's code.
 *
 * EXT-HOST POSTURE (the documented `workflow`/`toolHosts` posture): the
 * member is OPTIONAL and the extension-host branch deliberately does NOT
 * wire it — the input is validated and consumed entirely on the main
 * process. A plugin guards `host.notifications?.notify(...)`; on an older
 * host or the ext-host branch the member is `undefined` and a guarded call
 * activates nothing.
 *
 * DOM-PURITY INVARIANT: a MAIN-context module, never imported by
 * `renderer.ts`; only `backend.ts` imports it. Every field is a plain
 * `string` / string-literal / plain-record type — no DOM type, no
 * `electron`/Node type, no `@main`/`@shared` import (this module imports
 * nothing at all, not even `./_shared` — it has no unregister to declare).
 *
 * @module @elftia/plugin-types/host-api/notifications
 */

/**
 * The single supported click action: open a filesystem directory with the
 * OS shell. `kind` is a literal union of one TODAY — the enumerated shape
 * is the point (a future action kind lands as a new literal, never as a
 * free-form verb string), keeping the host-side capability auditable.
 */
export interface HostNotificationAction {
  readonly kind: 'openPath';
  /**
   * Absolute path to an EXISTING DIRECTORY. Validated at `notify()` time
   * (a relative / missing / non-directory path throws at the seam, naming
   * the field) and re-validated at click time (the world may have changed;
   * a gone path is a logged no-op, never a throw).
   */
  readonly path: string;
}

/** One notification request. Wire-safe plain data, nothing executable. */
export interface HostNotificationInput {
  /** Non-empty title line, shown by the OS notification surface. */
  readonly title: string;
  /** Non-empty body text, shown by the OS notification surface. */
  readonly body: string;
  /** Optional icon path/URL, passed through to the OS notification. */
  readonly icon?: string;
  /** Optional silence flag (suppress the OS sound), passed through. */
  readonly silent?: boolean;
  /** Optional data-only click action (see {@link HostNotificationAction}). */
  readonly action?: HostNotificationAction;
}

/**
 * `host.notifications` — the notification namespace: EXACTLY one verb.
 *
 * A NAMESPACE OBJECT (the `toolHosts` discipline) so sibling seams, if any
 * ever land, sit beside `notify` without another top-level `backend.ts`
 * member.
 *
 * `void` return: fire-and-forget. The input is validated at the host
 * adapter seam — a malformed input throws an actionable diagnostic naming
 * the offending fields, never shows silently.
 */
export interface HostNotificationsBackend {
  /**
   * Show a system notification. The host injects the SOURCE attribution
   * (the registering plugin's id) itself — the input carries no source
   * field a plugin could set or forge.
   */
  notify(input: HostNotificationInput): void;
}
