/**
 * host-api/session-effects.ts — `AgentUiSessionEffects`, the ADDITIVE v1.16
 * `host.sessionEffects` member of `AgentUiHostApi`: a single REGISTER port that
 * lets a plugin contribute a PAGE-LEVEL EFFECT the HOST mounts while a session
 * of a declared kind (e.g. `'design'`) is active.
 *
 * WHY A NEW PORT (the architectural crux). Every existing renderer registration
 * surface (`hello`/`workspace`/`page`/`sessionGroup`/`chatPanel`/`newChat`) is
 * SLOT/PANEL-level — none survives a workspace-slot remount. The design-session
 * streaming bridge (`useDesignArtifactStream` + `useDesignProjectFilePreview`)
 * must mount at the chat-PAGE level ON PURPOSE: the workspace slot can mount
 * LATE (after streaming started) and unmounts on toggle, so a slot-level
 * consumer would lose every chunk that arrived during the gap. This port lets a
 * plugin register that effect while the HOST keeps owning the mount lifecycle
 * (keyed on `(kind, sessionId)`, page-level), so the bridge SURVIVES slot
 * remounts exactly as the host's own copy does today.
 *
 * 窄端口 DISCIPLINE: exposes EXACTLY ONE member — `registerSessionEffect(def):
 * HostUnregister` — the `hello`/`workspace`/`sessionGroup`/`newChat` register
 * precedent (Decision D3). The def pins `kind` + an `Effect` component; rendering
 * + the mount lifecycle stay HOST-owned. The host passes the `Effect` a
 * `HostSessionEffectContext` pinning EXACTLY the per-session inputs the design
 * page effect (`useDesignSessionEffects`) threads today (`sessionId` /
 * `projectRoot` / `projectId` / `sourceSkillId?` / `designSystemId?` / `mode?`)
 * plus a NARROW `workspace` affordance — only the 3 audited host writes the
 * design page effect performs (`setView` / `setVisible` / `setActiveArtifact`).
 * No host store object, no `htmlPreviewStore`, no React handle, no per-frame
 * callback crosses (the effect already reaches host stores via
 * `host.stores.htmlPreview` / `host.agentEvents` / `host.ipc` / `host.agent`).
 *
 * DOM-PURITY INVARIANT (Decision D2 / D6): this module imports ONLY `./_shared`
 * (`HostReactNode` + `HostUnregister`). No `react` runtime dep, no `electron` /
 * `WebContents` / `node:*` type, no `@elftia/shared` import, no renderer-source
 * import. `Effect` is typed with the structural `HostReactNode` return (the
 * `WorkspaceDefinitionLike.render` / `AgentPageDefinitionLike.render` precedent
 * — a component-shaped method whose return is the lib-agnostic node, so the host
 * produces the component via `host.react`, no `react` dep in this package). The
 * context is a structural LOWER BOUND — it pins only the inputs the design page
 * effect reads and leaves the rest opaque (`[key: string]: unknown`).
 *
 * @module @elftia/plugin-types/host-api/session-effects
 */
import type { HostReactNode, HostUnregister } from './_shared';

/**
 * The active-artifact payload `setActiveArtifact` accepts (the manual
 * preview-card click path). Mirrors the host html-preview setter input the
 * design page effect builds from a `readBody` result — `id` + `kind` + `html`
 * required, `title` optional. `kind` is a plain `string` (the design-domain kind
 * union stays renderer-owned; this contract is a lower bound).
 */
export interface HostActiveArtifactPayload {
  /** The artifact id whose body is being activated. REQUIRED. */
  readonly id: string;
  /** The artifact kind (e.g. `'html'`); the design-domain union stays opaque. REQUIRED. */
  readonly kind: string;
  /** Optional display title. */
  readonly title?: string;
  /** The artifact body HTML to activate in the html-preview pane. REQUIRED. */
  readonly html: string;
}

/**
 * The NARROW workspace affordances a registered session effect performs. Pins
 * EXACTLY the 3 host writes `useDesignSessionEffects` makes — route the
 * workspace to a named view, show/hide the workspace pane, and activate a
 * fetched artifact body — so NO host store object (`workspaceStore` /
 * `htmlPreviewStore`) crosses the boundary; the host owns these setters.
 */
export interface HostSessionEffectWorkspace {
  /** Route the workspace to a named view (e.g. `'designStudio'`). */
  setView(view: string): void;
  /** Show/hide the workspace pane. */
  setVisible(visible: boolean): void;
  /** Activate a fetched artifact body in the html-preview pane (manual preview). */
  setActiveArtifact(payload: HostActiveArtifactPayload): void;
}

/**
 * Structural LOWER BOUND of the host page-level context the host threads into a
 * registered session effect while a session of the declared kind is active.
 * Pins EXACTLY the per-session inputs the design page effect
 * (`useDesignSessionEffects`) consumes today; everything else stays opaque
 * (`[key: string]: unknown`).
 *
 * @remarks The effect reaches host STORES itself (`host.stores.htmlPreview` /
 *   `host.agentEvents` / `host.ipc` / `host.agent`); this context only supplies
 *   the per-session inputs the HOST knows + the 3 workspace writes the HOST owns
 *   (which a `plugin://` bundle cannot reach).
 */
export interface HostSessionEffectContext {
  /** The active session id (the effect filters/subscribes on this). REQUIRED. */
  readonly sessionId: string;
  /** Project root on disk (absolute), or null. REQUIRED (nullable). */
  readonly projectRoot: string | null;
  /** Resolved host project id (`dp_<uuid>`), or null until resolved. REQUIRED (nullable). */
  readonly projectId: string | null;
  /** Active skill pin to stamp on persisted artifacts. */
  readonly sourceSkillId?: string;
  /** Active design-system pin. */
  readonly designSystemId?: string;
  /** Picker-selected mode (`'prototype'|'deck'|'template'|'design-system'|…`). */
  readonly mode?: string;
  /**
   * Narrow workspace affordances the auto-open / manual-preview paths use. Pins
   * ONLY the 3 host writes `useDesignSessionEffects` performs — no host store
   * object crosses. REQUIRED.
   */
  readonly workspace: HostSessionEffectWorkspace;
  /** Remaining members are opaque / additively extensible — see source. */
  readonly [key: string]: unknown;
}

/**
 * Structural LOWER BOUND of a registered page-level session effect. Pins the
 * REQUIRED `kind` (the session kind it applies to) + `Effect` (the host-mounted
 * component). The `Effect` renders nothing visible — it mounts the plugin's
 * port-backed hooks — and the host mounts it (keyed on `(kind, sessionId)`) at
 * the chat-page level while a session of `kind` is active, so it SURVIVES
 * workspace-slot remounts.
 *
 * `Effect` is a component-shaped method whose return is the structural
 * `HostReactNode` (the `WorkspaceDefinitionLike.render` / `AgentPageDefinitionLike.render`
 * precedent — no `react` runtime dep in this package): the host renders it via
 * `host.react` — one React instance, no second copy. Everything else stays
 * opaque (`[key: string]: unknown`).
 */
export interface SessionEffectDefinitionLike {
  /** The session kind this effect runs for (e.g. `'design'`). REQUIRED. */
  readonly kind: string;
  /**
   * The effect component the host mounts (keyed on `(kind, sessionId)`) at the
   * chat-page level while a session of `kind` is active, passing the
   * {@link HostSessionEffectContext}. Returns a host node (usually `null`).
   * REQUIRED.
   */
  Effect(props: { ctx: HostSessionEffectContext }): HostReactNode;
  /** Remaining members are opaque — see source. */
  readonly [key: string]: unknown;
}

/**
 * `host.sessionEffects` — register a page-level effect the HOST runs while a
 * session of a declared kind is active. The single registration verb; rendering
 * + mount lifecycle stay host-owned (the host keeps the effect alive across
 * workspace-slot remounts). Mirrors the `host.hello`/`workspace`/`sessionGroup`
 * register precedent (Decision D3).
 *
 * @stability frozen (the BACKING `sessionEffectStore` registry is the contract)
 */
export interface AgentUiSessionEffects {
  /**
   * Register a page-level session effect.
   * @remarks Routes to `registerSessionEffect(def)` (the host
   *   `sessionEffectStore`, per-kind last-registration-wins). The returned
   *   unregister is leak-safe (a stale unregister never removes a newer def for
   *   the same kind).
   */
  registerSessionEffect(def: SessionEffectDefinitionLike): HostUnregister;
}
