/** Non-secret configuration for one host-managed object storage provider. */
export interface HostObjectStorageProviderConfig {
  readonly bucket: string;
  readonly region?: string;
  readonly endpoint?: string;
  readonly prefix?: string;
  readonly publicBaseUrl?: string;
  readonly urlMode: 'signed' | 'public';
  readonly expiresInSeconds?: number;
  readonly forcePathStyle?: boolean;
}

/** Masked provider descriptor. Credentials never cross this port. */
export interface HostObjectStorageProvider {
  readonly id: string;
  readonly name: string;
  readonly description: string;
  readonly kind: 's3' | 'oss';
  readonly builtin: true;
  readonly isDefault: boolean;
  readonly configured: boolean;
  readonly ready: boolean;
  readonly config: HostObjectStorageProviderConfig;
  readonly accessKeyId?: never;
  readonly secretAccessKey?: never;
  readonly sessionToken?: never;
}

export type HostObjectStorageProviderPatch = Partial<HostObjectStorageProviderConfig>;

/** Write-only credentials. Empty/omitted fields leave the stored value unchanged. */
export interface HostObjectStorageCredentialsInput {
  readonly accessKeyId?: string;
  readonly secretAccessKey?: string;
  readonly sessionToken?: string;
}

export interface HostObjectStorageMutationResult {
  readonly success: boolean;
  readonly provider?: HostObjectStorageProvider;
  readonly error?: string;
}

/** `host.services.objectStorageConfig` — BYO object-storage configuration port. */
export interface HostObjectStorageConfigLike {
  listProviders(): Promise<readonly HostObjectStorageProvider[]>;
  updateProvider(
    id: string,
    patch: HostObjectStorageProviderPatch
  ): Promise<HostObjectStorageMutationResult>;
  setCredentials(
    id: string,
    credentials: HostObjectStorageCredentialsInput
  ): Promise<HostObjectStorageMutationResult>;
  clearCredentials(id: string): Promise<HostObjectStorageMutationResult>;
  setDefaultProvider(id: string | null): Promise<HostObjectStorageMutationResult>;
}
