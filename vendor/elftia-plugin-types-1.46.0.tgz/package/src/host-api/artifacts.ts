/**
 * host-api/artifacts.ts — `host.artifacts`, the Artifact layer's two process
 * handles (composition platform Phase 2, design §10/§11/§13 + §37 D3/D22).
 *
 * ---------------------------------------------------------------------------
 * THE D3 SPLIT — TWO HANDLES, ONE MODULE (design §37 D3, restated 2026-08-12;
 * member assignment frozen 2026-08-14, Gate-0 C2)
 * ---------------------------------------------------------------------------
 * Unlike `host.capabilities` (one interface, both halves), the artifact
 * namespace MUST split: {@link HostArtifactsMain} carries the main-side data
 * plane (`registerKind` / `create` / `getSummary` / `subscribeSummary`),
 * {@link HostArtifactsRenderer} carries the React-shaped members
 * (`surfaces`, {@link HostArtifactsRenderer.ArtifactView}). `open` appears on
 * BOTH halves verbatim — one pure-data signature (C2: the member-level
 * application of D3's own "no React/DOM/Node-specific type ⇒ do not split"
 * rule, the same rule that keeps `HostCapabilities` whole). The split lives in
 * WHICH host API exposes which handle (`backend.ts` vs `renderer.ts`), not in
 * two modules: every type here is lib-agnostic (the React-ness is confined to
 * `_shared.ts`'s deliberately-structural `HostComponentType`), so one sibling
 * module — the `HostCapabilities` precedent — avoids forking the vocabulary.
 * The assignment table is pinned MECHANICALLY by cross-half `@ts-expect-error`
 * absence probes in both `__smoke__` fixtures (a structural
 * `HostComponentType` member on the wrong half compiles everywhere; tsc is
 * blind to that class by design) and by the half-purity gate test
 * (`hostApiHalfPurity.test.ts`: lib-stripped compile + import-closure
 * denylist).
 *
 * ---------------------------------------------------------------------------
 * FROZEN SURFACE (design D21 discipline, applied to Phase 2)
 * ---------------------------------------------------------------------------
 * Main: `registerKind` / `create` / `getSummary` / `subscribeSummary` / `open?`.
 * Renderer: `surfaces.register` / `ArtifactView` / `open?`. Renderer data-plane
 * verbs are deliberately ABSENT — the slices 4–8 renderer consumers (canvas
 * card, missing-provider UI) read summaries through the host-rendered
 * `ArtifactView`, not by fetching them; a renderer `getSummary` is additive
 * later if a real consumer appears. Surface registry verbs beyond `register`
 * (`list` / `explain` / `observe`) are NOT frozen — no consumer exists.
 *
 * DOM-PURITY INVARIANT (Decision D2): no `electron` / `WebContents` / `node:*`
 * / `react` type is referenced here. The context's cancellation signal is the
 * STRUCTURAL {@link HostAbortSignalLike} — the repo's `tsconfig.base.json`
 * ships `lib: [ES2022, DOM, DOM.Iterable]`, so a bare `AbortSignal` WOULD have
 * compiled on the main half while quietly violating freeze-checklist rule 3
 * (the Phase-1 trap; now mechanically enforced by the purity gate).
 *
 * STRUCTURAL RESTATEMENT (the `new-chat.ts` / `agent.ts` discipline): this
 * package declares NO runtime dependencies and imports no `@elftia/shared`
 * type. The shapes below are structural lower bounds of the canonical wire
 * contract, kept identical on purpose and smoke-pinned.
 * @remarks Canonical source: `@elftia/shared`
 * `contracts/artifact-composition.ts` (host-private). Names: canonical `X` ↔
 * plugin `HostX`.
 *
 * @module @elftia/plugin-types/host-api/artifacts
 */

import type {
  HostComponentType,
  HostReactNode,
  HostUnregister,
} from './_shared';
import type { HostAbortSignalLike, HostWireValue } from './capabilities';

// ───────────────────────────────────────────────────────────────────────────
// Data restatement — identity (design §10.1)
// ───────────────────────────────────────────────────────────────────────────

/** Where an Artifact lives. @remarks Canonical: `ArtifactScope`. */
export type HostArtifactScope =
  | { readonly type: 'project'; readonly id: string }
  | { readonly type: 'session'; readonly id: string }
  | { readonly type: 'library'; readonly id: string };

/**
 * A structured-clone-safe Artifact identity. Carries NO provider id and NO
 * revision — the ref stays valid when its Provider is missing and can be
 * stored anywhere a plain value can.
 * @remarks Canonical: `ArtifactRef` (invariants §10.1 / D4).
 */
export interface HostArtifactRef {
  readonly protocol: 'elftia.artifact/v1';
  readonly kind: string;
  readonly artifactId: string;
  readonly scope: HostArtifactScope;
}

/**
 * A wire-safe slot reference into artifact storage — scheme discriminator +
 * artifact identity, NEVER a path. The HOST mints it (into
 * {@link HostArtifactContext}) and validates the provider-returned envelope
 * carries it verbatim; a divergent one is rejected `ARTIFACT_INPUT_INVALID`.
 * @remarks Canonical: `OpaqueArtifactLocator` (Gate-0 C3).
 */
export interface HostOpaqueArtifactLocator {
  readonly storage: 'elftia.artifact-storage/v1';
  readonly ref: HostArtifactRef;
}

// ───────────────────────────────────────────────────────────────────────────
// Data restatement — state + projections (design §10.2/§10.3)
// ───────────────────────────────────────────────────────────────────────────

/**
 * The ONE six-member artifact state union, used by BOTH the envelope and the
 * summary (Gate-0 C6: `tombstoned` and `migration-required` are each reachable
 * in both projections — the original two five-member unions were drafting
 * drift, not semantics).
 * @remarks Canonical: `ArtifactState`.
 */
export type HostArtifactState =
  | 'ready'
  | 'busy'
  | 'error'
  | 'provider-missing'
  | 'tombstoned'
  | 'migration-required';

/**
 * The host-managed light envelope. `providerPluginId` is the sticky Provider
 * binding (kept OUT of the ref). `payloadLocator` MUST equal the locator the
 * host minted into the provider's context — the host validates it verbatim.
 * @remarks Canonical: `ArtifactEnvelope`.
 */
export interface HostArtifactEnvelope {
  readonly ref: HostArtifactRef;
  readonly providerPluginId: string;
  readonly artifactSchemaVersion: number;
  readonly revision: number;
  readonly createdAt: number;
  readonly updatedAt: number;
  readonly state: HostArtifactState;
  readonly payloadLocator: HostOpaqueArtifactLocator;
}

/** A display badge on a summary card. @remarks Canonical: `ArtifactBadge`. */
export interface HostArtifactBadge {
  readonly id: string;
  readonly label: string;
  readonly tone?: 'neutral' | 'info' | 'warning' | 'danger';
}

/**
 * The stable low-cost projection for caching and degraded display — NOT a
 * full snapshot.
 * @remarks Canonical: `ArtifactSummary`.
 */
export interface HostArtifactSummary {
  readonly ref: HostArtifactRef;
  readonly revision: number;
  readonly title: string;
  readonly subtitle?: string;
  readonly thumbnailUrl?: string;
  readonly durationTicks?: number;
  readonly state: HostArtifactState;
  readonly badges?: readonly HostArtifactBadge[];
}

// ───────────────────────────────────────────────────────────────────────────
// Data restatement — kind declaration + error vocabulary (design §10.4)
// ───────────────────────────────────────────────────────────────────────────

/** What a surface may be asked to act as. @remarks Canonical: `ArtifactSurfaceRole`. */
export type HostArtifactSurfaceRole =
  | 'card'
  | 'thumbnail'
  | 'preview'
  | 'embed'
  | 'editor'
  | 'inspector'
  | 'dialog'
  | `plugin:${string}`;

/**
 * A kind's declaration, handed to {@link HostArtifactsMain.registerKind}.
 * `kind` is stable and namespaced; `dataCapabilityId` names the Capability
 * whose Provider owns the payload schema.
 * @remarks Canonical: `ArtifactKindDefinition`.
 */
export interface HostArtifactKindDefinition {
  readonly kind: string;
  readonly currentSchemaVersion: number;
  /** SemVer RANGE of schema versions the provider can READ (not write). */
  readonly readableSchemaRange: string;
  readonly defaultSurfaceRole: HostArtifactSurfaceRole;
  readonly supportedSurfaceRoles: readonly HostArtifactSurfaceRole[];
  readonly dataCapabilityId: string;
}

/**
 * The closed 9-member artifact error vocabulary (the `HostWorkflowErrorCode`
 * restatement precedent — a type union, not a runtime tuple). Callers branch
 * on the code, never on a message string. NO destroy code: the v1 surface has
 * no host destroy verb (§10.6's flow is host-internal + the provider's
 * optional `destroy?`); Phase 1's lesson is to freeze no code without a
 * producer.
 * @remarks Canonical: `ArtifactErrorCode` / `ARTIFACT_ERROR_CODES` (which also
 * ships the `isArtifactErrorCode` narrow guard).
 */
export type HostArtifactErrorCode =
  | 'ARTIFACT_NOT_FOUND'
  | 'ARTIFACT_KIND_UNKNOWN'
  | 'ARTIFACT_KIND_CONFLICT'
  | 'ARTIFACT_INPUT_INVALID'
  | 'ARTIFACT_SCOPE_INVALID'
  | 'ARTIFACT_PROVIDER_MISSING'
  | 'ARTIFACT_PROVIDER_FAILED'
  | 'ARTIFACT_STATE_INVALID'
  | 'ARTIFACT_SURFACE_NOT_FOUND';

// ───────────────────────────────────────────────────────────────────────────
// Data restatement — surface protocol shapes (design §11.2–§11.4, C3/C4)
// ───────────────────────────────────────────────────────────────────────────

/** Who owns interaction inside a surface's bounds. @remarks Canonical: `SurfaceInteractionMode`. */
export type HostSurfaceInteractionMode = 'passive' | 'focused' | 'full';

/** Where a surface can be placed. @remarks Canonical: `ArtifactSurfacePlacement`. */
export type HostArtifactSurfacePlacement =
  | 'inline'
  | 'canvas'
  | 'chat-workspace'
  | 'page'
  | 'dialog';

/**
 * The pure-identity render context (Gate-0 C3). NO DOM handle ever appears
 * here — no `HTMLElement`, no pointer/keyboard/wheel/focus event types, no
 * `ResizeObserver`, no ref objects; §11.7's host-side mechanics stay
 * host-side. A future affordance lands as an additive data/callback member.
 * @remarks Canonical: `ArtifactSurfaceContext`.
 */
export interface HostArtifactSurfaceContext {
  readonly surfaceId: string;
  readonly pluginId: string;
}

/** The data props a surface renders from. @remarks Canonical: `ArtifactSurfaceProps`. */
export interface HostArtifactSurfaceProps {
  readonly artifact: HostArtifactRef;
  readonly role: HostArtifactSurfaceRole;
  readonly interaction: HostSurfaceInteractionMode;
  readonly active: boolean;
  readonly focused: boolean;
  readonly bounds?: {
    readonly width: number;
    readonly height: number;
    readonly scale: number;
  };
  readonly initialState?: HostWireValue;
}

/**
 * A surface's registration, handed to {@link HostArtifactSurfaces.register}
 * (Gate-0 C4 — the single frozen entry point; the registry runtime and the
 * §11.6 selection implementation belong to the surface-registry slice, which
 * also owns the deferred duplicate-`surfaceId` policy, C1).
 * @remarks Canonical: `ArtifactSurfaceDefinition`.
 */
export interface HostArtifactSurfaceDefinition {
  readonly id: string;
  readonly artifactKinds: readonly string[];
  readonly roles: readonly HostArtifactSurfaceRole[];
  readonly placements: readonly HostArtifactSurfacePlacement[];
  readonly features?: readonly string[];
  render(
    props: HostArtifactSurfaceProps,
    context: HostArtifactSurfaceContext
  ): HostReactNode;
}

// ───────────────────────────────────────────────────────────────────────────
// Data restatement — open (design §11.5, C2)
// ───────────────────────────────────────────────────────────────────────────

/** Caller-requested open semantics. @remarks Canonical: `ArtifactOpenOptions`. */
export interface HostArtifactOpenOptions {
  readonly role?: 'preview' | 'editor';
  /** `'auto'` asks the host to resolve the disposition. */
  readonly disposition?: 'workspace' | 'page' | 'dialog' | 'auto';
  readonly focus?: {
    readonly entityId?: string;
    readonly timeTicks?: number;
  };
  readonly initialState?: HostWireValue;
}

/**
 * The RESOLVED outcome of `open`. `disposition` never carries `'auto'` (the
 * host resolved it); `surfaceId` / `providerPluginId` are absent when the
 * §10.7 generic Missing Provider placeholder rendered — the provider-missing
 * branch RESOLVES, never rejects (C2 / §39).
 * @remarks Canonical: `ArtifactOpenResult`.
 */
export interface HostArtifactOpenResult {
  readonly disposition: 'workspace' | 'page' | 'dialog';
  readonly surfaceId?: string;
  readonly providerPluginId?: string;
}

// ───────────────────────────────────────────────────────────────────────────
// Behavioural half (lives ONLY here — Phase 1's canonical/data split)
// ───────────────────────────────────────────────────────────────────────────

/**
 * The provider call context, mirroring `HostInjectedCapabilityContext`'s
 * trust split.
 *
 * READ THIS BEFORE TRUSTING A FIELD — the members are NOT equally trustworthy:
 *   HOST-DERIVED (a caller cannot influence these; the host stamps them from
 *   the registration it already holds): `providerPluginId`,
 *   `consumerPluginId?`, `traceId`, `signal`, and the host-MINTED `ref` +
 *   `payloadLocator`.
 *   CALLER-ASSERTED (the caller supplies these and the host forwards them
 *   verbatim): `projectId?`, `sessionId?` — ROUTING HINTS, never
 *   authorization boundaries. A provider that scopes stored data by
 *   `context.projectId` on that sentence's strength lets any caller read or
 *   write another project's data by passing a different id; a trustworthy
 *   project identity must be derived from `consumerPluginId` plus the
 *   provider's own records.
 *
 * The provider MUST copy `payloadLocator` verbatim into its returned envelope
 * (the host validates it — see {@link HostOpaqueArtifactLocator}).
 */
export interface HostArtifactContext {
  /** HOST-DERIVED. */
  readonly providerPluginId: string;
  /** HOST-DERIVED. */
  readonly consumerPluginId?: string;
  /** HOST-DERIVED. */
  readonly traceId: string;
  /**
   * HOST-DERIVED. Structural cancellation signal — never a bare DOM
   * `AbortSignal` (the Phase-1 lib trap; see the module header). A real
   * `AbortSignal` is assignable to it.
   */
  readonly signal: HostAbortSignalLike;
  /** HOST-MINTED artifact identity for this call. */
  readonly ref: HostArtifactRef;
  /** HOST-MINTED slot reference (see {@link HostOpaqueArtifactLocator}). */
  readonly payloadLocator: HostOpaqueArtifactLocator;
  /** CALLER-ASSERTED — a routing hint, not an authorization boundary. */
  readonly projectId?: string;
  /** CALLER-ASSERTED — a routing hint, not an authorization boundary. */
  readonly sessionId?: string;
}

/**
 * What a kind's Provider implements and hands to
 * {@link HostArtifactsMain.registerKind}. `create` and `getSummary` are the
 * required minimum; `clone` / `migrate` / `destroy` are optional per
 * capability, not per call.
 */
export interface HostArtifactKindProvider {
  create(
    context: HostArtifactContext,
    input: HostWireValue
  ): Promise<HostArtifactEnvelope>;

  getSummary(
    context: HostArtifactContext,
    ref: HostArtifactRef
  ): Promise<HostArtifactSummary>;

  clone?(
    context: HostArtifactContext,
    ref: HostArtifactRef,
    targetScope: HostArtifactScope
  ): Promise<HostArtifactEnvelope>;

  migrate?(
    context: HostArtifactContext,
    ref: HostArtifactRef,
    targetSchemaVersion: number
  ): Promise<HostArtifactEnvelope>;

  destroy?(
    context: HostArtifactContext,
    ref: HostArtifactRef,
    expectedRevision: number
  ): Promise<void>;
}

/**
 * `host.artifacts.surfaces` — the surface registration port (Gate-0 C4).
 * EXACTLY one verb; this is the entry point the surface-registry slice
 * consumes. `list` / `explain` / `observe` are deliberately absent (D21 —
 * freeze no verb without a consumer).
 */
export interface HostArtifactSurfaces {
  /**
   * Register a surface definition. The duplicate-`surfaceId` conflict policy
   * (C1) is deliberately deferred to the registry runtime.
   */
  register(definition: HostArtifactSurfaceDefinition): HostUnregister;
}

/**
 * `host.artifacts` on the MAIN half (design §37 D3). The data plane.
 *
 * 窄端口 justification, per member (freeze-checklist rule 2):
 * - `registerKind` — the Provider side's only entry point (a kind exists when
 *   a provider registers it).
 * - `create` — the single way ANY artifact comes into existence.
 * - `getSummary` — the read projection every consumer (renderer included,
 *   via the host-rendered `ArtifactView`) eventually sees.
 * - `subscribeSummary` — live updates for the same projection; without it a
 *   busy→ready transition is invisible until the next poll.
 * - `open` — see {@link HostArtifactsRenderer.open} (C2: both halves, one
 *   signature; a main-side agent opening a workspace editor is §11.5's
 *   natural caller).
 */
export interface HostArtifactsMain {
  registerKind(
    definition: HostArtifactKindDefinition,
    provider: HostArtifactKindProvider
  ): HostUnregister;

  create(
    kind: string,
    input: HostWireValue,
    scope: HostArtifactScope
  ): Promise<HostArtifactRef>;

  getSummary(ref: HostArtifactRef): Promise<HostArtifactSummary>;

  subscribeSummary(
    ref: HostArtifactRef,
    listener: (summary: HostArtifactSummary) => void
  ): HostUnregister;

  /**
   * OPTIONAL on both halves (C2): the navigation runtime lands in a later
   * slice — the same honesty as `workflow?`. Resolves through §11.6 surface
   * selection and falls back to the §10.7 generic Missing Provider
   * placeholder (RESOLVING, not rejecting) when the provider is missing;
   * rejects only `ARTIFACT_NOT_FOUND` (unknown ref) or
   * `ARTIFACT_STATE_INVALID` (tombstoned).
   */
  open?(
    ref: HostArtifactRef,
    options?: HostArtifactOpenOptions
  ): Promise<HostArtifactOpenResult>;
}

/**
 * `host.artifacts` on the RENDERER half (design §37 D3). The React-shaped
 * members — `HostComponentType` appears here and ONLY here in this module.
 * Data-plane verbs (`getSummary` / `subscribeSummary`) are deliberately
 * ABSENT: renderer consumers read summaries through the host-rendered
 * {@link HostArtifactsRenderer.ArtifactView}, not by fetching them.
 *
 * 窄端口 justification, per member (freeze-checklist rule 2):
 * - `surfaces` — the one registration verb a surface provider needs (C4).
 * - `ArtifactView` — the one component the host renders an artifact through;
 *   every placement (canvas card, workspace, dialog) is this view with
 *   different props, so no per-placement component is frozen.
 * - `open` — see {@link HostArtifactsMain.open} (C2: both halves, one
 *   signature).
 */
export interface HostArtifactsRenderer {
  /** Same pure-data signature as the Main half (C2); OPTIONAL there too. */
  open?(
    ref: HostArtifactRef,
    options?: HostArtifactOpenOptions
  ): Promise<HostArtifactOpenResult>;

  readonly surfaces: HostArtifactSurfaces;

  readonly ArtifactView: HostComponentType<HostArtifactSurfaceProps>;
}
