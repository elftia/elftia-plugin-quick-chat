/**
 * host-api/agents.ts — the ADDITIVE v1.44 unified `host.agents.define` port
 * (`host-agents-define-infra`, design D1).
 *
 * Gives plugins a SINGLE entry point — `host.agents.define(def)` — that
 * dispatches each field of `def` to the right store/registry. The renderer half
 * (`HostAgentsUi` on `AgentUiHostApi`) dispatches behavior→sessionKindStore,
 * effect→sessionEffectStore, workspace→workspaceStore, modality→newChatStore,
 * group→sessionGroupStore. The backend half (`HostAgentsBackend` on
 * `AgentBackendHostApi`) dispatches setup→AgentSessionSetupRegistry. Both halves
 * share the same `agentId` key.
 *
 * This is the Phase-1 foundation of the unify-agent-path effort: plugins
 * currently using the spec-session path (Design Studio, Video Studio) will
 * migrate to `host.agents.define` in Phase 2, gaining the standard path's
 * permission gating, streaming, and workspace guarantees without bypassing them.
 *
 * MINIMALITY (窄端口): one `define` verb per half. Each field of the definition
 * is OPTIONAL and forwarded verbatim to the corresponding existing store — no
 * new store shape, no new callback, no host object crosses. The fields are
 * typed `unknown` (structural pass-through) so this module stays self-contained
 * (imports ONLY `./_shared`); the host factory casts each field to the concrete
 * `*Like` type its target store demands, and the plugin constructs a def whose
 * fields match those existing published types.
 *
 * DOM-PURITY INVARIANT (Decision D2): this module imports ONLY `./_shared`
 * (`HostUnregister`). No `react` runtime dep, no `electron`/Node/DOM type, no
 * `@main`/`@shared` import. The setup function shapes use plain `string` /
 * `readonly` arrays / structural records only.
 *
 * @module @elftia/plugin-types/host-api/agents
 */
import type { HostUnregister } from './_shared';

// ───────────────────────────────────────────────────────────────────────────
// Renderer-half definition (HostAgentsUi)
// ───────────────────────────────────────────────────────────────────────────

/**
 * The definition a plugin passes to the renderer-half `host.agents.define(def)`.
 * Carries `agentId` (the shared key) plus optional fields the host dispatches to
 * the corresponding stores.
 *
 * Each optional field is a structural pass-through: the plugin constructs an
 * object matching the store's published `*Like` type (e.g.
 * `SessionKindBehaviorLike` for `behavior`), and the host factory forwards it
 * verbatim. Typed `unknown` here so this module stays self-contained.
 */
export interface HostAgentUiDefinition {
  /** The agent id — the shared key across both host halves. REQUIRED. */
  readonly agentId: string;
  /**
   * Forwarded to `sessionKindStore` via `registerSessionKind({ kind: agentId,
   * ...behavior, agentId })`. Construct a `SessionKindBehaviorLike`-shaped
   * object (minus `kind`, which the host stamps from `agentId`).
   */
  readonly behavior?: unknown;
  /**
   * Forwarded to `sessionEffectStore` via `registerSessionEffect({ kind: agentId,
   * ...effect, agentId })`. Construct a `SessionEffectDefinitionLike`-shaped
   * object (minus `kind`, which the host stamps from `agentId`).
   */
  readonly effect?: unknown;
  /**
   * Forwarded to `workspaceStore` via `registerWorkspace(workspace)`. Construct a
   * `WorkspaceDefinitionLike`-shaped object.
   */
  readonly workspace?: unknown;
  /**
   * Forwarded to `newChatModalityStore` via `registerNewChatModality(modality)`.
   * Construct a `NewChatModalityDefinitionLike`-shaped object.
   */
  readonly modality?: unknown;
  /**
   * Forwarded to `sessionGroupStore` via `registerSessionGroup(group)`. Construct
   * a `SessionGroupDefinitionLike`-shaped object.
   */
  readonly group?: unknown;
}

/**
 * ADDITIVE v1.44 (MINOR) — the renderer-half `host.agents` member. `define(def)`
 * dispatches each present field to the corresponding renderer store and returns
 * a combined {@link HostUnregister} that revokes ALL registrations when called.
 */
export interface HostAgentsUi {
  define(def: HostAgentUiDefinition): HostUnregister;
}

// ───────────────────────────────────────────────────────────────────────────
// Backend-half definition (HostAgentsBackend)
// ───────────────────────────────────────────────────────────────────────────

/**
 * Structural lower bound of a chat session passed to the setup function. Pins
 * only `id` (the load-bearing field the setup fn reads); the rest is opaque so
 * this module does not lock the full session schema.
 */
export interface HostAgentSetupSession {
  /** Stable session id. */
  readonly id: string;
  /** Remaining session fields are opaque — see canonical source. */
  readonly [key: string]: unknown;
}

/** Input passed to {@link HostAgentSessionSetupFn}. */
export interface HostAgentSetupInput {
  /** The active chat session (structural lower bound — `id` pinned). */
  readonly session: HostAgentSetupSession;
  /** The agent id (same key shared across both host halves). */
  readonly agentId: string;
  /** The session's project path, or null when unbound. */
  readonly projectPath: string | null;
}

/**
 * A resolved spec-components delta the setup fn may return. Each array is
 * CONCATENATED after the agent record's resolved components (record-first,
 * setup-after). Structural — the host knows the real element shape.
 */
export interface HostAgentSetupSpecComponents {
  /** Skills to append. */
  readonly skills?: readonly unknown[];
  /** Commands to append. */
  readonly commands?: readonly unknown[];
  /** Sub-agents to append. */
  readonly subAgents?: readonly unknown[];
}

/**
 * The delta a setup function returns to enrich the session context.
 *
 * Merge semantics (design D3):
 * - `systemPromptAppend` → APPEND to the existing `systemPrompt`.
 * - `specComponents` → CONCAT after the record's resolved components.
 * - `engineConfigPatch` → shallow-merge (`Object.assign({}, existing, patch)`).
 * - `projectPath` → OVERWRITE the payload's `projectPath`.
 * - `mediaAssetOutput` → OVERWRITE (set the ctx field).
 */
export interface HostAgentSetupResult {
  /** Appended to the agent record's resolved systemPrompt. */
  readonly systemPromptAppend?: string;
  /** Shallow-merged into the engine config (`Object.assign({}, cfg, patch)`). */
  readonly engineConfigPatch?: Record<string, unknown>;
  /** Overwrites the payload's projectPath. */
  readonly projectPath?: string;
  /** Overwrites (sets) the ctx's mediaAssetOutput field. */
  readonly mediaAssetOutput?: unknown;
  /** Concatenated after the record's resolved specComponents (record-first). */
  readonly specComponents?: HostAgentSetupSpecComponents;
}

/**
 * The setup function a plugin registers via the backend-half
 * `host.agents.define({ setup })`. Called by the engineSession setup hook
 * AFTER the agent record is loaded and engineConfig/systemPrompt/specComponents
 * are derived, BEFORE the final EngineSessionContext is constructed. The
 * returned deltas are merged per {@link HostAgentSetupResult} semantics.
 *
 * If the function throws, the error is caught, logged as a warning, and the
 * session continues with record-derived values (non-fatal).
 */
export type HostAgentSessionSetupFn = (
  input: HostAgentSetupInput,
) => Promise<HostAgentSetupResult | undefined>;

/**
 * The definition a plugin passes to the backend-half `host.agents.define(def)`.
 * Carries `agentId` (the shared key) plus an optional `setup` function.
 */
export interface HostAgentBackendDefinition {
  /** The agent id — the shared key across both host halves. REQUIRED. */
  readonly agentId: string;
  /**
   * The setup function the engineSession hook calls to enrich the session
   * context. OPTIONAL — an agent without a setup fn runs with record-derived
   * values (identical to pre-change behavior).
   */
  readonly setup?: HostAgentSessionSetupFn;
}

/**
 * ADDITIVE v1.44 (MINOR) — the backend-half `host.agents` member. `define(def)`
 * registers the setup function in `AgentSessionSetupRegistry` under key
 * `agentId` and returns a {@link HostUnregister} that removes the registration.
 */
export interface HostAgentsBackend {
  define(def: HostAgentBackendDefinition): HostUnregister;
}
