/**
 * host-api/stores.ts — `AgentUiHostStores`: the NARROW per-store ports an
 * ADDITIVE v1.1 `host.stores` member exposes into the host data stores a
 * first-party code plugin (Design Studio) reads and/or writes.
 *
 * 窄端口 DISCIPLINE: each port exposes EXACTLY the members the Design Studio
 * renderer audit recorded (`agent-ui-extensions-2/planning-context.md` §F11) —
 * never the whole store. Read access follows the read-only-snapshot + subscribe
 * precedent (`buildAgentUiHostApi.projectThemeSnapshot`); write access forwards
 * the specific audited mutators. Adding a member with no verified DS call site is
 * rejected by the freeze checklist's narrow-port rule.
 *
 * DOM-PURITY INVARIANT (Decision D2): structural shapes + `_shared` primitives
 * ONLY — no `electron` / `WebContents` / `node:*` type, no `react` runtime dep.
 * Snapshot shapes are structural lower bounds; the SSOT for the store types
 * stays in the renderer source (this package imports none of it).
 *
 * @module @elftia/plugin-types/host-api/stores
 */
import type {
  HostChatSessionSettingsLike,
  HostReactNode,
  HostUnregister,
} from './_shared';

// ───────────────────────────────────────────────────────────────────────────
// htmlPreview (READ + WRITE — the richest port)
// ───────────────────────────────────────────────────────────────────────────

/**
 * Read-only snapshot of the HTML-preview state DS consumes. Structural lower
 * bound of `HtmlPreviewState` — pins only the fields DS reads, rest opaque.
 *
 * @remarks Canonical: `htmlPreviewStore.HtmlPreviewState` (`useHtmlPreview().state`).
 */
export interface HostHtmlPreviewSnapshot {
  readonly isOpen: boolean;
  readonly html: string;
  readonly title: string;
  readonly expanded: boolean;
  readonly artifactId: string | null;
  readonly baseHref?: string;
  readonly status: string;
  /** Active artifact kind (`artifactKind` in the real state; `kind` to DS). */
  readonly kind?: string | null;
  readonly onSave?: (html: string) => void;
  /**
   * ADDITIVE v1.3 — failure reason when `status === 'error'`. Mirrors the real
   * `HtmlPreviewState.errorMessage` (DS's `DesignWorkspaceSlot` reads it).
   */
  readonly errorMessage?: string;
  readonly [key: string]: unknown;
}

/** `open(options)` input — structural lower bound of `OpenPreviewOptions`. */
export interface HostHtmlPreviewOpenOptions {
  html: string;
  title: string;
  source?: string;
  onSave?: (html: string) => void;
  baseHref?: string;
  kind?: string;
  [key: string]: unknown;
}

/** `begin(input)` input — structural lower bound of `BeginInput`. */
export interface HostHtmlPreviewBeginInput {
  artifactId: string;
  kind: string;
  title?: string;
  source?: string;
  [key: string]: unknown;
}

/** `setActiveArtifact(input)` input — structural lower bound of `SetActiveArtifactInput`. */
export interface HostHtmlPreviewSetActiveArtifactInput {
  id: string;
  kind: string;
  title?: string;
  html: string;
  [key: string]: unknown;
}

/**
 * READ + WRITE port over the host HTML-preview store. Backed by
 * `htmlPreviewStore` (`useHtmlPreview` / `HtmlPreviewContextValue`). DS drives
 * the host preview pane (artifact streaming + workspace), so the 9 mutators +
 * the `getCachedBody` query each map 1:1 to a verified DS call site.
 */
export interface HostHtmlPreviewPort {
  /** Read the current preview state (frozen projection). */
  getSnapshot(): HostHtmlPreviewSnapshot;
  /** Subscribe to preview-state changes; returns an unsubscribe. */
  subscribe(listener: (snapshot: HostHtmlPreviewSnapshot) => void): HostUnregister;
  // Audited mutators (1:1 with `HtmlPreviewContextValue`).
  open(options: HostHtmlPreviewOpenOptions): void;
  close(): void;
  updateHtml(html: string): void;
  setExpanded(expanded: boolean): void;
  begin(input: HostHtmlPreviewBeginInput): void;
  appendChunk(content: string): void;
  complete(): void;
  fail(reason: string): void;
  setActiveArtifact(input: HostHtmlPreviewSetActiveArtifactInput): void;
  /** Audited query — the cached inactive-artifact body, or null. */
  getCachedBody(id: string): string | null;
}

// ───────────────────────────────────────────────────────────────────────────
// devPreview (READ-ONLY)
// ───────────────────────────────────────────────────────────────────────────

/** Structural lower bound of `DevPreviewState` (DS reads, never mutates). */
export interface HostDevPreviewState {
  readonly isActive: boolean;
  readonly status: string | null;
  readonly url: string | null;
  readonly error: string | null;
  readonly [key: string]: unknown;
}

/** Structural lower bound of a dev-server `LogEntry`. */
export interface HostDevPreviewLogEntry {
  readonly text: string;
  readonly stream: 'stdout' | 'stderr';
  readonly timestamp: number;
}

/** Read snapshot of the dev-preview store — `{ state, logs }`. */
export interface HostDevPreviewSnapshot {
  readonly state: HostDevPreviewState;
  readonly logs: readonly HostDevPreviewLogEntry[];
}

/**
 * READ-ONLY port over the host dev-server-preview store. Backed by
 * `devPreviewStore` (`useDevPreview`). DS reads `{ state, logs }` only — the
 * host's DevPreviewPanel owns writes, so this port has NO mutators.
 */
export interface HostDevPreviewPort {
  getSnapshot(): HostDevPreviewSnapshot;
  subscribe(listener: (snapshot: HostDevPreviewSnapshot) => void): HostUnregister;
}

// ───────────────────────────────────────────────────────────────────────────
// workspaceToolbar (WRITE — publish, OQ1)
// ───────────────────────────────────────────────────────────────────────────

/** A single workspace-toolbar action item (structural lower bound). */
export interface HostWorkspaceToolbarItem {
  key: string;
  label: string;
  icon: HostReactNode;
  onClick: () => void;
  active?: boolean;
  badge?: string;
  [key: string]: unknown;
}

/** Workspace-toolbar config a workspace body publishes (structural lower bound). */
export interface HostWorkspaceToolbarConfig {
  title?: string;
  viewModes?: HostWorkspaceToolbarItem[];
  actions?: HostWorkspaceToolbarItem[];
  [key: string]: unknown;
}

/**
 * WRITE port over the host workspace-toolbar mechanism. Backed by
 * `useWorkspaceToolbar` (an effect-based publish hook). OQ1-RESOLVED: exposed as
 * an imperative `publish(config): HostUnregister` (narrower than handing out the
 * hook — no React-hook-identity leak; the host implements it over the
 * `useWorkspaceToolbar` slot). The plugin calls it from inside its workspace
 * body via `host.react`; the returned `HostUnregister` clears the published slot.
 */
export interface HostWorkspaceToolbarPort {
  publish(config: HostWorkspaceToolbarConfig): HostUnregister;
}

// ───────────────────────────────────────────────────────────────────────────
// newChatHandoff (WRITE — one mutator)
// ───────────────────────────────────────────────────────────────────────────

/**
 * `requestPersonaSelect` argument — structural lower bound of
 * `PendingPersonaSelect` (the fields DS supplies).
 *
 * @remarks Canonical: `newChatHandoffStore.PendingPersonaSelect`.
 */
export interface HostPendingPersonaSelect {
  agentId?: string;
  prefill?: unknown;
  hidePicker?: boolean;
  resetPicker?: boolean;
  [key: string]: unknown;
}

/**
 * WRITE port over the new-chat-handoff store. Backed by `newChatHandoffStore`
 * (`useNewChatHandoff`) + (for `openNewChat`) the host `chatTabsStore`.
 */
export interface HostNewChatHandoffPort {
  requestPersonaSelect(arg: HostPendingPersonaSelect): void;
  /**
   * v1.6 — open a NEW chat surface, then queue `arg` as the persona-select the
   * fresh `NewChatContent` consumes. The host performs the canonical tab-flip
   * (`useOpenChatWithAgentAndPrompt`): re-target the active tab OFF any agent-page
   * onto a fresh `chat` page, drop its sessionId so `NewChatContent` mounts, queue
   * the handoff, and sync the route. A plugin page (e.g. DS Examples "Use") cannot
   * reach the host's `useChatTabs` hooks, so `requestPersonaSelect` alone is inert
   * while the active tab is the plugin's own agent-page — this does the flip the
   * plugin lacks. `arg` is the same payload `requestPersonaSelect` takes.
   */
  openNewChat(arg: HostPendingPersonaSelect): void;
  /**
   * ADDITIVE v1.41 (MINOR) — open an EXISTING chat session in the active tab.
   *
   * The same act as {@link openNewChat} with a session id instead of a persona
   * handoff: re-target the active tab onto the `chat` page and bind it to
   * `sessionId`. It lives here for the same reason `openNewChat` does — the tab
   * model is host-owned and a `plugin://` bundle cannot reach `useChatTabs`, so
   * a plugin panel linking to a session it produced has no other route.
   *
   * MINIMALITY: a VOID write taking a session id and an optional tab title. It
   * yields nothing, reads nothing, and reaches exactly the two tab mutations the
   * host's own `openSessionInChat` helper performs. It adds no way to enumerate,
   * create or delete a session — those already have their own audited ports.
   *
   * OPTIONAL, per the freeze checklist's definition of a MINOR bump. A host
   * built at `1.0.0`-`1.40.0` does not have it, and the loader proceeds to
   * `activate` a plugin whose `requiredMinor` exceeds the running host's — so a
   * caller must guard (`openSessionInChat?.(id, title)`) and hide the affordance
   * rather than throw. Same reasoning as `getProfileDir?.()`.
   *
   * @param sessionId the session to bind the active tab to.
   * @param title optional tab title; absent ⇒ the host's default.
   */
  openSessionInChat?(sessionId: string, title?: string): void;
}

// ───────────────────────────────────────────────────────────────────────────
// chat (READ-ONLY — narrow)
// ───────────────────────────────────────────────────────────────────────────

/**
 * Structural lower bound of a chat session row DS derives its design state from.
 * Pins the fields DS's `buildStateFromSession` reads; rest opaque.
 *
 * @remarks Canonical: `chatStore.Session` (a.k.a. `ChatSession`). Named
 *   `HostChatSessionRef` to avoid colliding with the main-surface
 *   `HostChatSessionLike` (`../backend.ts`) re-exported from the barrel.
 */
export interface HostChatSessionRef {
  readonly id: string;
  readonly sessionType?: string;
  readonly agentId?: string;
  readonly designConfig?: unknown;
  /**
   * v1.19 — project root path the session is bound to (`null`/absent when
   * unbound). Minimality: DS root resolution reads exactly this field
   * (previously index-signature-reachable only).
   */
  readonly projectPath?: string | null;
  /**
   * v1.19 — the session settings blob (structural lower bound; see
   * {@link HostChatSessionSettingsLike} for why it carries no index signature).
   */
  readonly settings?: HostChatSessionSettingsLike;
  readonly [key: string]: unknown;
}

/**
 * READ-ONLY port over the host chat store. Backed by `chatStore` (`useChatStore`
 * / `selectActiveSession` + session lookup). DS reads the active session id +
 * looks a session up by id; it has NO mutators (DS's own `useDesignSessionStore`
 * is package-internal and writes via `host.ipc`/`agent`, not chatStore).
 */
export interface HostChatStorePort {
  getActiveSessionId(): string | null;
  getActiveSession(): HostChatSessionRef | null;
  getSession(id: string): HostChatSessionRef | null;
  subscribe(listener: () => void): HostUnregister;
}

// ───────────────────────────────────────────────────────────────────────────
// Umbrella
// ───────────────────────────────────────────────────────────────────────────

/**
 * The `host.stores` member — the five NARROW per-store ports DS touches. Each
 * port is wired in `buildAgentUiHostApi` to its shipped store at a single cast
 * boundary (the `hello`/`workspace` precedent).
 *
 * @stability additive (MINOR) — a new port or a new audited member is MINOR;
 *   widening a port beyond audited need is rejected (窄端口).
 */
export interface AgentUiHostStores {
  /** READ + WRITE — the host HTML-preview pane (`htmlPreviewStore`). */
  htmlPreview: HostHtmlPreviewPort;
  /** READ-ONLY — the dev-server preview (`devPreviewStore`). */
  devPreview: HostDevPreviewPort;
  /** WRITE — publish a workspace toolbar (`useWorkspaceToolbar`). */
  workspaceToolbar: HostWorkspaceToolbarPort;
  /** WRITE — queue a new-chat persona-select handoff (`newChatHandoffStore`). */
  newChatHandoff: HostNewChatHandoffPort;
  /** READ-ONLY — the chat session registry (`chatStore`). */
  chat: HostChatStorePort;
}
