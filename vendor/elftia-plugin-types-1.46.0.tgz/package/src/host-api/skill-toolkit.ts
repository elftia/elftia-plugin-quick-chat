/**
 * host-api/skill-toolkit.ts — `HostToolkitsBackend`, the `host.toolkits`
 * registration port a plugin registers a SKILL-TOOLKIT through (change
 * `third-party-tool-pack-channel`, host-API v1.55).
 *
 * WHY: a skill-toolkit is a named bundle of in-process functions the model
 * reaches through the single `elftia_toolkit` MCP (`list_toolkits` /
 * `read_toolkit` / `skill_invoke`) — one schema in `tools/list` regardless of
 * how many functions the catalog holds, with the catalog itself living in the
 * toolkit's SKILL.md. Before this port the host owned every toolkit: the
 * registry appeared NOWHERE in this package, so a plugin could contribute an
 * MCP server (`registerMcpProviderFactory`, host-API v1) but had no way to
 * contribute the cheaper, prompt-flat surface beside it. This port is that
 * seam, and it is the toolkit half of the user-installable `kind:'tool-pack'`
 * channel.
 *
 * NARROW-PORT MINIMALITY (窄端口): EXACTLY one verb, `register` — the
 * `toolHosts` discipline. No `list`, `read`, `invoke`, or `unregisterByName`:
 * the HOST owns the registry and the user reaches it through the host's own
 * `elftia_toolkit` surfaces, not through the registering plugin. Revocation is
 * the returned teardown (or the host's per-plugin drain), never a second
 * method.
 *
 * OPAQUE STRUCTURAL MIRROR (the {@link import('../backend').HostMcpProviderLike}
 * discipline): {@link HostToolkitSpecLike} pins the IDENTITY members the host
 * must be able to read without executing anything — `name`, `description`,
 * `skillMarkdown`, and each `functions[].name` — and leaves the rest opaque.
 *
 * NO ZOD IN THE CONTRACT. Each function's `schema` is typed `unknown`, not
 * `ZodTypeAny`. `@elftia/plugin-types` is dependency-light by charter (it
 * declares NO runtime dependency at all), and a plugin's own validator
 * instance is not the host's — a nominal Zod type here would be a lie that
 * breaks on `instanceof` across module boundaries. What the host actually
 * needs is a callable `safeParse`, which is a STRUCTURAL fact it duck-types at
 * the registration seam.
 *
 * VALIDATE AT THE SEAM, REJECT WHOLE. Because `schema` is opaque, the host
 * checks every declared function for a callable `safeParse` BEFORE the
 * registry sees the spec, and rejects the ENTIRE spec — naming plugin id,
 * toolkit name and offending function — if any fails. The alternative
 * (register anyway, skip validation for the bad one) would route unvalidated,
 * MODEL-SUPPLIED arguments into a third-party handler running in the main
 * process; a toolkit that does not exist is strictly safer than one that
 * accepts anything. All-or-nothing is also what makes the returned teardown
 * exact: a half-registered toolkit would leave function-index entries the
 * removal could not reliably find.
 *
 * ACL IS NOT A GRANT. `ToolkitFunction.acl` is HOST-DECLARED policy on the
 * host side; a plugin-supplied `acl` on this port is not honored as a
 * privilege grant. It is opaque here precisely so it cannot read as one.
 *
 * MAIN-ONLY, DELIBERATELY. The extension-host branch does not wire this member
 * (the documented `workflow?` / `toolHosts?` posture), and here the obstacle is
 * concrete rather than general: the host's per-invocation `ToolkitCtx` carries
 * LIVE OBJECT HANDLES (`logger`, an optional media bridge) into every handler
 * call, and neither is wire-safe. Relaying a toolkit handler would need the
 * registration relay's callback-proxy treatment PLUS a per-handle decision
 * about crossing the process boundary — a larger contract question than this
 * port answers. Consequence, stated plainly: a pack that wants process
 * isolation contributes MCP SERVERS (fully relayed today); a pack contributing
 * toolkits runs its handlers in the main process — the same privilege its
 * `activate` already has, so no new privilege is granted, only no new
 * isolation is gained.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module. It MUST NOT be
 * imported by `renderer.ts`; only `backend.ts` imports it. Every member is a
 * plain `string` / array / `unknown` — no DOM type, no `electron`/Node type,
 * no `@main`/`@shared` import, no Zod reference.
 *
 * @module @elftia/plugin-types/host-api/skill-toolkit
 */
import type { HostUnregister } from './_shared';

/**
 * One callable function inside a registered toolkit — the lib-agnostic
 * structural mirror of the host's internal `ToolkitFunction`
 * (main `services/capabilities/tools/skill-toolkit/types.ts`).
 *
 * Only `name` is pinned: it is the string the model passes to `skill_invoke`
 * and the key the host's function index is built from, so the host must be
 * able to read it. `schema` and `handler` stay opaque — see the module doc for
 * why `schema` is `unknown` rather than a Zod type, and what the host checks
 * instead.
 */
export interface HostToolkitFunctionLike {
  /** Function name as referenced in SKILL.md and `skill_invoke` calls. */
  readonly name: string;
  /**
   * The argument validator. Typed `unknown` BY DESIGN (no Zod in this
   * package). The host requires it to expose a callable `safeParse(input)`
   * returning `{ success: true; data }` / `{ success: false; error }` — the
   * Zod `safeParse` shape — because the host's dispatcher calls exactly that
   * on every invocation. A function whose `schema` cannot answer `safeParse`
   * causes the WHOLE spec to be refused at the registration seam.
   */
  readonly schema: unknown;
  /** Remaining function members (`handler`, `acl`, …) are opaque — see source. */
  readonly [key: string]: unknown;
}

/**
 * A plugin-registered skill-toolkit — the lib-agnostic structural mirror of
 * the host's internal `ToolkitSpec`. Deliberately declared HERE instead of
 * imported: this contract imports no host source (the `HostMcpProviderLike`
 * discipline), so the two shapes evolve independently.
 *
 * The pinned members are exactly what the host reads WITHOUT calling plugin
 * code: `name` (registry key + `skill_invoke` selector), `description`
 * (`list_toolkits`), `skillMarkdown` (`read_toolkit`, and the body a
 * capability-preloaded toolkit contributes to the system prompt), and each
 * function's `name`.
 *
 * PROMPT SURFACE, NOT A PRIVILEGE: `skillMarkdown` is MODEL-READABLE content
 * that can reach a session's system prompt. It is a prompt-injection surface
 * the host already reasons about for its own toolkits, disclosed as part of
 * installing a code-bearing plugin (which already runs arbitrary Node in the
 * main process). It is not newly created by this port, and it is why toolkit
 * ACL is host-declared rather than read out of the markdown.
 */
export interface HostToolkitSpecLike {
  /**
   * Toolkit name — the registry key and the `skill` argument of
   * `skill_invoke`. Must be unique among registered toolkits; the host
   * refuses a duplicate (the incumbent keeps serving) and, for a
   * `kind:'tool-pack'` plugin, refuses a name the plugin's own manifest did
   * not declare.
   */
  readonly name: string;
  /** One-line summary surfaced in `list_toolkits`. */
  readonly description: string;
  /** Raw SKILL.md body returned by `read_toolkit`. See the prompt-surface note. */
  readonly skillMarkdown: string;
  /** The callable catalog. An empty catalog is a toolkit nothing can invoke. */
  readonly functions: readonly HostToolkitFunctionLike[];
  /** Remaining spec members (`category`, `references`, …) are opaque — see source. */
  readonly [key: string]: unknown;
}

/**
 * `host.toolkits` — the registration namespace: EXACTLY one verb.
 *
 * A NAMESPACE OBJECT (the `workflow` / `toolHosts` discipline) so sibling
 * seams, if any ever land, sit beside `register` without another top-level
 * `backend.ts` member.
 *
 * FAILS CLOSED: `register` throws when the spec is invalid (the host names the
 * plugin, the toolkit and the offending function), when `name` is already
 * registered — the incumbent keeps serving, last-registration never wins — or
 * when the host's declare-then-register / reserved-name rules refuse the name.
 *
 * The returned teardown is the SAME `() => void` shape as
 * `HostBackendUnregister` (`../backend`) — declared here as the lib-agnostic
 * {@link HostUnregister} primitive because `backend.ts` imports this module
 * and `_shared.ts` exists precisely to break that cycle (Decision D6). The
 * host also feeds the teardown into its per-plugin teardown drain, so
 * disabling or hot-toggling the owner unregisters the toolkit even if the
 * plugin never calls it.
 *
 * TEARDOWN IS A REGISTRY REMOVAL, NOT A CANCELLATION. The host's dispatcher
 * resolves the toolkit and function synchronously at call entry and then
 * awaits the handler, so an unregister landing mid-flight does NOT interrupt a
 * running invocation — it holds a captured reference and runs to completion,
 * side effects included. Only the NEXT invocation fails, with the registry's
 * unknown-toolkit error, which the model sees as a normal tool error.
 * Interrupting a running handler would need an abort signal on the invocation
 * context and handler cooperation; no caller may assume cancellation.
 */
export interface HostToolkitsBackend {
  /**
   * Register `spec` as an available skill-toolkit. The host validates every
   * declared function's `schema` for a callable `safeParse`, applies its
   * name rules, registers all-or-nothing, and returns the unregister handle.
   */
  register(spec: HostToolkitSpecLike): HostUnregister;
}
