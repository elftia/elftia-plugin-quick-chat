/**
 * host-api/chatPanel.ts — `AgentUiChatPanel`, the ADDITIVE v1.4 `host.chatPanel`
 * member of `AgentUiHostApi`: a register handle for the design-session Comments
 * tab renderer.
 *
 * The host receiving registry already exists — `designCommentsTabStore`
 * (`registerDesignCommentsTab`, a single-slot IoC store, last-registration-wins;
 * `ChatSessionPage` resolves the renderer for `kind='design'` sessions). This
 * member wires `activate(host)` into that registry, so the DS plugin registers
 * its comments tab through the frozen API instead of statically importing the
 * host store (which a `plugin://` bundle cannot do at runtime). Same pattern as
 * the `sessionGroup` / `hello` / `workspace` register handles.
 *
 * NAMING: `registerDesignCommentsTab` is DS-specific in the frozen API. This is
 * a first-party TRANSITIONAL register handle (honest — the host genuinely has a
 * single design-comments slot); it MAY be generalized to a generic panel
 * registry LATER additively, but no generic panel system is introduced now
 * (窄端口 — one verified consumer).
 *
 * DOM-PURITY INVARIANT (Decision D2 / D6): structural shapes + `_shared`
 * primitives ONLY — no `electron` / `WebContents` / `node:*` type, no `react`
 * runtime dep. The render-prop shape is a structural lower bound; the SSOT stays
 * the renderer source (`designCommentsTabStore`) — this package imports none of it.
 *
 * @module @elftia/plugin-types/host-api/chatPanel
 */
import type { HostReactNode, HostUnregister } from './_shared';

/**
 * Props the host passes to the registered design-comments-tab renderer.
 * Structural lower bound of the real `DesignCommentsTabRenderProps` — pins the
 * REQUIRED fields the store passes (verified to match exactly), rest opaque.
 *
 * @remarks Canonical: `designCommentsTabStore.DesignCommentsTabRenderProps`
 *   (`renderer/src/shared/state/designCommentsTabStore.ts`).
 */
export interface HostDesignCommentsTabContext {
  /** Engine type for the active session — drives the `comments.plan` IPC. */
  readonly engineType: string;
  /** Conversation id for the surgical-edit ctx. */
  readonly conversationId: string;
  /** Remaining fields are opaque — see canonical source. */
  readonly [key: string]: unknown;
}

/**
 * `host.chatPanel` — the design-session chat-panel register handle. Routes to
 * the shipped host `designCommentsTabStore` (single-slot IoC).
 *
 * @stability additive (MINOR) — a first-party transitional register handle.
 */
export interface AgentUiChatPanel {
  /**
   * Register the design-session Comments tab renderer. Routes to the host
   * `registerDesignCommentsTab` (`designCommentsTabStore`, single-slot,
   * last-registration-wins). The `render` callback receives the chat context
   * (`{ engineType, conversationId }`) and returns a host React node. Returns a
   * leak-safe unregister (HMR/teardown; production callers usually ignore it).
   */
  registerDesignCommentsTab(
    render: (ctx: HostDesignCommentsTabContext) => HostReactNode,
  ): HostUnregister;
}
