/**
 * host-api/pet-runtime.ts — `AgentUiPetRuntime`, the ADDITIVE v1.52
 * `host.petRuntime` member of `AgentUiHostApi`: the desktop-pet window's
 * runtime surface (`desktop-pet-window-runtime` D7), EXTENDED at v1.54 with an
 * OPTIONAL main-window management backing (`desktop-pet-manager-page` D2).
 *
 * 窄端口 DISCIPLINE: five REQUIRED members (v1.52, unchanged) plus ONE optional
 * management verb (v1.54) —
 *   - `subscribeFacts(listener): HostUnregister` — a read-only PUSH port (the
 *     `agentEvents` v1.15 precedent). The listener receives the freshly
 *     composed workbench facts snapshot on subscribe (initial/ready replay),
 *     on every change, and on half-TTL truth re-assertions; the snapshot
 *     remains the SOLE truth (this port never
 *     fabricates a second event stream). No filter arguments — the consumer
 *     filters by `type` client-side.
 *   - `getConfig(): Promise<HostPetRuntimeConfig>` — resolves the runtime
 *     config (enabled / current pet id / window size / presence-hidden).
 *     READ-ONLY: there is no write verb — the pet cannot re-enable itself.
 *   - `setPointerCapture(inside: boolean)` — toggles the pet window's
 *     mouse-event capture from the renderer's DOM hit-test. Boolean only; no
 *     coordinates or window handles cross.
 *   - `startDrag()` — signals drag intent; the HOST owns the native drag loop
 *     and window positioning (the renderer never moves the window).
 *   - `requestAppExit()` — the single lifecycle verb (pet context-menu exit;
 *     mirrors tray quit). No restart, hide, or settings mutation.
 *
 * DOM-PURITY INVARIANT (Decision D2 / D6): this module imports ONLY
 * `./_shared`. The payloads are structural LOWER BOUNDS — no `electron` /
 * `WebContents` / `node:*` type, no `@elftia/shared` type, no renderer-source
 * import, no `react` runtime dep. The host wires `subscribeFacts` to its
 * `pet:onFactsSnapshot` push and the verbs to the `pet:*` IPC channels (all
 * main-owned; the renderer sends only intent booleans/signals).
 *
 * Meaningfully backed ONLY in the pet window's scoped harness; invoked from a
 * main-window plugin context it is a no-op / logged degradation, never a crash
 * — EXCEPT (v1.54) the main window's construction, which promotes `getConfig`
 * to the full management shape and adds the optional `setConfig` management
 * verb (`desktop-pet-manager-page` D2③). The pet window's construction NEVER
 * gains `setConfig` — "the pet cannot re-enable itself" (child B D7) holds by
 * construction, not just by the IPC handler's sender check.
 *
 * @module @elftia/plugin-types/host-api/pet-runtime
 */
import type { HostUnregister } from './_shared';

/**
 * Structural LOWER BOUND of one workbench facts snapshot entry (child A's
 * `PetFactEntry`). Pins the four fields every consumer reads — `type` / `id` /
 * `active` / `deadline` (the absolute epoch-ms trust bound) — and leaves the
 * rest opaque (`[key: string]: unknown`). Consumers tolerate unknown fact
 * `type`s (forward compatibility).
 */
export interface HostPetFactEntryLike {
  /** Closed-enum fact discriminator (e.g. `taskCompleted` / `sessionThinking`). */
  readonly type: string;
  /** Stable per-instance key (sessionId / runId / jobId / taskId / 'app'). */
  readonly id: string;
  /** Always true in emitted entries. */
  readonly active: boolean;
  /** ABSOLUTE epoch ms — the assertion is valid until here. */
  readonly deadline: number;
  /** Bounded discriminator details; opaque-extensible. */
  readonly [key: string]: unknown;
}

/**
 * Structural LOWER BOUND of the full facts snapshot (child A's
 * `PetFactsSnapshot`). The snapshot is the SOLE truth: `subscribeFacts`
 * delivers freshly composed snapshots, never a parallel event shape.
 */
export interface HostPetFactsSnapshotLike {
  /** Protocol version (v1 = the eight-fact closed enum). */
  readonly apiVersion: number;
  /** Aggregator-local monotonic counter. */
  readonly revision: number;
  /** Epoch ms at composition time. */
  readonly generatedAt: number;
  readonly facts: ReadonlyArray<HostPetFactEntryLike>;
}

/** The resolved pet runtime config (`getConfig()` — read-only). */
export interface HostPetRuntimeConfig {
  /** Master switch state (default off ⇒ zero existing-user change). */
  readonly enabled: boolean;
  /** The A7-resolved current pet contributor id, or `null` when none exists. */
  readonly petId: string | null;
  readonly window: { readonly width: number; readonly height: number };
  /** True while an external companion presence hides the window (D8). */
  readonly presenceHidden: boolean;
  /**
   * The EXPLICIT "current pet" selection, or `null` when auto-resolved (A7).
   * Settings-surface only — present in the main-window management backing
   * (v1.54), absent in the pet-window projection (the 4-field v1.52 shape).
   */
  readonly currentPetId?: string | null;
  /**
   * Manual transparency-disabled fallback (D9). Settings-surface only —
   * present in the main-window management backing (v1.54), absent in the
   * pet-window projection.
   */
  readonly opaqueFallback?: boolean;
  /**
   * True when A7 resolved multiple contributors with no (still-valid)
   * explicit selection — the "multiple pets installed, unselected" hint.
   * Settings-surface only — present in the main-window management backing
   * (v1.54), absent in the pet-window projection.
   */
  readonly resolutionHint?: boolean;
}

/**
 * Structural LOWER BOUND of the settings-surface config patch
 * (`PetSetConfigPayloadSchema` in `@elftia/shared`, kept structural here per
 * the DOM-PURITY invariant). All fields optional — `{}` is a legitimate
 * re-scan request (the v1.54 handler refreshes contributors after every
 * management write).
 */
export interface HostPetConfigPatch {
  /** Master switch. */
  enabled?: boolean;
  /** Explicit "current pet" selection (A7); `null` clears it (back to auto). */
  currentPetId?: string | null;
  /** Manual transparency-disabled fallback (D9). */
  opaqueFallback?: boolean;
}

/**
 * `host.petRuntime` — the desktop-pet window's runtime surface. Five REQUIRED
 * members (v1.52, unchanged) plus one OPTIONAL management verb (v1.54); each
 * carries a one-line minimality justification per the freeze checklist.
 *
 * @stability additive v1.52 + v1.54 (MINOR per the freeze checklist)
 */
export interface AgentUiPetRuntime {
  /**
   * Subscribe to the workbench facts snapshot stream. The listener receives an
   * INITIAL freshly composed snapshot at subscribe time, ready-time replay,
   * every subsequent change, and half-TTL truth re-assertions. MINIMALITY:
   * read-only push, no filter args.
   */
  subscribeFacts(listener: (snapshot: HostPetFactsSnapshotLike) => void): HostUnregister;
  /**
   * Resolve the runtime config. MINIMALITY: read only. The v1.52 shape is the
   * pet-window projection; the v1.54 main-window management backing resolves
   * the same read with the optional settings-surface fields present.
   */
  getConfig(): Promise<HostPetRuntimeConfig>;
  /**
   * The settings-surface management write (v1.54). OPTIONAL because it is
   * implemented ONLY by the main-window host construction — the PET WINDOW's
   * construction never provides it, so the pet cannot re-enable itself
   * (child B D7 preserved by construction). Routes to the main-window-only
   * `pet:setConfig` IPC; the handler refreshes pet contributors after every
   * write (an empty patch `{}` is a legitimate re-scan request).
   */
  setConfig?(patch: HostPetConfigPatch): Promise<void>;
  /** Toggle mouse-event capture from the renderer's DOM hit-test. MINIMALITY: boolean only. */
  setPointerCapture(inside: boolean): void;
  /** Signal drag intent; the host owns the native drag loop. MINIMALITY: signal only. */
  startDrag(): void;
  /** The single lifecycle verb (pet context-menu exit). MINIMALITY: no restart/hide/settings. */
  requestAppExit(): void;
}
