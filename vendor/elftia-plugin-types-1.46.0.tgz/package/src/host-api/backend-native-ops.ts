/**
 * host-api/backend-native-ops.ts — the backend NATIVE-OPERATION ports
 * (`plugin-proc-isolation-p1-ds-flip`, v1.12): the narrow process-safe service
 * contracts for native operations a main-half plugin needs once its bundle no
 * longer imports `electron` — host-owned platform path resolution, the native
 * save dialog, and HTML-file-to-PDF rendering.
 *
 * WHY THESE PORTS (design D1): the Design Studio main bundle must be
 * Electron-free before it runs in a utilityProcess extension host (where
 * Electron main APIs do not exist). The host OWNS every Electron API
 * (`app.getPath`, `dialog.showSaveDialog`, `BrowserWindow`/`printToPDF`);
 * the plugin sends/receives only strings and wire-safe option/result objects,
 * so every member here crosses a MessagePort boundary unchanged.
 *
 * MINIMALITY (freeze checklist item 2): three ports, each the audited DS
 * consumption set and nothing more —
 *   - `HostPlatformPathsLike` (3 path getters): the user-data dir, the default
 *     agent-workspace root, and the host's bundled-resources root. No generic
 *     `getPath(name)` passthrough (that would republish Electron's whole path
 *     namespace).
 *   - `HostNativeDialogLike` (2 methods): a wire-safe `showSaveDialog` (v1.12,
 *     DS export saves) + `showOpenDialog` (v1.35 — the Workshop file-source pick
 *     in `workshop-publish-from-file`; a path-only file/directory picker). No
 *     message box; the open dialog returns ONLY the chosen path(s).
 *   - `HostPdfRendererLike` (1 method): render an on-disk HTML file to a PDF
 *     written at a destination path. PDF bytes never cross the boundary (the
 *     host writes the file); no `BrowserWindow`, no `WebContents`.
 *
 * DOM-PURITY INVARIANT (Decision D2): MAIN-context module — imported only by
 * `backend-services.ts`/`backend.ts`. No DOM type leaks in; the surface is
 * `string` / `number` / `boolean` / `Promise` only. No `electron` import —
 * shapes are structural.
 *
 * @module @elftia/plugin-types/host-api/backend-native-ops
 */

/**
 * `host.services.platformPaths` — host-owned platform path/resource roots
 * (v1.12). Each getter answers with an ABSOLUTE host-resolved path string;
 * the host owns the dev-vs-packaged discrimination (`app.isPackaged` /
 * `process.resourcesPath`) the plugin used to perform itself.
 *
 * @stability additive (MINOR, v1.12) — frozen once published; evolution
 *   follows the `version.ts` freeze checklist.
 */
export interface HostPlatformPathsLike {
  /** The host's user-data directory (`app.getPath('userData')`). */
  userDataDir(): Promise<string>;
  /**
   * The default agent-workspace ROOT (`<userData>/agent-workspaces`). A
   * session without a user-chosen project path defaults its workspace to
   * `<this>/<sessionId>` — the host owns the convention, the plugin joins
   * only the session segment.
   */
  agentWorkspacesRootDir(): Promise<string>;
  /**
   * The host's bundled-resources ROOT: `process.resourcesPath` in a packaged
   * build, `<repo>/resources` in dev. A plugin joins its own bundled content
   * dir name (e.g. `design-studio-builtin`) under it.
   */
  bundledResourcesDir(): Promise<string>;
}

/** One save-dialog file filter (wire-safe mirror of Electron's `FileFilter`). */
export interface HostSaveDialogFilter {
  readonly name: string;
  readonly extensions: readonly string[];
}

/** Wire-safe save-dialog request options (the audited DS subset). */
export interface HostSaveDialogOptions {
  readonly title?: string;
  readonly defaultPath?: string;
  readonly filters?: readonly HostSaveDialogFilter[];
}

/** Wire-safe save-dialog result (`{ canceled, filePath? }`). */
export interface HostSaveDialogResult {
  readonly canceled: boolean;
  readonly filePath?: string;
}

/**
 * Wire-safe OPEN-dialog request options (v1.35 — `workshop-publish-from-file`).
 * Mirrors the audited save-dialog subset plus a single file-vs-directory intent.
 * Single-selection only (the Workshop file source picks ONE file or folder), so
 * no `multiSelections` knob is published — minimality (open-vs-save is the same
 * capability domain, the same `host:native-dialog` token).
 */
export interface HostOpenDialogOptions {
  readonly title?: string;
  readonly defaultPath?: string;
  readonly filters?: readonly HostSaveDialogFilter[];
  /** Pick a directory instead of a file (mutually-exclusive intent). Default false. */
  readonly directory?: boolean;
}

/**
 * Wire-safe OPEN-dialog result (v1.35). Carries ONLY the chosen absolute
 * PATH(s) — no `dialog` object, window handle, file handle, or file bytes ever
 * cross into the plugin. Single-selection ⇒ at most one path; empty when
 * canceled.
 */
export interface HostOpenDialogResult {
  readonly canceled: boolean;
  /** Chosen absolute path(s). Single-selection ⇒ at most one. Empty when canceled. */
  readonly paths: readonly string[];
}

/**
 * `host.services.nativeDialog` — the host-owned native dialog service (v1.12;
 * `showOpenDialog` added v1.35). The host opens Electron's
 * `dialog.showSaveDialog` / `dialog.showOpenDialog`; only the wire-safe
 * options/result cross. No `dialog` object, no window handle, no file bytes.
 *
 * @stability additive (MINOR, v1.12; `showOpenDialog` v1.35) — frozen once
 *   published.
 */
export interface HostNativeDialogLike {
  /** Open a native save dialog and resolve with the user's choice. */
  showSaveDialog(options: HostSaveDialogOptions): Promise<HostSaveDialogResult>;
  /**
   * v1.35 — open a native file OR directory picker (selected via
   * `options.directory`); returns the chosen PATH(s) ONLY (`{ canceled, paths }`).
   * Additive on the same port/token as `showSaveDialog` (an open is the SAME
   * capability as a save — no new service member, no new vocabulary token).
   */
  showOpenDialog(options: HostOpenDialogOptions): Promise<HostOpenDialogResult>;
}

/** A custom PDF page size in INCHES (mirrors Electron's `printToPDF` size). */
export interface HostPdfPageSizeInches {
  readonly width: number;
  readonly height: number;
}

/** Page margins in inches (all four required when declared — wire-explicit). */
export interface HostPdfMargins {
  readonly top: number;
  readonly bottom: number;
  readonly left: number;
  readonly right: number;
}

/** A host PDF render request — file paths + wire-safe print options only. */
export interface HostPdfRenderRequest {
  /** ABSOLUTE path of the on-disk HTML entry file to load + render. */
  readonly sourceFilePath: string;
  /** ABSOLUTE destination path the host writes the PDF file to. */
  readonly destPath: string;
  /** `'A4'` or a custom `{ width, height }` in inches. Default `'A4'`. */
  readonly pageSize?: 'A4' | HostPdfPageSizeInches;
  /** Print CSS backgrounds (default `true` — the DS export behavior). */
  readonly printBackground?: boolean;
  /** Page margins in inches (default zero margins — the DS export behavior). */
  readonly margins?: HostPdfMargins;
  /**
   * CSS text injected into the loaded document as a `<style>` appended to
   * `<head>` AFTER load, BEFORE printing (the deck print-stylesheet path) —
   * so it can override the document's own print rules. Omitted ⇒ no injection.
   */
  readonly injectCss?: string;
}

/** A host PDF render result — the destination the host wrote. */
export interface HostPdfRenderResult {
  readonly destPath: string;
}

/**
 * `host.services.pdfRenderer` — the host-owned HTML-to-PDF render service
 * (v1.12). The host loads the source file in a hidden window, optionally
 * injects print CSS, prints to PDF, and WRITES the file at `destPath` — PDF
 * bytes never cross the boundary.
 *
 * @stability additive (MINOR, v1.12) — frozen once published.
 */
export interface HostPdfRendererLike {
  /** Render an on-disk HTML file to a PDF written at `request.destPath`. */
  renderHtmlFileToPdf(request: HostPdfRenderRequest): Promise<HostPdfRenderResult>;
}
