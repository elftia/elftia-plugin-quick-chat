/**
 * host-api/plugin-paths.ts — `HostPluginPathsLike`, the read-only
 * plugin-install path-getter `host.services.pluginPaths` capability port
 * (`oss-channel-isolation` Phase 3 slice P3-3b-2a, host-API v1.30).
 *
 * WHY (P3 context): the channel-gated Steam plugin's MAIN half (loaded
 * in-process) installs Workshop UGC through the host's single guardrail-bearing
 * `PluginInstaller`, which is constructed against the SHARED plugins-install root
 * + plugin-data root (the SAME roots the plugin-management surface uses). A
 * plugin cannot import `@main`/`ElftiaPaths`/`electron` to resolve those roots
 * itself (and once it runs outside the host process it could not anyway). This
 * narrow port is the seam: three host-resolved absolute path strings the plugin
 * reads to point its own install-adjacent logic at the shared roots.
 *
 * NOT THE v1.12 `platformPaths` PORT: the EXISTING `host.services.platformPaths`
 * ({@link import('./backend-native-ops').HostPlatformPathsLike}, v1.12) answers
 * the Design Studio DS paths (userData / agent-workspaces root / bundled
 * resources, all `Promise<string>`). This is a DISTINCT, deliberately separate
 * port for the PLUGIN-INSTALL roots (plugins root / plugin-data root / userData),
 * resolved SYNCHRONOUSLY (`string`, not `Promise<string>`) because the host
 * already holds these as plain strings at construction (`ElftiaPaths` +
 * `app.getPath`) and the plugin uses them to build a `PluginInstaller`-adjacent
 * config synchronously. Two narrow ports, two audited consumption sets — widening
 * the v1.12 port with sync getters of a different shape would conflate two
 * unrelated path domains.
 *
 * NARROW-PORT MINIMALITY (窄端口): a fixed, enumerated set of read-only getters
 * — the three v1.30 install roots plus the two OPTIONAL host-resolved roots
 * added additively since (`getProfileDir?` v1.38, `getDataRootDir?` v1.39) —
 * each an absolute host-resolved path string. NO generic `getPath(name)`
 * passthrough (that would republish the host's whole path namespace), no write,
 * no mkdir, no fs verb.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node shapes are
 * fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts` imports it
 * (via `backend-services.ts`). Every member returns a plain `string` — no
 * DOM/Node type leaks in.
 *
 * @module @elftia/plugin-types/host-api/plugin-paths
 */

/**
 * `host.services.pluginPaths` — host-owned plugin-install path/resource roots
 * (v1.30). Each getter answers SYNCHRONOUSLY with an ABSOLUTE host-resolved
 * path string; the host owns the dev-vs-packaged + userData resolution
 * (`ElftiaPaths` / `app.getPath('userData')`) the plugin would otherwise have
 * to perform with host internals it cannot reach.
 *
 * @stability additive (MINOR, v1.30) — frozen once published; evolution follows
 *   the `version.ts` freeze checklist. Absent on a build that does not wire the
 *   path roots (the plugin `activate` guards — the optional-dep pattern).
 */
export interface HostPluginPathsLike {
  /**
   * The plugins INSTALL root — where installed plugin bundles live
   * (`== ElftiaPaths.getPluginsRootDir()`). The SAME root the host's
   * `PluginInstaller` + the plugin-management surface use.
   */
  getPluginsRootDir(): string;
  /**
   * The plugin-DATA root (`== <userData>/plugin-data`) — the parent of each
   * plugin's private `dataDir()`. The SAME root the host's `PluginInstaller`
   * (and `host.services.storage`) resolves plugin-data dirs under.
   */
  getPluginDataRootDir(): string;
  /** The Electron userData dir (`== app.getPath('userData')`). */
  getUserDataDir(): string;
  /**
   * The Elftia PROFILE dir (`== AppPaths.profileDir == <dataRoot>/profile`,
   * i.e. `~/.elftia/profile` after `elftia-home-relocation`) — the Steam-synced
   * roamable subtree. ADDITIVE + OPTIONAL (`HOST_API_VERSION` 1.37 → 1.38): older
   * hosts lack it, so callers guard with `getProfileDir?.() ?? join(getUserDataDir(),'profile')`.
   * The Steam plugin sources its backup target (`<profileDir>/backups`) from here.
   */
  getProfileDir?(): string;
  /**
   * The Elftia DATA ROOT (`== AppPaths.dataRoot`, i.e. `~/.elftia` after
   * `elftia-home-relocation`), honoring the `ELFTIA_HOME` override and the
   * host's home-first → userData-fallback existence resolution. ADDITIVE +
   * OPTIONAL (`HOST_API_VERSION` 1.38 → 1.39), following the
   * {@link HostPluginPathsLike.getProfileDir} v1.38 precedent verbatim: adding a
   * REQUIRED member to a published interface is a MAJOR break by this package's
   * own freeze checklist, so this ships optional and callers guard —
   * `const root = getDataRootDir?.(); if (!root) …degrade explicitly…`.
   *
   * WHY IT EXISTS: a workflow provider derives its own data home from the data
   * root (e.g. `<dataRoot>/<workflow-id>`). It cannot import `@main` /
   * `ElftiaPaths` / `electron` to resolve it, and once it runs outside the host
   * process it could not anyway.
   *
   * NEVER RECOMPUTE THE DATA ROOT FROM `process.env`. Reading `ELFTIA_HOME` (or
   * joining a home dir) yourself skips the host's existence resolution and the
   * profile relocation, and silently splits the data set in exactly the cases
   * this getter exists for (an interrupted migration, a test temp home, a
   * relocated profile). Absent getter ⇒ degrade explicitly, never guess.
   *
   * SYNC + ABSOLUTE, like every member of this port. NO-WRITE / read-only: it
   * resolves a path, it does not create one. NO new permission token — a
   * path-shape extension of the existing `pluginPaths` read port (again the
   * v1.38 `getProfileDir` precedent).
   */
  getDataRootDir?(): string;
}
