/**
 * host-api/platform-ipc.ts — `AgentUiCanvas` + `AgentUiDataPacks`: ADDITIVE v1.1
 * `host.canvas` / `host.dataPacks` members that FORWARD to the EXISTING host
 * static-CHANNELS adapters (`@/shared/ipc/canvas` → `window.native.canvas`,
 * `@/shared/ipc/dataPacks` → `window.native.dataPacks`).
 *
 * F1 (LEAD-locked): these are typed-host-member FORWARDS — the underlying IPC
 * channels, main-side routers (`CanvasRouter` / `DataPacksRouter`), and handler
 * logic are UNCHANGED. There is NO `plugins:invoke` reroute and NO new IPC
 * channel. The request/response members are async pass-throughs; the 4 push
 * channels become `onX(cb): HostUnregister` subscriptions forwarding the existing
 * host push events.
 *
 * DOM-PURITY INVARIANT (Decision D2): structural shapes + `_shared` primitives
 * ONLY — no `electron` / `WebContents` / `node:*` type, no `react` runtime dep.
 * Payloads are structural lower bounds / `unknown` (OQ2); the SSOT for the
 * concrete payload types stays `@elftia/shared/contracts/api/{canvas,dataPacks}`
 * — this package imports NO renderer/shared runtime source. The host factory
 * casts at the single wiring boundary.
 *
 * @module @elftia/plugin-types/host-api/platform-ipc
 */
import type { HostUnregister } from './_shared';

// ───────────────────────────────────────────────────────────────────────────
// canvas (8 members)
// ───────────────────────────────────────────────────────────────────────────

/**
 * Structural lower bound of `CanvasMutationResult` (the `applyMutation` result).
 *
 * @remarks SSOT: `@elftia/shared/contracts/api/canvas` (`CanvasMutationResult`).
 */
export interface HostCanvasMutationResult {
  changedElementIds: string[];
  [key: string]: unknown;
}

/**
 * Structural lower bound of `CanvasSoftCapPayload` (the `onSoftCapExceeded` push).
 *
 * @remarks SSOT: `@elftia/shared/contracts/api/canvas` (`CanvasSoftCapPayload`).
 */
export interface HostCanvasSoftCapPayload {
  sessionId: string;
  elementCount: number;
  [key: string]: unknown;
}

/**
 * Typed forward to the host `canvas` IPC namespace (`canvasIpc`). 8 members: 5
 * request/response pass-throughs + 3 push subscriptions. Routers UNCHANGED.
 *
 * @stability additive (MINOR)
 */
export interface AgentUiCanvas {
  /** Read the canvas state for a session. Forwards `canvasIpc.getState`. */
  getState(sessionId: string): Promise<unknown>;
  /** Apply a mutation. Forwards `canvasIpc.applyMutation`. */
  applyMutation(sessionId: string, mutation: unknown): Promise<HostCanvasMutationResult>;
  /** Begin a user drag. Forwards `canvasIpc.userDragStart`. */
  userDragStart(sessionId: string, elementId: string): Promise<void>;
  /** End a user drag. Forwards `canvasIpc.userDragEnd`. */
  userDragEnd(sessionId: string, elementId: string): Promise<void>;
  /** Flush pending canvas writes. Forwards `canvasIpc.flush`. */
  flush(sessionId: string): Promise<void>;
  /** Subscribe to canvas-state-changed push events. Forwards `canvasIpc.onStateChanged`. */
  onStateChanged(cb: (event: unknown) => void): HostUnregister;
  /** Subscribe to agent-edited push events. Forwards `canvasIpc.onAgentEdited`. */
  onAgentEdited(cb: (event: unknown) => void): HostUnregister;
  /** Subscribe to soft-cap-exceeded push events. Forwards `canvasIpc.onSoftCapExceeded`. */
  onSoftCapExceeded(cb: (payload: HostCanvasSoftCapPayload) => void): HostUnregister;
}

// ───────────────────────────────────────────────────────────────────────────
// dataPacks (5 members)
// ───────────────────────────────────────────────────────────────────────────

/** A safe data-pack id payload — structural lower bound of `DataPackIdPayload`. */
export interface HostDataPackIdPayload {
  id: string;
  [key: string]: unknown;
}

/** Push `progress` event payload — structural lower bound of `DataPackProgressEvent`. */
export interface HostDataPackProgressEvent {
  id: string;
  phase: string;
  percentage: number;
  message?: string;
  [key: string]: unknown;
}

/**
 * Typed forward to the host `dataPacks` IPC namespace (`dataPacksIpc`). 5
 * members: 4 request/response pass-throughs + 1 push subscription. The result
 * DTOs are renderer/shared-owned (SSOT
 * `@elftia/shared/contracts/api/dataPacks`); typed `unknown` here so the contract
 * package imports no renderer/shared source. Routers UNCHANGED.
 *
 * @stability additive (MINOR)
 */
export interface AgentUiDataPacks {
  /** Query install status. Forwards `dataPacksIpc.status`. */
  status(payload: HostDataPackIdPayload): Promise<unknown>;
  /** Trigger an install. Forwards `dataPacksIpc.install`. */
  install(payload: HostDataPackIdPayload): Promise<unknown>;
  /** Install from a local file (MAIN opens the dialog). Forwards `dataPacksIpc.installFromFile`. */
  installFromFile(payload: HostDataPackIdPayload): Promise<unknown>;
  /** Remove an installed pack. Forwards `dataPacksIpc.uninstall`. */
  uninstall(payload: HostDataPackIdPayload): Promise<unknown>;
  /** Subscribe to install progress push events. Forwards `dataPacksIpc.onProgress`. */
  onProgress(cb: (event: HostDataPackProgressEvent) => void): HostUnregister;
}
