import type { HostUnregister } from './_shared';

export type HostLocalChannelStatus =
  | 'idle'
  | 'processing'
  | 'completed'
  | 'interrupted'
  | 'error'
  | 'suspended';

export interface HostLocalChannelMessage {
  readonly id: string;
  readonly role: 'user' | 'assistant';
  readonly content: string;
  readonly createdAt: string;
  readonly revision: number;
  readonly clientMessageId?: string | null;
}

export interface HostLocalChannelSnapshot {
  readonly endpointId: string;
  readonly chatId: string;
  readonly status: HostLocalChannelStatus;
  readonly revision: number;
  readonly unreadCount: number;
  readonly messages: readonly HostLocalChannelMessage[];
  readonly hasOlderMessages: boolean;
}

export type HostLocalChannelStreamEvent =
  | { readonly type: 'reasoning'; readonly text: string }
  | {
      readonly type: 'tool';
      readonly phase: 'start' | 'end';
      readonly name: string;
      readonly status?: 'running' | 'done' | 'error';
      readonly summary?: string;
    }
  | { readonly type: 'text'; readonly delta: string };

export type HostLocalChannelEvent =
  | {
      readonly type: 'message';
      readonly revision: number;
      readonly message: HostLocalChannelMessage;
    }
  | { readonly type: 'status'; readonly revision: number; readonly status: HostLocalChannelStatus }
  | { readonly type: 'unread'; readonly revision: number; readonly unreadCount: number }
  | {
      readonly type: 'stream';
      readonly revision: number;
      readonly stream: HostLocalChannelStreamEvent;
    }
  | {
      readonly type: 'error';
      readonly revision: number;
      readonly code: string;
      readonly message: string;
    }
  | { readonly type: 'resnapshot-required'; readonly code: 'RESNAPSHOT_REQUIRED' }
  | { readonly type: 'revoked'; readonly code: 'ENDPOINT_UNAVAILABLE' | 'NOT_DECLARED' };

export interface HostLocalChannelSendResult {
  readonly accepted: boolean;
  readonly duplicate: boolean;
  readonly message: HostLocalChannelMessage;
}

export interface HostLocalChannelClient {
  send(input: {
    readonly text: string;
    readonly clientMessageId: string;
  }): Promise<HostLocalChannelSendResult>;
  stop(): Promise<void>;
  getSnapshot(): Promise<HostLocalChannelSnapshot>;
  subscribe(listener: (event: HostLocalChannelEvent) => void): HostUnregister;
  markRead(): Promise<void>;
  detach(): Promise<void>;
}

export interface HostLocalChannels {
  attach(input: {
    readonly endpointId: string;
    readonly chatId: string;
  }): Promise<HostLocalChannelClient>;
}

/** Wire-safe attachment event delivered to a main-half plugin connection. */
export interface HostLocalChannelEventEnvelope {
  readonly attachmentId: string;
  readonly event: HostLocalChannelEvent;
}

export interface HostLocalChannelAttachResult {
  readonly snapshot: HostLocalChannelSnapshot;
  readonly watermark: number;
}

export interface HostLocalChannelOperationResult {
  readonly success: true;
}

/**
 * Flat main-half Local Channel port. Unlike the renderer convenience API, this
 * surface contains no callback-bearing client object in an RPC result, so it
 * can cross the extension-host process boundary unchanged. Plugin identity is
 * host-injected by the per-plugin handle and is intentionally absent from every
 * request shape.
 */
export interface HostLocalChannelsBackend {
  attach(input: {
    readonly endpointId: string;
    readonly chatId: string;
    readonly attachmentId: string;
  }): Promise<HostLocalChannelAttachResult>;
  activate(input: {
    readonly endpointId: string;
    readonly chatId: string;
    readonly attachmentId: string;
    readonly watermark: number;
  }): Promise<HostLocalChannelOperationResult>;
  snapshot(input: {
    readonly endpointId: string;
    readonly chatId: string;
  }): Promise<HostLocalChannelSnapshot>;
  send(input: {
    readonly endpointId: string;
    readonly chatId: string;
    readonly text: string;
    readonly clientMessageId: string;
  }): Promise<HostLocalChannelSendResult>;
  stop(input: {
    readonly endpointId: string;
    readonly chatId: string;
  }): Promise<HostLocalChannelOperationResult>;
  markRead(input: {
    readonly endpointId: string;
    readonly chatId: string;
  }): Promise<HostLocalChannelOperationResult>;
  detach(input: {
    readonly endpointId: string;
    readonly chatId: string;
    readonly attachmentId: string;
  }): Promise<HostLocalChannelOperationResult>;
  onEvent(listener: (envelope: HostLocalChannelEventEnvelope) => void): HostUnregister;
}
