/** Lib-agnostic Quick Chat ports shared by the main and renderer contracts. */

export type HostQuickChatOperation = 'open' | 'toggle' | 'focus' | 'close';
export type HostQuickChatPlacementIntent =
  | 'near-active-pet'
  | 'near-cursor'
  | 'primary-bottom-right';

export interface HostQuickChatSurfaceRequest {
  readonly operation: HostQuickChatOperation;
  readonly placement?: HostQuickChatPlacementIntent;
}

export interface HostQuickChatSurfaceResult {
  readonly state: 'visible' | 'closed';
}

/** Main-only owner-bound request port. Identity and native state are Host-closed-over. */
export interface HostQuickChatSurfaceLike {
  request(input: HostQuickChatSurfaceRequest): Promise<HostQuickChatSurfaceResult>;
}

/** The sole native-window intent exposed to a dedicated Quick Chat module. */
export interface QuickChatWindowCloseIntent {
  request(): Promise<void>;
}
