/** Lib-agnostic Quick Chat ports shared by the main and renderer contracts. */
import type { HostComponentType, HostUnregister } from './_shared';

export type HostQuickChatOperation = 'open' | 'toggle' | 'focus' | 'close';
export type HostQuickChatPlacementIntent =
  | 'near-active-pet'
  | 'near-cursor'
  | 'primary-bottom-right';

export interface HostQuickChatSurfaceRequest {
  readonly operation: HostQuickChatOperation;
  readonly placement?: HostQuickChatPlacementIntent;
}

export interface HostQuickChatSurfaceResult {
  readonly state: 'visible' | 'closed';
}

/** Main-only owner-bound request port. Identity and native state are Host-closed-over. */
export interface HostQuickChatSurfaceLike {
  request(input: HostQuickChatSurfaceRequest): Promise<HostQuickChatSurfaceResult>;
}

export interface HostQuickChatSurfaceDefinition {
  readonly id: string;
  readonly render: HostComponentType<Record<string, never>>;
}

/** Renderer-only registry meaningful inside the trusted Quick Chat shell. */
export interface HostQuickChatRegistry {
  registerSurface(definition: HostQuickChatSurfaceDefinition): HostUnregister;
}
