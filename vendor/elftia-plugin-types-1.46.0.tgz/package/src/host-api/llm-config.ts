/**
 * host-api/llm-config.ts — `HostLlmConfigLike`, the `host.services.llmConfig`
 * capability port (`byo-port-llm-config`, host-API v1.21).
 *
 * Lets a Tier-1 main plugin (the future `byo-providers` plugin) drive LLM
 * provider configuration WITHOUT the host owning any BYO-key UI: provider CRUD,
 * the multi-key pool, provider presets, and the default-model router config.
 *
 * MASK-ON-RETURN INVARIANT (design D2/D3): EVERY method that returns provider or
 * key data returns the SAME renderer-masked projection the existing
 * `llmConfig:*` IPC handlers return (`toRendererProvider` / the key-pool
 * `toRendererEntry`): a literal API key is BLANKED (`api_key: ''` + `hasKey`),
 * a `$VAR` env reference is preserved verbatim (it is not a secret), and a
 * key-pool entry surfaces only a non-reversible `keyHint`. No method on this
 * port returns a plaintext API key. Writes (`setSecret`-bearing flows) ride the
 * separate write-only `host.services.secretsWrite` port — provider/key bodies
 * carry the plaintext INWARD only.
 *
 * THE REVEAL EXCEPTION (host-API v1.50): `revealProviderKey` is the ONE
 * deliberate outward exception — it returns the stored key for USER-INITIATED
 * display (the settings eye icon) on a dedicated
 * {@link HostLlmKeyRevealResult}, never on a provider row, so the structural
 * mask above stays intact for every other method.
 *
 * DOM-PURITY INVARIANT (Decision D2): a MAIN-context module (Node/Electron
 * shapes are fine). It MUST NOT be imported by `renderer.ts`; only `backend.ts`
 * imports it. No DOM type leaks in. Like `HostMcpProviderLike`, the payload
 * shapes are STRUCTURAL LOWER BOUNDS (Node-shaped, no `@main`/`@shared` import)
 * — the host's canonical `LLMProvider` / `LLMProviderResult` / `RouterConfig`
 * are structurally assignable, and the plugin re-narrows what it reads.
 *
 * @module @elftia/plugin-types/host-api/llm-config
 */

/**
 * A renderer-MASKED LLM provider, as the IPC `getProviders`/`getProvider` path
 * returns. Pins only the masked-key fields the contract guarantees; the rest of
 * the provider row is opaque (the index signature). Canonical: the masked
 * `LLMProvider` produced by `toRendererProvider`.
 *
 * `api_key` is BLANKED for a literal key (a `$VAR` env ref is preserved); the
 * boolean `hasKey` reports whether a key is stored. Never a plaintext literal.
 */
export interface HostMaskedLlmProvider {
  /** Stable provider id. */
  readonly id: string;
  /** BLANKED for a literal key; a `$VAR` env reference is preserved verbatim. */
  readonly api_key?: string;
  /** Whether a key (ciphertext ref or `$VAR` ref or legacy plaintext) is stored. */
  readonly hasKey?: boolean;
  /** Remaining provider fields are opaque — see the canonical `LLMProvider`. */
  readonly [key: string]: unknown;
}

/**
 * The mutation/toggle/reset envelope, as the IPC path returns it. `provider`
 * (when present) is ALREADY masked (`toRendererProviderResult`).
 */
export interface HostLlmProviderResult {
  readonly success: boolean;
  readonly message?: string;
  /** The masked provider after the mutation (absent on failure). */
  readonly provider?: HostMaskedLlmProvider;
  /** Remaining envelope fields are opaque — see canonical `LLMProviderResult`. */
  readonly [key: string]: unknown;
}

/** A plain `{ success, message? }` op result (delete / reorder). */
export interface HostLlmOpResult {
  readonly success: boolean;
  readonly message?: string;
}

/**
 * The EXPLICIT key-reveal result (host-API v1.50) — the ONE deliberate
 * exception to mask-on-return: carries the provider's stored key OUTWARD, only
 * on the `revealProviderKey` verb, only for user-initiated display (the
 * settings eye icon). `value` is the resolved `api_key` (plaintext literal, or
 * a `$VAR`/relay-marker ref verbatim — refs are not secrets); `''` when none
 * is stored. It lives on THIS result type — outside
 * {@link HostMaskedLlmProvider} — so the `api_key` structural mask stays
 * intact for every provider-returning method.
 */
export interface HostLlmKeyRevealResult {
  readonly success: boolean;
  /** The stored key (plaintext, or a `$VAR` ref verbatim); `''` when unset. */
  readonly value?: string;
  readonly error?: string;
}

/**
 * A renderer-MASKED key-pool entry, as the IPC `getApiKeys` path returns
 * (`toRendererEntry`). `apiKey` is blanked for a literal key (a `$VAR` ref is
 * preserved); `keyHint` is a non-reversible last-4 hint at most; `hasKey`
 * reports presence. Never a plaintext literal.
 */
export interface HostMaskedPoolKeyEntry {
  /** Stable key-pool entry id. */
  readonly id: string;
  /** Whether a key (ciphertext ref or legacy plaintext) is stored. */
  readonly hasKey: boolean;
  /** BLANKED for a literal key; a `$VAR` env reference is preserved verbatim. */
  readonly apiKey: string;
  /** A non-reversible masked hint (e.g. `••••1234`) — never the full key. */
  readonly keyHint?: string;
  /** Remaining entry fields (providerId / label / enabled / weight / …) opaque. */
  readonly [key: string]: unknown;
}

/** The `{ success, key? }` envelope of an add/update key-pool mutation (masked). */
export interface HostPoolKeyMutationResult {
  readonly success: boolean;
  readonly message?: string;
  /** The masked key-pool entry after the mutation (absent on failure). */
  readonly key?: HostMaskedPoolKeyEntry;
}

/** Per-key live cooldown health, keyed by key id (opaque value shape). */
export type HostKeyHealthMap = { readonly [keyId: string]: unknown };

/** Options for `discoverModels` (mirrors the IPC `modelDiscoverOptionsSchema`). */
export interface HostModelDiscoverOptions {
  readonly forceRefresh?: boolean;
}

/**
 * The diagnostic result of `testModel` (host-API v1.27 — `byo-p2-llm-2`). A
 * STATUS/DIAGNOSTIC shape only: it reports reachability + the probe round-trip,
 * NOT any secret. NO field carries an API key or token (the connectivity probe
 * sends a trivial "Hello" host-side using the host-resolved key; the key never
 * crosses, in or out). Canonical: the host `completion.testModel` return.
 */
export interface HostModelTestResult {
  /** Whether the connectivity probe succeeded. */
  readonly success: boolean;
  /** Human-readable outcome message (never a secret). */
  readonly message: string;
  /** The model's reply text (when the probe succeeded) — never a secret. */
  readonly response?: string;
  /** The model id that was probed. */
  readonly model: string;
  /** Round-trip duration in milliseconds (when measured). */
  readonly durationMs?: number;
}

/**
 * `host.services.llmConfig` — the LLM-config capability port.
 *
 * Every method Zod-validates its payload (≥ the corresponding IPC handler,
 * reusing the same schemas) before delegating to the host's `LLMConfigService`
 * + the shared key-pool ops module + the router config; every provider/key
 * return is masked. `import`/`export` bulk config is DELIBERATELY omitted from
 * v1 of the port (a host-app concern; additive later if a real consumer needs
 * it — the `host.services` narrowing discipline).
 */
export interface HostLlmConfigLike {
  // ── Providers ──────────────────────────────────────────────────────────────
  /** List all providers (masked). */
  getProviders(): Promise<HostMaskedLlmProvider[]>;
  /** Get one provider by id (masked, or `null` when absent). */
  getProvider(id: string): Promise<HostMaskedLlmProvider | null>;
  /** Create a provider; returns the masked mutation envelope. */
  addProvider(input: Record<string, unknown>): Promise<HostLlmProviderResult>;
  /** Update a provider (input carries its `id`); returns the masked envelope. */
  updateProvider(input: Record<string, unknown>): Promise<HostLlmProviderResult>;
  /** Delete a provider by id. */
  deleteProvider(id: string): Promise<HostLlmOpResult>;
  /** Enable/disable a provider; returns the masked envelope. */
  toggleProvider(id: string, enabled: boolean): Promise<HostLlmProviderResult>;
  /** Reorder providers by an ordered id list. */
  reorderProviders(orderedIds: readonly string[]): Promise<HostLlmOpResult>;
  /** Reset a provider to its catalog defaults; returns the masked envelope. */
  resetProvider(id: string): Promise<HostLlmProviderResult>;
  /** Discover a provider's models (optionally force-refresh). Shape opaque. */
  discoverModels(id: string, options?: HostModelDiscoverOptions): Promise<unknown>;
  /**
   * Probe a provider/model for reachability (host-API v1.27 — `byo-p2-llm-2`).
   * A connectivity DIAGNOSTIC: the host sends a trivial prompt with the
   * host-resolved key and returns `{ success, message, response?, model,
   * durationMs? }` — NO secret crosses in or out (the key never appears in the
   * request or the response). Reuses the EXISTING `host:llm-config` token (a
   * provider/model operation in the llm-config domain — no new token). Delegates
   * to the same body the host `completion.testModel` IPC uses.
   */
  testModel(providerId: string, modelId: string): Promise<HostModelTestResult>;
  /**
   * Reveal a provider's stored API key (host-API v1.50) — the ONE deliberate
   * outward exception to mask-on-return, for user-initiated display (the
   * settings eye icon). Resolves the host-side key (plaintext, or a `$VAR`/
   * relay-marker ref verbatim); absent provider → `{ success: false }`. Reuses
   * the EXISTING `host:llm-config` token (same domain — no new token).
   */
  revealProviderKey?(providerId: string): Promise<HostLlmKeyRevealResult>;

  // ── Presets ──────────────────────────────────────────────────────────────
  /** List the built-in provider presets (catalog; opaque shape). */
  getProviderPresets(): Promise<unknown> | unknown;
  /**
   * Add a provider from a preset id (with an optional inbound key). The inbound
   * `apiKey` is carried INWARD only; the returned envelope is masked.
   */
  addFromPreset(presetId: string, apiKey?: string): Promise<HostLlmProviderResult>;

  // ── Key pool ──────────────────────────────────────────────────────────────
  /** List a provider's pool keys (masked entries). */
  getApiKeys(providerId: string): Promise<HostMaskedPoolKeyEntry[]>;
  /** Add a pool key (encrypt-at-rest); returns the masked entry envelope. */
  addApiKey(input: Record<string, unknown>): Promise<HostPoolKeyMutationResult>;
  /** Update a pool key (input carries its `id`); returns the masked envelope. */
  updateApiKey(input: Record<string, unknown>): Promise<HostPoolKeyMutationResult>;
  /** Delete a pool key by id (also deletes its secret). */
  deleteApiKey(id: string): Promise<HostLlmOpResult>;
  /** Toggle a pool key's enabled state. */
  toggleApiKey(input: Record<string, unknown>): Promise<HostLlmOpResult>;
  /** Live cooldown health for a provider's pool keys. */
  getKeyHealth(providerId: string): Promise<HostKeyHealthMap>;

  // ── Default model (router config) ───────────────────────────────────────────
  /** Get the router config (carries `router.default` = the default model). */
  getRouterConfig(): Promise<unknown>;
  /** Set the router config (validated); returns the op result (opaque shape). */
  setRouterConfig(config: Record<string, unknown>): Promise<unknown>;
}
