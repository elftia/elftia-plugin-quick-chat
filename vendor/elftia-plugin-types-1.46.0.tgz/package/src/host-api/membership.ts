/**
 * host-api/membership.ts — `AgentUiMembership`, the ADDITIVE v1.36 `host.membership`
 * member of `AgentUiHostApi`: a single REGISTER port that lets a channel-gated
 * plugin SUPPLY the Colorful-purchase behavior (and its COPY) the CORE upsell
 * dialog invokes + renders, keeping the open-source core free of any
 * channel-specific (Steam) reference — in BEHAVIOR and in WORDING.
 *
 * ROUTED MECHANISM. `registerColorfulPurchase(registration)` routes to the host's
 * canonical single-slot Colorful-purchase registry (`registerColorfulPurchase`
 * in `@/shared/state/colorfulPurchaseStore`, last-registration-wins — the
 * `host.chatPanel` / `designCommentsTabStore` single-slot IoC precedent). The
 * core `UpgradeDialog` resolves the registered `registration` reactively, renders
 * the plugin-supplied `copy` thunks for its CTA / intro / pending lines (falling
 * back to a channel-NEUTRAL host string when a thunk is absent), and INVOKES
 * `registration.purchase` for its purchase CTA; the plugin's `purchase` opens the
 * store + polls ownership, and the entitlement reaches core through the EXISTING
 * entitlement-state path — NEVER as a return value. `purchase` therefore yields
 * NO value.
 *
 * COPY OWNERSHIP (the steam-free crux). The host AUTHORS NO Steam copy: it owns a
 * channel-NEUTRAL fallback (`settings.membershipUpgrade.colorfulBuy` /
 * `colorfulPurchasing`) and renders the plugin's `copy` thunks when present. The
 * copy thunks follow the section-label-thunk precedent (`host.settings`
 * `SettingsSectionDefinitionLike.label` / the steam plugin's `readPointsSectionLabel`):
 * each is re-evaluated PER RENDER (plugin i18n), so the plugin owns the Steam
 * wording and the core renders it without ever naming the channel.
 *
 * 窄端口 DISCIPLINE: exposes EXACTLY ONE member — `registerColorfulPurchase(
 * registration): HostUnregister` — the `hello`/`workspace`/`chatPanel`/
 * `sessionKinds` register precedent. No read, no ownership query, no return value
 * from `purchase`: the result surfaces only via the host entitlement state the
 * dialog already reacts to. `copy` is OPTIONAL (absent ⇒ the host fallback).
 *
 * DOM-PURITY INVARIANT: this module imports ONLY `./_shared` (`HostUnregister`).
 * No `react` runtime dep, no `electron`/`node:*` type, no `@main`/`@shared`
 * source — it is imported by `renderer.ts` only (never `backend.ts`).
 *
 * @module @elftia/plugin-types/host-api/membership
 */
import type { HostUnregister } from './_shared';

/**
 * Plugin-supplied COPY for the core Colorful-purchase upsell dialog. Each member
 * is an OPTIONAL string thunk (the section-label-thunk precedent): re-evaluated
 * PER RENDER so it tracks the plugin's own i18n / locale changes. The plugin owns
 * the channel-specific wording (it MAY mention Steam); the host renders whatever
 * is present and falls back to its OWN channel-NEUTRAL string when a thunk is
 * absent — so the core authors NO Steam copy.
 *
 * @since 1.36
 */
export interface ColorfulPurchaseCopy {
  /** CTA label thunk (e.g. "Buy Colorful"). Absent ⇒ the host neutral CTA. */
  readonly cta?: () => string;
  /** Optional pre-purchase intro line. Absent ⇒ no intro is rendered. */
  readonly intro?: () => string;
  /** Optional in-progress line shown while `purchase` runs. Absent ⇒ host neutral. */
  readonly pending?: () => string;
}

/**
 * The registration object a channel-gated plugin hands the core
 * `host.membership.registerColorfulPurchase`. `purchase` is the imperative
 * channel-specific flow (e.g. open the DLC store + poll ownership); it yields NO
 * value — the purchase result reaches the core dialog through the EXISTING
 * entitlement-state path it already observes, never as a return. `copy` is the
 * OPTIONAL plugin-supplied wording (absent ⇒ the host channel-NEUTRAL fallback).
 *
 * @since 1.36
 */
export interface ColorfulPurchaseRegistration {
  /**
   * Perform the channel-specific purchase flow (open the DLC store + poll
   * ownership). Yields NO value — the entitlement flips via the EXISTING
   * entitlement-state path, never as a return.
   */
  readonly purchase: () => void | Promise<void>;
  /**
   * Plugin-supplied CTA / intro / pending COPY. OPTIONAL — when absent (or a
   * given thunk is absent) the host renders its channel-NEUTRAL fallback, so the
   * core authors NO Steam copy. See {@link ColorfulPurchaseCopy}.
   */
  readonly copy?: ColorfulPurchaseCopy;
}

/**
 * The ADDITIVE v1.36 `host.membership` port: the channel-agnostic seam for the
 * Colorful purchase entry. A channel-gated plugin (the Steam plugin) registers
 * the imperative purchase behavior AND its copy; the core upsell dialog invokes
 * the behavior and renders the copy without ever naming the channel.
 *
 * @since 1.36
 */
export interface AgentUiMembership {
  /**
   * Register the Colorful-purchase registration (single-slot, last-registration-
   * wins; routes to `registerColorfulPurchase` → `colorfulPurchaseStore`). The
   * host factory disposer-tracks the returned `HostUnregister` in the plugin's
   * owner scope so a hot-toggle / `unloadOne` revokes it.
   *
   * `registration.purchase` performs the channel-specific purchase flow (e.g.
   * open the DLC store + poll ownership); it yields NO value — the purchase
   * result reaches the core dialog through the EXISTING entitlement-state path it
   * already observes, never as a return. `registration.copy` (OPTIONAL) supplies
   * the CTA / intro / pending wording; when a thunk is absent the host renders
   * its channel-NEUTRAL fallback, so the core authors NO Steam copy.
   */
  registerColorfulPurchase(registration: ColorfulPurchaseRegistration): HostUnregister;
}
